[ActiveSupport TRCE]
; Setup Analysis
Fmax_0 = 182.083 MHz (21.477 MHz);
Fmax_1 = 62.590 MHz (42.954 MHz);
Failed = 0 (Total 2);
Clock_ports = 1;
Clock_nets = 2;
; Hold Analysis
Fmax_0 = 0.304 ns (0.000 ns);
Fmax_1 = 0.199 ns (0.000 ns);
Failed = 0 (Total 2);
Clock_ports = 1;
Clock_nets = 2;
