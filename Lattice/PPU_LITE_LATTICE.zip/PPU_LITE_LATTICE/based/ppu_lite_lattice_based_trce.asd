[ActiveSupport TRCE]
; Setup Analysis
Fmax_0 = 243.191 MHz (21.477 MHz);
Fmax_1 = 70.892 MHz (42.954 MHz);
Failed = 0 (Total 2);
Clock_ports = 1;
Clock_nets = 2;
; Hold Analysis
Fmax_0 = 0.304 ns (0.000 ns);
Fmax_1 = 0.201 ns (0.000 ns);
Failed = 0 (Total 2);
Clock_ports = 1;
Clock_nets = 2;
