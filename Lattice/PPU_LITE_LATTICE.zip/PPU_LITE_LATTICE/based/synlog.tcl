run_tcl -fg PPU_LITE_LATTICE_based_synplify.tcl
