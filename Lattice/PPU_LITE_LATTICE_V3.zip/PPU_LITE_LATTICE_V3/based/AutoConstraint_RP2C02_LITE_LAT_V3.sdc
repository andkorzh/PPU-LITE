
#Begin clock constraint
define_clock -name {PLL|CLKOP_inferred_clock} {n:PLL|CLKOP_inferred_clock} -period 6.244 -clockgroup Autoconstr_clkgroup_0 -rise 0.000 -fall 3.122 -route 0.000 
#End clock constraint

#Begin clock constraint
define_clock -name {RP2C02_LITE_LAT_V3|MCLK} {p:RP2C02_LITE_LAT_V3|MCLK} -period 1.537 -clockgroup Autoconstr_clkgroup_1 -rise 0.000 -fall 0.768 -route 0.000 
#End clock constraint
