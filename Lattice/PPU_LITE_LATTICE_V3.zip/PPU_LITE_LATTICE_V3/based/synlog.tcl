run_tcl -fg PPU_LITE_LATTICE_V3_based_synplify.tcl
