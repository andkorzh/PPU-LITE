//NTSC_PAL composite video encoder
// Author HardWareMan
// Implementation of andkorzh
module CODER_NTSC_PAL(
//Clock
input Clk,           // Clock frequency 42.954 / 53.203 MHz
// Inputs
input BLANK,         // Blanking
input BURST,         // Color Subcarrier Sync Burst Output Mask
input SYNC,          // Composite sync input
input [5:0]PIX,      // Pixel input data
input [2:0]EMP,      // Emphasis B, G, R
input MODE,          // PAL/NTSC mode
input ODD,           // Even-odd scanline
// Outputs
output [6:0]COMPOSIT // Video DAC output
);
// Variables
reg [3:0]DIV;        // Clock frequency divider for obtaining color subcarrier
reg [12:1]PH;        // Color burst phase register
// Combinatorics
wire ODDM;
assign ODDM = ODD & MODE;
// Phase selector
wire SUB;
assign SUB = (~ODDM) ?
            (~PIX[3]) ?
               (~PIX[2]) ?
                  (~PIX[1]) ?
                     (~PIX[0]) ? 1'b1   : PH[1]
                  :
                     (~PIX[0]) ? PH[2]  : PH[3]
               :
                  (~PIX[1]) ?
                     (~PIX[0]) ? PH[4]  : PH[5]
                  :
                     (~PIX[0]) ? PH[6]  : PH[7]
            :
               (~PIX[2]) ?
                  (~PIX[1]) ?
                     (~PIX[0]) ? PH[8]  : PH[9]
                  :
                     (~PIX[0]) ? PH[10] : PH[11]
               :
                  (~PIX[1]) ?
                     (~PIX[0]) ? PH[12] : 1'b0
                  :
                     1'b0
         :
            (~PIX[3]) ?
               (~PIX[2]) ?
                  (~PIX[1]) ?
                     (~PIX[0]) ? 1'b1   : PH[4]
                  :
                     (~PIX[0]) ? PH[3]  : PH[2]
               :
                  (~PIX[1]) ?
                     (~PIX[0]) ? PH[1]  : PH[12]
                  :
                     (~PIX[0]) ? PH[11] : PH[10]
            :
               (~PIX[2]) ?
                  (~PIX[1]) ?
                     (~PIX[0]) ? PH[9]  : PH[8]
                  :
                     (~PIX[0]) ? PH[7]  : PH[6]
               :
                  (~PIX[1]) ?
                     (~PIX[0]) ? PH[5]  : 1'b0
                  :
                     1'b0;
// Emphasis
wire TINT;
assign TINT = (EMP[2] & PH[8]) | (EMP[1] & PH[4]) | (EMP[0] & PH[12]);
// The resulting signal
wire [6:0]DMUX;
assign DMUX[6:0] = (BURST) ? 
                  (~ODDM) ?
                     PH[8] ? 7'h29 : 7'h0F 
                  :
                     PH[6] ? 7'h29 : 7'h0F 
               :
               (BLANK | (PIX[3] & PIX[2] & PIX[1])) ? 7'h16 :
                  (TINT) ?
                     (~PIX[5]) ?
                        (~PIX[4]) ?
                           (SUB) ? 7'h2B : 7'h0D
                        :
                           (SUB) ? 7'h43 : 7'h12
                     :
                        (~PIX[4]) ?
                           (SUB) ? 7'h60 : 7'h26
                        :
                           (SUB) ? 7'h60 : 7'h45
                  :
                     (~PIX[5]) ?
                        (~PIX[4]) ?
                           (SUB) ? 7'h36 : 7'h10
                        :
                           (SUB) ? 7'h54 : 7'h16
                     :
                        (~PIX[4]) ?
                           (SUB) ? 7'h78 : 7'h30
                        :
                           (SUB) ? 7'h78 : 7'h56;
assign COMPOSIT[6:0] = DMUX[6:0] & {7{SYNC}};
// Logics
always @(posedge Clk) begin
   // Color burst phase register
   {PH[12:1]} <= {DIV[3],PH[12:2]};
   // Subcarrier divider
   if (DIV[2] & ~DIV[1] & DIV[0]) begin
       DIV[2:0] <= 3'h0;
       DIV[3]   <= ~DIV[3];
       end else DIV[2:0] <= DIV[2:0] + 3'h1;
                      end
// End of module
endmodule