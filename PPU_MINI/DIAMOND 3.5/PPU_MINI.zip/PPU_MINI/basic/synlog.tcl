run_tcl -fg PPU_MINI_basic_synplify.tcl
