[ActiveSupport TRCE]
; Setup Analysis
Fmax_0 = 268.889 MHz (21.477 MHz);
Fmax_1 = 78.101 MHz (42.954 MHz);
Failed = 0 (Total 2);
Clock_ports = 1;
Clock_nets = 2;
; Hold Analysis
Fmax_0 = 0.299 ns (0.000 ns);
Fmax_1 = 0.216 ns (0.000 ns);
Failed = 0 (Total 2);
Clock_ports = 1;
Clock_nets = 2;
