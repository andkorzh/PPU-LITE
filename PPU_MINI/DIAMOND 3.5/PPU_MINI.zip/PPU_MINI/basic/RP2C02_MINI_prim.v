// Verilog netlist produced by program LSE :  version Diamond Version 3.5.0.102
// Netlist written on Wed Sep 16 17:53:06 2026
//
// Verilog Description of module RP2C02_MINI
//

module RP2C02_MINI (MCLK, MODE_IN, DENDY_IN, nRES, PALSEL, RnW, 
            nDBE, A, PD, VRAMCS, VRAMA10, PCLK, SUBCLK, DB, 
            RGB, PA8, PA9, PA10, PA11, PA12, PA13, INT, ALE, 
            nWR, nRD, SYNC) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(35[8:19])
    input MCLK;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(36[7:11])
    input MODE_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(38[7:14])
    input DENDY_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(39[7:15])
    input nRES;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(40[7:11])
    input [2:0]PALSEL;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(41[12:18])
    input RnW;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(42[7:10])
    input nDBE;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(43[7:11])
    input [2:0]A;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(44[12:13])
    inout [7:0]PD;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(45[12:14])
    input VRAMCS;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(46[7:13])
    input VRAMA10;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(47[7:14])
    output PCLK;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(49[8:12])
    output SUBCLK;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(50[8:14])
    inout [7:0]DB;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(51[12:14])
    output [23:0]RGB;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    output PA8;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(53[8:11])
    output PA9;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(54[8:11])
    output PA10;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(55[8:12])
    output PA11;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(56[8:12])
    output PA12;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(57[8:12])
    output PA13;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(58[8:12])
    output INT;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(59[8:11])
    output ALE;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(60[8:11])
    output nWR;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(61[8:11])
    output nRD;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(62[8:11])
    output SYNC;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(63[8:12])
    
    wire MCLK_c /* synthesis is_clock=1, SET_AS_NETWORK=MCLK_c */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(36[7:11])
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire Clk2_N_17 /* synthesis is_inv_clock=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(478[5:10])
    
    wire MODE_IN_c, DENDY_IN_c, nRES_c, PALSEL_c_2, PALSEL_c_1, PALSEL_c_0, 
        RnW_c, nDBE_c, A_c_2, A_c_1, A_c_0, SUBCLK_c, RGB_c_23, 
        RGB_c_22, RGB_c_21, RGB_c_20, RGB_c_19, RGB_c_18, RGB_c_17, 
        RGB_c_16, RGB_c_15, RGB_c_14, RGB_c_13, RGB_c_12, RGB_c_11, 
        RGB_c_10, RGB_c_9, RGB_c_8, RGB_c_7, RGB_c_6, RGB_c_5, RGB_c_4, 
        RGB_c_3, RGB_c_2, RGB_c_1, RGB_c_0, PA8_c_8, PA9_c_9, PA10_c_10, 
        PA11_c_11, PA12_c_12, PA13_c_13, INT_c, ALE_c, nWR_c, nRD_c, 
        SYNC_c;
    wire [5:0]Hn;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(68[11:13])
    wire [5:0]Hnn;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(69[11:14])
    wire [7:0]DBIN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(70[11:15])
    wire [7:0]OB;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(71[11:13])
    wire [3:0]OV;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(72[11:13])
    wire [7:0]Vo;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(73[11:13])
    wire [2:0]R2DB;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(75[11:15])
    wire [4:0]THO;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(76[11:14])
    wire [13:0]PAD;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(76[27:30])
    wire [4:0]ZCOL;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(78[11:15])
    wire [4:0]CGA;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(79[11:14])
    wire [2:0]EMPH;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(80[11:15])
    
    wire W0, W1, R2, W3, W4, R4, W5_1, W5_2, W6_1, W6_2, 
        W7, R7, R_EN, I1_32, OBSEL, BGSEL, O8_16, VBL_EN, B_W, 
        BGCLIP, S_EV, O_HPOS, nEVAL, E_EV, I_OAM2, PAR_O, nVIS, 
        F_NT, SC_CNT, nPICTURE, RC, RESCL, TH_MUX, TVO1, OMFG, 
        PD_FIFO, SPR0_EV, SPR_OV, SH2, GND_net;
    wire [2:0]DIV;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(479[10:13])
    
    wire DIV_2__N_3, RnWR, nDBER, CLIPOR, EMP_R, EMP_G, n11800, 
        nCLPB_N_123, n11577;
    wire [7:0]OB_R;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(640[10:14])
    wire [7:0]D;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(643[11:12])
    
    wire n84, n85, n86, n87, n88, n89, n90, n91, HC, CLIP_OUT, 
        FTA_OUT, NFO_OUT, N_HB, RESCL_IN, BLNK_FF;
    wire [8:0]H;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(735[11:12])
    
    wire CLIP_B_N_240, H_8__N_226, Vo_7__N_205, n11798, n10549, Clk_enable_87, 
        n11797, n11794, n11840, n11839, XRB_N_599;
    wire [3:0]BGC2;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(947[10:14])
    
    wire CLPB_LATCH, F_AT_LATCH, PD_SR, PD_SEL, n11709;
    wire [11:0]TP;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1056[11:13])
    
    wire NTV_IN, TVZ, TVZB;
    wire [4:0]TVO;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1089[11:14])
    
    wire NTVDO;
    wire [2:0]FVO;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1091[11:14])
    
    wire NBFVO1;
    wire [13:0]PAMUX;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1105[12:17])
    
    wire THSTEP_N_916;
    wire [7:0]PAMUX_7__N_852;
    wire [7:0]PAMUX_7__N_844;
    
    wire TH_4__N_769, n11830, Clk_enable_120, TAL_LATCH_N_883, n10489, 
        SPR0_EV1, OVZ, SPR0_EV1_N_977, VCC_net;
    wire [4:0]W4Q;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1239[10:13])
    
    wire ORES_LATCH;
    wire [2:0]OSTEP;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1242[10:15])
    
    wire OVF_LATCH, OMFG_LATCH, OMV_LATCH, OAMCTR2, ORES;
    wire [7:0]OAM1ADR;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1262[11:18])
    
    wire Clk_enable_514, OAP_N_1084, Clk_enable_83, OAM2STEP_N_1097, 
        OAMQ_7__N_1034, OB2_7__N_1036, OMSTEP_1__N_1046;
    wire [7:0]SEL_LATCH;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1322[10:19])
    
    wire SPR0HIT_LATCH, n10784, SH2_N_1365, SH3_N_1374, SH5_N_1378, 
        SH7_N_1383, DB_out_0, DB_out_1, DB_out_2, DB_out_3, DB_out_4, 
        n11816, DB_out_5, DB_out_6, DB_out_7, PD_out_0, ATR_IN0_2__N_1353, 
        PD_out_1, ATR_IN1_2__N_1355, PD_out_2, ATR_IN2_2__N_1356, PD_out_3, 
        ATR_IN3_2__N_1357, PD_out_4, ATR_IN4_2__N_1358, PD_out_5, ATR_IN5_2__N_1359, 
        PD_out_6, ATR_IN6_2__N_1360, ATR_IN7_2__N_1361;
    wire [4:0]THO_LATCH;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1510[10:19])
    wire [4:0]STEP3;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1512[10:15])
    
    wire n11811, DB_PARR;
    wire [7:0]ri;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1578[11:13])
    
    wire CGAH_N_1528, n11786, n4430, n11694, n11692, Clk_enable_367, 
        n7695, Clk_enable_549;
    wire [0:0]CNT1_N_558_adj_2427;
    wire [7:0]CNT1;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1682[10:14])
    
    wire CNT_7__N_1133, n4185, n4, n5745, n960, Clk_enable_526, 
        Clk_enable_564, n12275, Clk_enable_513, n12292, Clk_enable_473, 
        Clk_enable_206, Clk_enable_423, Clk_enable_530, n11691, n7934, 
        n4641, Clk_enable_563, n11701, n10, n11772, Clk_enable_185, 
        n11768, n5788, n5786, n10992, Clk_enable_562, Clk_enable_73, 
        n2939, Clk_enable_293, Clk_enable_553, n11762, n10702, n12276, 
        Clk_enable_210, n5755, n11755, Clk_enable_207, n4_adj_2287, 
        PD_out_7, Clk_enable_204, Clk_enable_202, n11753, n11750, 
        n11749, n11748, Clk_enable_208, n11741, n11729, n11724, 
        n10722, n11579;
    
    VLO i1 (.Z(GND_net));
    INV i11193 (.A(MCLK_c), .Z(Clk2_N_17));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(36[7:11])
    PIX_MUX MOD_PIX_MUX (.Clk(Clk), .Clk_enable_562(Clk_enable_562), .Clk_enable_564(Clk_enable_564), 
            .ZCOL({ZCOL}), .THO({THO}), .BGC2({BGC2}), .CLPB_LATCH(CLPB_LATCH), 
            .Clk_enable_185(Clk_enable_185), .STEP3({STEP3[4], Open_0, 
            Open_1, Open_2, Open_3}), .Clk_enable_549(Clk_enable_549), 
            .\THO_LATCH[4] (THO_LATCH[4]), .\R2DB[1] (R2DB[1]), .n10549(n10549), 
            .TH_MUX(TH_MUX), .\CGA[3] (CGA[3]), .\CGA[2] (CGA[2]), .\CGA[1] (CGA[1]), 
            .SPR0HIT_LATCH(SPR0HIT_LATCH), .SPR0_EV(SPR0_EV), .nVIS(nVIS), 
            .n10722(n10722), .n12292(n12292), .n11768(n11768), .CGAH_N_1528(CGAH_N_1528)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(427[9] 441[2])
    TSALL TSALL_INST (.TSALL(GND_net));
    IB A_pad_0 (.I(A[0]), .O(A_c_0));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(44[12:13])
    IB A_pad_1 (.I(A[1]), .O(A_c_1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(44[12:13])
    IB A_pad_2 (.I(A[2]), .O(A_c_2));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(44[12:13])
    IB nDBE_pad (.I(nDBE), .O(nDBE_c));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(43[7:11])
    IB RnW_pad (.I(RnW), .O(RnW_c));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(42[7:10])
    IB PALSEL_pad_0 (.I(PALSEL[0]), .O(PALSEL_c_0));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(41[12:18])
    IB PALSEL_pad_1 (.I(PALSEL[1]), .O(PALSEL_c_1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(41[12:18])
    IB PALSEL_pad_2 (.I(PALSEL[2]), .O(PALSEL_c_2));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(41[12:18])
    IB nRES_pad (.I(nRES), .O(nRES_c));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(40[7:11])
    IB DENDY_IN_pad (.I(DENDY_IN), .O(DENDY_IN_c));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(39[7:15])
    IB MODE_IN_pad (.I(MODE_IN), .O(MODE_IN_c));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(38[7:14])
    IB MCLK_pad (.I(MCLK), .O(MCLK_c));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(36[7:11])
    OB SYNC_pad (.I(SYNC_c), .O(SYNC));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(63[8:12])
    OB nRD_pad (.I(nRD_c), .O(nRD));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(62[8:11])
    OB nWR_pad (.I(nWR_c), .O(nWR));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(61[8:11])
    OB ALE_pad (.I(ALE_c), .O(ALE));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(60[8:11])
    OB INT_pad (.I(INT_c), .O(INT));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(59[8:11])
    OB PA13_pad (.I(PA13_c_13), .O(PA13));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(58[8:12])
    OB PA12_pad (.I(PA12_c_12), .O(PA12));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(57[8:12])
    OB PA11_pad (.I(PA11_c_11), .O(PA11));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(56[8:12])
    OB PA10_pad (.I(PA10_c_10), .O(PA10));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(55[8:12])
    OB PA9_pad (.I(PA9_c_9), .O(PA9));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(54[8:11])
    OB PA8_pad (.I(PA8_c_8), .O(PA8));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(53[8:11])
    OB RGB_pad_0 (.I(RGB_c_0), .O(RGB[0]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_1 (.I(RGB_c_1), .O(RGB[1]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_2 (.I(RGB_c_2), .O(RGB[2]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_3 (.I(RGB_c_3), .O(RGB[3]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_4 (.I(RGB_c_4), .O(RGB[4]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_5 (.I(RGB_c_5), .O(RGB[5]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_6 (.I(RGB_c_6), .O(RGB[6]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_7 (.I(RGB_c_7), .O(RGB[7]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_8 (.I(RGB_c_8), .O(RGB[8]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_9 (.I(RGB_c_9), .O(RGB[9]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_10 (.I(RGB_c_10), .O(RGB[10]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_11 (.I(RGB_c_11), .O(RGB[11]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_12 (.I(RGB_c_12), .O(RGB[12]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_13 (.I(RGB_c_13), .O(RGB[13]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    PALETTE MOD_PALETTE (.Clk(Clk), .GND_net(GND_net), .n11798(n11798), 
            .n960(n960), .Clk_enable_564(Clk_enable_564), .nPICTURE(nPICTURE), 
            .\EMPH[2] (EMPH[2]), .\ri[7] (ri[7]), .Clk_enable_73(Clk_enable_73), 
            .n7934(n7934), .RGB_c_12(RGB_c_12), .RGB_c_13(RGB_c_13), .n11839(n11839), 
            .EMP_G(EMP_G), .EMP_R(EMP_R), .B_W(B_W), .Clk_enable_202(Clk_enable_202), 
            .Clk_enable_204(Clk_enable_204), .Clk_enable_206(Clk_enable_206), 
            .Clk_enable_207(Clk_enable_207), .Clk_enable_210(Clk_enable_210), 
            .RGB_c_17(RGB_c_17), .RGB_c_18(RGB_c_18), .RGB_c_19(RGB_c_19), 
            .RGB_c_20(RGB_c_20), .RGB_c_21(RGB_c_21), .RGB_c_22(RGB_c_22), 
            .RGB_c_14(RGB_c_14), .RGB_c_15(RGB_c_15), .RGB_c_16(RGB_c_16), 
            .RGB_c_23(RGB_c_23), .TH_MUX(TH_MUX), .DB_PARR(DB_PARR), .CGAH_N_1528(CGAH_N_1528), 
            .\STEP3[4] (STEP3[4]), .\THO_LATCH[4] (THO_LATCH[4]), .\EMPH[0] (EMPH[0]), 
            .RGB_c_0(RGB_c_0), .RGB_c_1(RGB_c_1), .RGB_c_2(RGB_c_2), .RGB_c_3(RGB_c_3), 
            .R7(R7), .DBIN({DBIN}), .n83({n84, n85, n86, n87, n88, 
            n89, n90, n91}), .RGB_c_4(RGB_c_4), .RGB_c_5(RGB_c_5), 
            .RGB_c_6(RGB_c_6), .RGB_c_7(RGB_c_7), .RGB_c_8(RGB_c_8), .RGB_c_9(RGB_c_9), 
            .RGB_c_10(RGB_c_10), .RGB_c_11(RGB_c_11), .PALSEL_c_2(PALSEL_c_2), 
            .PALSEL_c_1(PALSEL_c_1), .PALSEL_c_0(PALSEL_c_0), .\CGA[3] (CGA[3]), 
            .\CGA[2] (CGA[2]), .\CGA[1] (CGA[1]), .n11768(n11768)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(444[9] 460[2])
    OB RGB_pad_14 (.I(RGB_c_14), .O(RGB[14]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_15 (.I(RGB_c_15), .O(RGB[15]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_16 (.I(RGB_c_16), .O(RGB[16]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_17 (.I(RGB_c_17), .O(RGB[17]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_18 (.I(RGB_c_18), .O(RGB[18]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_19 (.I(RGB_c_19), .O(RGB[19]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_20 (.I(RGB_c_20), .O(RGB[20]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_21 (.I(RGB_c_21), .O(RGB[21]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_22 (.I(RGB_c_22), .O(RGB[22]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB RGB_pad_23 (.I(RGB_c_23), .O(RGB[23]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(52[14:17])
    OB SUBCLK_pad (.I(SUBCLK_c), .O(SUBCLK));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(50[8:14])
    OB PCLK_pad (.I(n12292), .O(PCLK));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(49[8:12])
    BB DB_pad_0 (.I(D[0]), .T(R_EN), .B(DB[0]), .O(DB_out_0));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(645[8:10])
    BB DB_pad_1 (.I(D[1]), .T(R_EN), .B(DB[1]), .O(DB_out_1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(645[8:10])
    BB DB_pad_2 (.I(D[2]), .T(R_EN), .B(DB[2]), .O(DB_out_2));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(645[8:10])
    BB DB_pad_3 (.I(D[3]), .T(R_EN), .B(DB[3]), .O(DB_out_3));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(645[8:10])
    BB DB_pad_4 (.I(D[4]), .T(R_EN), .B(DB[4]), .O(DB_out_4));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(645[8:10])
    BB DB_pad_5 (.I(D[5]), .T(R_EN), .B(DB[5]), .O(DB_out_5));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(645[8:10])
    BB DB_pad_6 (.I(D[6]), .T(R_EN), .B(DB[6]), .O(DB_out_6));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(645[8:10])
    BB DB_pad_7 (.I(D[7]), .T(R_EN), .B(DB[7]), .O(DB_out_7));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(645[8:10])
    BB PD_pad_0 (.I(PAD[0]), .T(n11750), .B(PD[0]), .O(PD_out_0));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(144[63:65])
    BB PD_pad_1 (.I(PAD[1]), .T(n11750), .B(PD[1]), .O(PD_out_1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(144[63:65])
    BB PD_pad_2 (.I(PAD[2]), .T(n11750), .B(PD[2]), .O(PD_out_2));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(144[63:65])
    BB PD_pad_3 (.I(PAD[3]), .T(n11750), .B(PD[3]), .O(PD_out_3));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(144[63:65])
    BB PD_pad_4 (.I(PAD[4]), .T(n11750), .B(PD[4]), .O(PD_out_4));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(144[63:65])
    BB PD_pad_5 (.I(PAD[5]), .T(n11750), .B(PD[5]), .O(PD_out_5));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(144[63:65])
    BB PD_pad_6 (.I(PAD[6]), .T(n11750), .B(PD[6]), .O(PD_out_6));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(144[63:65])
    BB PD_pad_7 (.I(PAD[7]), .T(n11750), .B(PD[7]), .O(PD_out_7));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(144[63:65])
    GSR GSR_INST (.GSR(nRES_c));
    OBJ_FIFO MOD_OBJ_FIFO (.n12292(n12292), .SEL_LATCH({SEL_LATCH}), .OB({OB}), 
            .Clk(Clk), .ATR_IN0_2__N_1353(ATR_IN0_2__N_1353), .CLIPOR(CLIPOR), 
            .PD_out_4(PD_out_4), .PD_out_3(PD_out_3), .SPR0HIT_LATCH(SPR0HIT_LATCH), 
            .Clk_enable_564(Clk_enable_564), .Clk_enable_562(Clk_enable_562), 
            .SH2(SH2), .SH2_N_1365(SH2_N_1365), .ATR_IN1_2__N_1355(ATR_IN1_2__N_1355), 
            .ATR_IN2_2__N_1356(ATR_IN2_2__N_1356), .ATR_IN3_2__N_1357(ATR_IN3_2__N_1357), 
            .ATR_IN4_2__N_1358(ATR_IN4_2__N_1358), .ATR_IN5_2__N_1359(ATR_IN5_2__N_1359), 
            .ATR_IN6_2__N_1360(ATR_IN6_2__N_1360), .ATR_IN7_2__N_1361(ATR_IN7_2__N_1361), 
            .O_HPOS(O_HPOS), .Clk_enable_185(Clk_enable_185), .SH3_N_1374(SH3_N_1374), 
            .SH5_N_1378(SH5_N_1378), .SH7_N_1383(SH7_N_1383), .Clk_enable_208(Clk_enable_208), 
            .PD_FIFO(PD_FIFO), .Clk_enable_530(Clk_enable_530), .Clk_enable_549(Clk_enable_549), 
            .Clk_enable_423(Clk_enable_423), .PD_out_0(PD_out_0), .PD_out_7(PD_out_7), 
            .\Hnn[5] (Hnn[5]), .\Hnn[4] (Hnn[4]), .\Hnn[3] (Hnn[3]), .ZCOL({ZCOL}), 
            .Clk_enable_526(Clk_enable_526), .n5788(n5788), .PD_out_6(PD_out_6), 
            .PD_out_1(PD_out_1), .PD_out_5(PD_out_5), .PD_out_2(PD_out_2), 
            .n12276(n12276), .nVIS(nVIS), .Clk_enable_473(Clk_enable_473)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(409[10] 424[2])
    PUR PUR_INST (.PUR(VCC_net));
    defparam PUR_INST.RST_PULSE = 1;
    LUT4 MODE_IN_I_0_2_lut_rep_363 (.A(MODE_IN_c), .B(DENDY_IN_c), .Z(n11839)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(142[16:37])
    defparam MODE_IN_I_0_2_lut_rep_363.init = 16'h8888;
    LUT4 i1_4_lut_4_lut_2_lut (.A(DENDY_IN_c), .B(n11755), .Z(n4_adj_2287)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(142[16:37])
    defparam i1_4_lut_4_lut_2_lut.init = 16'h2222;
    LUT4 EMP_R_I_0_70_3_lut_4_lut (.A(MODE_IN_c), .B(DENDY_IN_c), .C(EMP_G), 
         .D(EMP_R), .Z(EMPH[0])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(142[16:37])
    defparam EMP_R_I_0_70_3_lut_4_lut.init = 16'hf870;
    LUT4 DIV_1__I_0_2_lut_3_lut (.A(MODE_IN_c), .B(DENDY_IN_c), .C(DIV[1]), 
         .Z(DIV_2__N_3)) /* synthesis lut_function=(!(A (B+!(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(142[16:37])
    defparam DIV_1__I_0_2_lut_3_lut.init = 16'h7070;
    LUT4 EMP_G_I_0_71_3_lut_rep_322_4_lut (.A(MODE_IN_c), .B(DENDY_IN_c), 
         .C(EMP_R), .D(EMP_G), .Z(n11798)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(142[16:37])
    defparam EMP_G_I_0_71_3_lut_rep_322_4_lut.init = 16'hf870;
    TIMING_GENERATOR MOD_TIMING_GENERATOR (.SYNC_c(SYNC_c), .Hnn({Hnn[5:3], 
            Open_4, Open_5, Hnn[0]}), .Clk(Clk), .Clk_enable_513(Clk_enable_513), 
            .\Hn[0] (Hn[0]), .Clk_enable_562(Clk_enable_562), .Vo({Vo}), 
            .n11839(n11839), .RC(RC), .RESCL(RESCL), .n12275(n12275), 
            .n11753(n11753), .E_EV(E_EV), .Clk_enable_564(Clk_enable_564), 
            .\H[8] (H[8]), .n11800(n11800), .I_OAM2(I_OAM2), .VBL_EN(VBL_EN), 
            .INT_c(INT_c), .THO({THO}), .\PAMUX_7__N_852[1] (PAMUX_7__N_852[1]), 
            .PAR_O(PAR_O), .\PAMUX_7__N_852[2] (PAMUX_7__N_852[2]), .\TVO[2] (TVO[2]), 
            .\PAMUX_7__N_852[3] (PAMUX_7__N_852[3]), .\TVO[3] (TVO[3]), 
            .\PAMUX_7__N_852[4] (PAMUX_7__N_852[4]), .\TVO[0] (TVO[0]), 
            .\TVO[4] (TVO[4]), .\PAMUX_7__N_852[5] (PAMUX_7__N_852[5]), 
            .\PAMUX_7__N_852[0] (PAMUX_7__N_852[0]), .n11840(n11840), .BLNK_FF(BLNK_FF), 
            .TVO1(TVO1), .n10702(n10702), .TVZB(TVZB), .TVZ(TVZ), .Clk_enable_83(Clk_enable_83), 
            .nRD_c(nRD_c), .n11750(n11750), .NTV_IN(NTV_IN), .NTVDO(NTVDO), 
            .n11724(n11724), .n4185(n4185), .n11694(n11694), .n11691(n11691), 
            .\W4Q[4] (W4Q[4]), .\W4Q[2] (W4Q[2]), .OAMQ_7__N_1034(OAMQ_7__N_1034), 
            .nVIS(nVIS), .OAP_N_1084(OAP_N_1084), .n12292(n12292), .\Hn[2] (Hn[2]), 
            .n5786(n5786), .n11816(n11816), .n10992(n10992), .I1_32(I1_32), 
            .n11729(n11729), .CNT1_N_558({CNT1_N_558_adj_2427}), .FTA_OUT(FTA_OUT), 
            .NFO_OUT(NFO_OUT), .n11811(n11811), .Clk_enable_293(Clk_enable_293), 
            .Clk_enable_549(Clk_enable_549), .F_NT(F_NT), .RESCL_IN(RESCL_IN), 
            .HC(HC), .Clk_enable_185(Clk_enable_185), .S_EV(S_EV), .n11749(n11749), 
            .n11797(n11797), .n11701(n11701), .CLIP_OUT(CLIP_OUT), .O_HPOS(O_HPOS), 
            .BGCLIP(BGCLIP), .CLIP_B_N_240(CLIP_B_N_240), .OVZ(OVZ), .SPR_OV(SPR_OV), 
            .n11692(n11692), .nEVAL(nEVAL), .OMFG(OMFG), .n11755(n11755), 
            .nPICTURE(nPICTURE), .OMSTEP_1__N_1046(OMSTEP_1__N_1046), .Clk_enable_423(Clk_enable_423), 
            .n11794(n11794), .N_HB(N_HB), .\Hn[1] (Hn[1]), .SH2_N_1365(SH2_N_1365), 
            .SH5_N_1378(SH5_N_1378), .SH3_N_1374(SH3_N_1374), .SH7_N_1383(SH7_N_1383), 
            .n10784(n10784), .\R2DB[0] (R2DB[0]), .n4(n4), .n4641(n4641), 
            .R2(R2), .n10489(n10489), .OMV_LATCH(OMV_LATCH), .n11830(n11830), 
            .Clk_enable_526(Clk_enable_526), .n4_adj_43(n4_adj_2287), .DENDY_IN_c(DENDY_IN_c), 
            .nRES_c(nRES_c), .\R2DB[2] (R2DB[2]), .Clk_enable_553(Clk_enable_553), 
            .Clk_enable_530(Clk_enable_530), .Vo_7__N_205(Vo_7__N_205), 
            .Clk_enable_367(Clk_enable_367), .H_8__N_226(H_8__N_226)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(242[18] 283[2])
    OBJ_EVAL MOD_OBJ_EVAL (.Clk(Clk), .Clk_enable_562(Clk_enable_562), .OVZ(OVZ), 
            .Clk_enable_120(Clk_enable_120), .n11694(n11694), .SPR0_EV1(SPR0_EV1), 
            .SPR0_EV1_N_977(SPR0_EV1_N_977), .SPR0_EV(SPR0_EV), .n2939(n2939), 
            .Clk_enable_564(Clk_enable_564), .Clk_enable_549(Clk_enable_549), 
            .Clk_enable_185(Clk_enable_185), .TAL_LATCH_N_883(TAL_LATCH_N_883), 
            .Vo({Vo}), .OB_R({OB_R}), .GND_net(GND_net), .OV({OV}), 
            .n12292(n12292), .n4185(n4185), .O8_16(O8_16), .PD_FIFO(PD_FIFO), 
            .Clk_enable_563(Clk_enable_563), .n11800(n11800), .n7695(n7695)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(365[10] 383[2])
    LOCAL_BUS_CONTROL MOD_LOCAL_BUS_CONTROL (.n11577(n11577), .Clk(Clk), 
            .Clk_enable_564(Clk_enable_564), .Clk_enable_83(Clk_enable_83), 
            .DB_PARR(DB_PARR), .n12292(n12292), .n11797(n11797), .THSTEP_N_916(THSTEP_N_916), 
            .E_EV(E_EV), .n11709(n11709), .n11816(n11816), .R7(R7), 
            .n12276(n12276), .Clk_enable_549(Clk_enable_549), .n11800(n11800), 
            .W7(W7), .PAMUX_7__N_844({PAMUX_7__N_844}), .DBIN({DBIN}), 
            .\PAMUX[7] (PAMUX[7]), .\TP[3] (TP[3]), .\Hn[1] (Hn[1]), .\TP[2] (TP[2]), 
            .TH_MUX(TH_MUX), .nWR_c(nWR_c), .\PAMUX[6] (PAMUX[6]), .\TP[1] (TP[1]), 
            .\TP[4] (TP[4]), .\TP[0] (TP[0]), .n11786(n11786), .RC(RC), 
            .Clk_enable_87(Clk_enable_87), .n11748(n11748), .Clk_enable_513(Clk_enable_513), 
            .Clk_enable_423(Clk_enable_423), .OMFG_LATCH(OMFG_LATCH), .OVF_LATCH(OVF_LATCH), 
            .n4(n4), .XRB_N_599(XRB_N_599), .PA11_c_11(PA11_c_11), .PA12_c_12(PA12_c_12), 
            .PA8_c_8(PA8_c_8), .PA13_c_13(PA13_c_13), .PA9_c_9(PA9_c_9), 
            .PA10_c_10(PA10_c_10), .n11579(n11579), .n10784(n10784), .ALE_c(ALE_c)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(286[19] 304[2])
    REG2000_2001 MOD_REG2000_2001 (.BGCLIP(BGCLIP), .Clk(Clk), .EMP_R(EMP_R), 
            .EMP_G(EMP_G), .Clk_enable_562(Clk_enable_562), .nVIS(nVIS), 
            .CLIP_B_N_240(CLIP_B_N_240), .CLIPOR(CLIPOR), .n11839(n11839), 
            .\ri[7] (ri[7]), .n7934(n7934), .I1_32(I1_32), .O8_16(O8_16), 
            .OBSEL(OBSEL), .CLIP_OUT(CLIP_OUT), .BGSEL(BGSEL), .W1(W1), 
            .W0(W0), .RC(RC), .DBIN({DBIN}), .n11840(n11840), .BLNK_FF(BLNK_FF), 
            .n11800(n11800), .\H[8] (H[8]), .n11753(n11753), .N_HB(N_HB), 
            .SC_CNT(SC_CNT), .\Hn[2] (Hn[2]), .n11762(n11762), .n11772(n11772), 
            .n11577(n11577), .n11579(n11579), .\FVO[1] (FVO[1]), .NBFVO1(NBFVO1), 
            .n11749(n11749), .n12292(n12292), .OB2_7__N_1036(OB2_7__N_1036), 
            .nCLPB_N_123(nCLPB_N_123), .\EMPH[2] (EMPH[2]), .VBL_EN(VBL_EN), 
            .B_W(B_W), .n960(n960)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(197[14] 220[2])
    LUT4 m1_lut (.Z(n12276)) /* synthesis lut_function=1, syn_instantiated=1 */ ;
    defparam m1_lut.init = 16'hffff;
    PLL MOD_PLL (.MCLK_c(MCLK_c), .Clk(Clk), .GND_net(GND_net)) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(158[5] 161[2])
    REGISTER_SELECT MOD_REGISTER_SELECT (.Clk(Clk), .A_c_0(A_c_0), .RnWR(RnWR), 
            .RnW_c(RnW_c), .nDBER(nDBER), .nDBE_c(nDBE_c), .W5_1(W5_1), 
            .W5_2(W5_2), .W6_1(W6_1), .W6_2(W6_2), .A_c_2(A_c_2), .A_c_1(A_c_1), 
            .DBIN({DBIN}), .DB_out_0(DB_out_0), .R2(R2), .W0(W0), .W1(W1), 
            .W3(W3), .R4(R4), .W4(W4), .R7(R7), .W7(W7), .Clk_enable_514(Clk_enable_514), 
            .RC(RC), .TH_4__N_769(TH_4__N_769), .DB_out_1(DB_out_1), .DB_out_2(DB_out_2), 
            .DB_out_3(DB_out_3), .DB_out_4(DB_out_4), .DB_out_5(DB_out_5), 
            .DB_out_6(DB_out_6), .DB_out_7(DB_out_7), .Clk_enable_553(Clk_enable_553)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(174[17] 194[2])
    PAR_GEN MOD_PAR_GEN (.PAR_O(PAR_O), .O8_16(O8_16), .\FVO[1] (FVO[1]), 
            .Clk(Clk), .RC(RC), .\PAD[0] (PAD[0]), .Clk_enable_564(Clk_enable_564), 
            .W6_1(W6_1), .W5_2(W5_2), .DBIN({DBIN}), .Clk_enable_562(Clk_enable_562), 
            .OV({OV}), .OB({OB}), .E_EV(E_EV), .PD_out_0(PD_out_0), 
            .TP({Open_6, Open_7, Open_8, Open_9, Open_10, Open_11, 
            Open_12, Open_13, Open_14, Open_15, Open_16, TP[0]}), 
            .n11709(n11709), .TAL_LATCH_N_883(TAL_LATCH_N_883), .I1_32(I1_32), 
            .n11800(n11800), .THO({THO}), .TVZ(TVZ), .Clk_enable_208(Clk_enable_208), 
            .SC_CNT(SC_CNT), .Clk_enable_185(Clk_enable_185), .\TP[4] (TP[4]), 
            .\TP[3] (TP[3]), .\TP[2] (TP[2]), .\TP[1] (TP[1]), .PD_out_7(PD_out_7), 
            .PD_out_6(PD_out_6), .PD_out_5(PD_out_5), .PD_out_4(PD_out_4), 
            .PD_out_3(PD_out_3), .PD_out_2(PD_out_2), .PD_out_1(PD_out_1), 
            .Clk_enable_549(Clk_enable_549), .W0(W0), .RESCL(RESCL), .NTVDO(NTVDO), 
            .NTV_IN(NTV_IN), .W6_2(W6_2), .Clk_enable_530(Clk_enable_530), 
            .n12292(n12292), .PA12_c_12(PA12_c_12), .PA11_c_11(PA11_c_11), 
            .PA10_c_10(PA10_c_10), .PA9_c_9(PA9_c_9), .Clk_enable_367(Clk_enable_367), 
            .PA8_c_8(PA8_c_8), .\PAD[7] (PAD[7]), .\PAMUX[7] (PAMUX[7]), 
            .\PAD[6] (PAD[6]), .\PAMUX[6] (PAMUX[6]), .\PAD[5] (PAD[5]), 
            .\PAD[4] (PAD[4]), .n11748(n11748), .\PAD[3] (PAD[3]), .\PAD[2] (PAD[2]), 
            .\PAD[1] (PAD[1]), .F_NT(F_NT), .\Hnn[0] (Hnn[0]), .n10702(n10702), 
            .TVO1(TVO1), .Clk_enable_514(Clk_enable_514), .\TVO[2] (TVO[2]), 
            .\TVO[4] (TVO[4]), .\TVO[0] (TVO[0]), .\TVO[3] (TVO[3]), .SH2(SH2), 
            .SEL_LATCH({SEL_LATCH}), .ATR_IN1_2__N_1355(ATR_IN1_2__N_1355), 
            .ATR_IN0_2__N_1353(ATR_IN0_2__N_1353), .n11762(n11762), .n11794(n11794), 
            .ATR_IN2_2__N_1356(ATR_IN2_2__N_1356), .ATR_IN3_2__N_1357(ATR_IN3_2__N_1357), 
            .ATR_IN4_2__N_1358(ATR_IN4_2__N_1358), .ATR_IN5_2__N_1359(ATR_IN5_2__N_1359), 
            .ATR_IN6_2__N_1360(ATR_IN6_2__N_1360), .ATR_IN7_2__N_1361(ATR_IN7_2__N_1361), 
            .W5_1(W5_1), .PAMUX_7__N_844({PAMUX_7__N_844}), .TH_4__N_769(TH_4__N_769), 
            .\Hn[2] (Hn[2]), .\PAMUX_7__N_852[1] (PAMUX_7__N_852[1]), .n10992(n10992), 
            .\PAMUX_7__N_852[2] (PAMUX_7__N_852[2]), .\PAMUX_7__N_852[3] (PAMUX_7__N_852[3]), 
            .\PAMUX_7__N_852[4] (PAMUX_7__N_852[4]), .\PAMUX_7__N_852[5] (PAMUX_7__N_852[5]), 
            .\PAMUX_7__N_852[0] (PAMUX_7__N_852[0]), .PA13_c_13(PA13_c_13), 
            .n5786(n5786), .NBFVO1(NBFVO1), .BGSEL(BGSEL), .OBSEL(OBSEL), 
            .Clk_enable_513(Clk_enable_513), .n11786(n11786), .THSTEP_N_916(THSTEP_N_916), 
            .n11729(n11729), .n11772(n11772), .CNT1_N_558({CNT1_N_558_adj_2427}), 
            .TVZB(TVZB), .n11724(n11724)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(327[9] 362[2])
    OAM MOD_OAM (.ORES_LATCH(ORES_LATCH), .Clk(Clk), .Clk_enable_562(Clk_enable_562), 
        .nEVAL(nEVAL), .OVF_LATCH(OVF_LATCH), .OMFG_LATCH(OMFG_LATCH), 
        .OMFG(OMFG), .OMV_LATCH(OMV_LATCH), .OB2_7__N_1036(OB2_7__N_1036), 
        .OB({OB}), .Clk_enable_564(Clk_enable_564), .OSTEP({Open_17, Open_18, 
        OSTEP[0]}), .n11692(n11692), .I_OAM2(I_OAM2), .\W4Q[4] (W4Q[4]), 
        .\W4Q[2] (W4Q[2]), .OMSTEP_1__N_1046(OMSTEP_1__N_1046), .PAR_O(PAR_O), 
        .\Hn[0] (Hn[0]), .\Hn[2] (Hn[2]), .n4430(n4430), .\Hnn[0] (Hnn[0]), 
        .n10(n10), .n12292(n12292), .\R2DB[0] (R2DB[0]), .n4641(n4641), 
        .SPR_OV(SPR_OV), .n10489(n10489), .OAMCTR2(OAMCTR2), .n11741(n11741), 
        .W4(W4), .n11830(n11830), .W3(W3), .Clk_enable_563(Clk_enable_563), 
        .n11800(n11800), .OAP_N_1084(OAP_N_1084), .\OAM1ADR[0] (OAM1ADR[0]), 
        .n5755(n5755), .GND_net(GND_net), .OAMQ_7__N_1034(OAMQ_7__N_1034), 
        .DBIN({DBIN}), .n11691(n11691), .CNT_7__N_1133(CNT_7__N_1133), 
        .n5745(n5745), .n7695(n7695), .\CNT1[0] (CNT1[0]), .Clk_enable_423(Clk_enable_423), 
        .OAM2STEP_N_1097(OAM2STEP_N_1097), .ORES(ORES), .Clk_enable_185(Clk_enable_185), 
        .Clk_enable_530(Clk_enable_530)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(386[5] 406[2])
    READBUSMUX MOD_READBUSMUX (.OB_R({OB_R}), .Clk(Clk), .Clk_enable_367(Clk_enable_367), 
            .OB({OB}), .Clk_enable_87(Clk_enable_87), .RC(RC), .PD_out_0(PD_out_0), 
            .Clk_enable_513(Clk_enable_513), .R2(R2), .R7(R7), .R4(R4), 
            .Clk_enable_564(Clk_enable_564), .Clk_enable_83(Clk_enable_83), 
            .PD_out_7(PD_out_7), .PD_out_6(PD_out_6), .PD_out_5(PD_out_5), 
            .PD_out_4(PD_out_4), .PD_out_3(PD_out_3), .PD_out_2(PD_out_2), 
            .PD_out_1(PD_out_1), .DBIN({DBIN}), .D({D}), .RnWR(RnWR), 
            .nDBER(nDBER), .R_EN(R_EN), .XRB_N_599(XRB_N_599), .n83({n84, 
            n85, n86, n87, n88, n89, n90, n91}), .R2DB({R2DB})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(223[12] 239[2])
    CLK_DIV MOD_CLK_DIV (.MCLK_c(MCLK_c), .SUBCLK_c(SUBCLK_c), .Clk2_N_17(Clk2_N_17), 
            .DIV_2__N_3(DIV_2__N_3), .n11839(n11839), .\DIV[1] (DIV[1]), 
            .Clk_enable_206(Clk_enable_206), .Clk_enable_207(Clk_enable_207), 
            .Clk_enable_210(Clk_enable_210), .Clk_enable_73(Clk_enable_73), 
            .Clk_enable_562(Clk_enable_562), .Clk_enable_185(Clk_enable_185), 
            .Clk_enable_530(Clk_enable_530), .Clk_enable_423(Clk_enable_423), 
            .Clk_enable_473(Clk_enable_473), .n12292(n12292), .Clk_enable_513(Clk_enable_513), 
            .Clk_enable_564(Clk_enable_564), .Clk_enable_549(Clk_enable_549), 
            .Clk_enable_367(Clk_enable_367), .Clk_enable_526(Clk_enable_526), 
            .SPR_OV(SPR_OV), .OAMCTR2(OAMCTR2), .nVIS(nVIS), .n11800(n11800), 
            .n10(n10), .HC(HC), .RESCL_IN(RESCL_IN), .Vo_7__N_205(Vo_7__N_205), 
            .nRES_c(nRES_c), .Clk_enable_204(Clk_enable_204), .H_8__N_226(H_8__N_226), 
            .Clk_enable_202(Clk_enable_202), .ORES_LATCH(ORES_LATCH), .n11741(n11741), 
            .\Hnn[0] (Hnn[0]), .Clk_enable_120(Clk_enable_120), .n10722(n10722), 
            .\R2DB[1] (R2DB[1]), .RESCL(RESCL), .n10549(n10549), .ORES(ORES), 
            .PAR_O(PAR_O), .SPR0_EV1(SPR0_EV1), .SPR0_EV(SPR0_EV), .n2939(n2939), 
            .\Hnn[5] (Hnn[5]), .n5788(n5788), .\OSTEP[0] (OSTEP[0]), .n4430(n4430), 
            .OAM2STEP_N_1097(OAM2STEP_N_1097), .S_EV(S_EV), .SPR0_EV1_N_977(SPR0_EV1_N_977), 
            .\OAM1ADR[0] (OAM1ADR[0]), .\CNT1[0] (CNT1[0]), .n11830(n11830), 
            .n5745(n5745), .NFO_OUT(NFO_OUT), .FTA_OUT(FTA_OUT), .PD_SR(PD_SR), 
            .I_OAM2(I_OAM2), .n5755(n5755), .W3(W3), .CNT_7__N_1133(CNT_7__N_1133), 
            .\Hn[0] (Hn[0]), .n10784(n10784), .F_AT_LATCH(F_AT_LATCH), 
            .PD_SEL(PD_SEL)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(164[9] 171[2])
    BG_COLOR MOD_BG_COLOR (.Clk(Clk), .Clk_enable_367(Clk_enable_367), .Clk_enable_293(Clk_enable_293), 
            .Clk_enable_562(Clk_enable_562), .PD_SR(PD_SR), .PD_out_0(PD_out_0), 
            .Clk_enable_120(Clk_enable_120), .n11811(n11811), .PD_out_7(PD_out_7), 
            .PD_out_6(PD_out_6), .PD_out_5(PD_out_5), .PD_out_4(PD_out_4), 
            .PD_out_3(PD_out_3), .PD_out_2(PD_out_2), .n11797(n11797), 
            .PD_out_1(PD_out_1), .CLPB_LATCH(CLPB_LATCH), .Clk_enable_564(Clk_enable_564), 
            .nCLPB_N_123(nCLPB_N_123), .F_AT_LATCH(F_AT_LATCH), .n11794(n11794), 
            .\THO[1] (THO[1]), .BGC2({BGC2}), .PD_SEL(PD_SEL), .Clk_enable_423(Clk_enable_423), 
            .RC(RC), .\DBIN[0] (DBIN[0]), .Clk_enable_513(Clk_enable_513), 
            .W5_1(W5_1), .\DBIN[1] (DBIN[1]), .\DBIN[2] (DBIN[2]), .n12292(n12292), 
            .NFO_OUT(NFO_OUT), .TVO1(TVO1), .Clk_enable_549(Clk_enable_549), 
            .n11701(n11701)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(307[10] 324[2])
    LUT4 m0_lut (.Z(n12275)) /* synthesis lut_function=0, syn_instantiated=1 */ ;
    defparam m0_lut.init = 16'h0000;
    VHI i11195 (.Z(VCC_net));
    
endmodule
//
// Verilog Description of module PIX_MUX
//

module PIX_MUX (Clk, Clk_enable_562, Clk_enable_564, ZCOL, THO, BGC2, 
            CLPB_LATCH, Clk_enable_185, STEP3, Clk_enable_549, \THO_LATCH[4] , 
            \R2DB[1] , n10549, TH_MUX, \CGA[3] , \CGA[2] , \CGA[1] , 
            SPR0HIT_LATCH, SPR0_EV, nVIS, n10722, n12292, n11768, 
            CGAH_N_1528) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_562;
    input Clk_enable_564;
    input [4:0]ZCOL;
    input [4:0]THO;
    input [3:0]BGC2;
    input CLPB_LATCH;
    input Clk_enable_185;
    output [4:0]STEP3;
    input Clk_enable_549;
    output \THO_LATCH[4] ;
    output \R2DB[1] ;
    input n10549;
    input TH_MUX;
    output \CGA[3] ;
    output \CGA[2] ;
    output \CGA[1] ;
    input SPR0HIT_LATCH;
    input SPR0_EV;
    input nVIS;
    output n10722;
    input n12292;
    output n11768;
    output CGAH_N_1528;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire BGC_LATCH, R2DB6_N_1430;
    wire [4:0]ZCOLN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1509[10:15])
    wire [4:0]THO_LATCH;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1510[10:19])
    wire [3:0]STEP2;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1511[10:15])
    wire [3:0]STEP2_3__N_1419;
    
    wire OCOL_N_1435, ZCOL_LATCH, n11834, OCOLN;
    wire [4:0]STEP3_c;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1512[10:15])
    
    wire n5778;
    
    FD1P3AX BGC_LATCH_46 (.D(R2DB6_N_1430), .SP(Clk_enable_562), .CK(Clk), 
            .Q(BGC_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam BGC_LATCH_46.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i0 (.D(ZCOL[0]), .SP(Clk_enable_564), .CK(Clk), .Q(ZCOLN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i0.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i0 (.D(THO[0]), .SP(Clk_enable_564), .CK(Clk), 
            .Q(THO_LATCH[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i0.GSR = "DISABLED";
    FD1P3AX STEP2_i0_i0 (.D(STEP2_3__N_1419[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(STEP2[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam STEP2_i0_i0.GSR = "DISABLED";
    LUT4 mux_25_i4_4_lut (.A(ZCOLN[3]), .B(BGC2[3]), .C(OCOL_N_1435), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1419[3])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1530[25:53])
    defparam mux_25_i4_4_lut.init = 16'haca0;
    LUT4 mux_25_i3_4_lut (.A(ZCOLN[2]), .B(BGC2[2]), .C(OCOL_N_1435), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1419[2])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1530[25:53])
    defparam mux_25_i3_4_lut.init = 16'haca0;
    FD1P3AX STEP2_i0_i3 (.D(STEP2_3__N_1419[3]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(STEP2[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam STEP2_i0_i3.GSR = "DISABLED";
    FD1P3AX ZCOL_LATCH_47 (.D(n11834), .SP(Clk_enable_185), .CK(Clk), 
            .Q(ZCOL_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam ZCOL_LATCH_47.GSR = "DISABLED";
    FD1P3AX STEP2_i0_i2 (.D(STEP2_3__N_1419[2]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(STEP2[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam STEP2_i0_i2.GSR = "DISABLED";
    FD1P3AX OCOLN_48 (.D(OCOL_N_1435), .SP(Clk_enable_185), .CK(Clk), 
            .Q(OCOLN));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam OCOLN_48.GSR = "DISABLED";
    FD1P3AX STEP2_i0_i1 (.D(STEP2_3__N_1419[1]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(STEP2[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam STEP2_i0_i1.GSR = "DISABLED";
    FD1P3AX STEP3_i0_i4 (.D(OCOLN), .SP(Clk_enable_549), .CK(Clk), .Q(STEP3[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam STEP3_i0_i4.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i4 (.D(THO[4]), .SP(Clk_enable_549), .CK(Clk), 
            .Q(\THO_LATCH[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i4.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i3 (.D(THO[3]), .SP(Clk_enable_549), .CK(Clk), 
            .Q(THO_LATCH[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i3.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i2 (.D(THO[2]), .SP(Clk_enable_549), .CK(Clk), 
            .Q(THO_LATCH[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i2.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i1 (.D(THO[1]), .SP(Clk_enable_549), .CK(Clk), 
            .Q(THO_LATCH[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i1.GSR = "DISABLED";
    LUT4 mux_25_i2_4_lut (.A(ZCOLN[1]), .B(BGC2[1]), .C(OCOL_N_1435), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1419[1])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1530[25:53])
    defparam mux_25_i2_4_lut.init = 16'haca0;
    FD1P3AX ZCOLN_i0_i4 (.D(ZCOL[4]), .SP(Clk_enable_549), .CK(Clk), .Q(ZCOLN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i4.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i3 (.D(ZCOL[3]), .SP(Clk_enable_549), .CK(Clk), .Q(ZCOLN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i3.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i2 (.D(ZCOL[2]), .SP(Clk_enable_549), .CK(Clk), .Q(ZCOLN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i2.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i1 (.D(ZCOL[1]), .SP(Clk_enable_549), .CK(Clk), .Q(ZCOLN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i1.GSR = "DISABLED";
    FD1S3AX R2DB6_41 (.D(n10549), .CK(Clk), .Q(\R2DB[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam R2DB6_41.GSR = "DISABLED";
    LUT4 STEP3_4__I_0_49_i4_3_lut (.A(STEP3_c[3]), .B(THO_LATCH[3]), .C(TH_MUX), 
         .Z(\CGA[3] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1519[19:55])
    defparam STEP3_4__I_0_49_i4_3_lut.init = 16'hcaca;
    LUT4 STEP3_4__I_0_49_i3_3_lut (.A(STEP3_c[2]), .B(THO_LATCH[2]), .C(TH_MUX), 
         .Z(\CGA[2] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1519[19:55])
    defparam STEP3_4__I_0_49_i3_3_lut.init = 16'hcaca;
    LUT4 STEP3_4__I_0_49_i2_3_lut (.A(STEP3_c[1]), .B(THO_LATCH[1]), .C(TH_MUX), 
         .Z(\CGA[1] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1519[19:55])
    defparam STEP3_4__I_0_49_i2_3_lut.init = 16'hcaca;
    LUT4 ZCOLN_1__I_0_2_lut_rep_358 (.A(ZCOLN[1]), .B(ZCOLN[0]), .Z(n11834)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1516[19:42])
    defparam ZCOLN_1__I_0_2_lut_rep_358.init = 16'heeee;
    LUT4 i10748_3_lut_4_lut (.A(ZCOLN[1]), .B(ZCOLN[0]), .C(R2DB6_N_1430), 
         .D(ZCOLN[4]), .Z(OCOL_N_1435)) /* synthesis lut_function=(!(A (C (D))+!A ((C (D))+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1516[19:42])
    defparam i10748_3_lut_4_lut.init = 16'h0eee;
    LUT4 i1_3_lut (.A(CLPB_LATCH), .B(BGC2[0]), .C(BGC2[1]), .Z(R2DB6_N_1430)) /* synthesis lut_function=(A (B+(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1523[54:73])
    defparam i1_3_lut.init = 16'ha8a8;
    LUT4 mux_25_i1_4_lut (.A(ZCOLN[0]), .B(BGC2[0]), .C(OCOL_N_1435), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1419[0])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1530[25:53])
    defparam mux_25_i1_4_lut.init = 16'haca0;
    LUT4 i2_4_lut (.A(SPR0HIT_LATCH), .B(SPR0_EV), .C(R2DB6_N_1430), .D(nVIS), 
         .Z(n10722)) /* synthesis lut_function=(!((B+((D)+!C))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam i2_4_lut.init = 16'h0020;
    LUT4 i5274_3_lut (.A(n12292), .B(BGC_LATCH), .C(ZCOL_LATCH), .Z(n5778)) /* synthesis lut_function=(!((B+(C))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam i5274_3_lut.init = 16'h0202;
    LUT4 STEP3_4__I_0_49_i1_3_lut_rep_292 (.A(STEP3_c[0]), .B(THO_LATCH[0]), 
         .C(TH_MUX), .Z(n11768)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1519[19:55])
    defparam STEP3_4__I_0_49_i1_3_lut_rep_292.init = 16'hcaca;
    LUT4 CGA_0__I_0_2_lut_4_lut (.A(STEP3_c[0]), .B(THO_LATCH[0]), .C(TH_MUX), 
         .D(\CGA[1] ), .Z(CGAH_N_1528)) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C+(D))+!B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1519[19:55])
    defparam CGA_0__I_0_2_lut_4_lut.init = 16'hffca;
    FD1P3IX STEP3_i0_i1 (.D(STEP2[1]), .SP(Clk_enable_549), .CD(n5778), 
            .CK(Clk), .Q(STEP3_c[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam STEP3_i0_i1.GSR = "DISABLED";
    FD1P3IX STEP3_i0_i2 (.D(STEP2[2]), .SP(Clk_enable_549), .CD(n5778), 
            .CK(Clk), .Q(STEP3_c[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam STEP3_i0_i2.GSR = "DISABLED";
    FD1P3IX STEP3_i0_i3 (.D(STEP2[3]), .SP(Clk_enable_549), .CD(n5778), 
            .CK(Clk), .Q(STEP3_c[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam STEP3_i0_i3.GSR = "DISABLED";
    FD1P3IX STEP3_i0_i0 (.D(STEP2[0]), .SP(Clk_enable_564), .CD(n5778), 
            .CK(Clk), .Q(STEP3_c[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=427, LSE_RLINE=441 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1521[8] 1535[27])
    defparam STEP3_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module TSALL
// module not written out since it is a black-box. 
//

//
// Verilog Description of module PALETTE
//

module PALETTE (Clk, GND_net, n11798, n960, Clk_enable_564, nPICTURE, 
            \EMPH[2] , \ri[7] , Clk_enable_73, n7934, RGB_c_12, RGB_c_13, 
            n11839, EMP_G, EMP_R, B_W, Clk_enable_202, Clk_enable_204, 
            Clk_enable_206, Clk_enable_207, Clk_enable_210, RGB_c_17, 
            RGB_c_18, RGB_c_19, RGB_c_20, RGB_c_21, RGB_c_22, RGB_c_14, 
            RGB_c_15, RGB_c_16, RGB_c_23, TH_MUX, DB_PARR, CGAH_N_1528, 
            \STEP3[4] , \THO_LATCH[4] , \EMPH[0] , RGB_c_0, RGB_c_1, 
            RGB_c_2, RGB_c_3, R7, DBIN, n83, RGB_c_4, RGB_c_5, 
            RGB_c_6, RGB_c_7, RGB_c_8, RGB_c_9, RGB_c_10, RGB_c_11, 
            PALSEL_c_2, PALSEL_c_1, PALSEL_c_0, \CGA[3] , \CGA[2] , 
            \CGA[1] , n11768) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input GND_net;
    input n11798;
    input n960;
    input Clk_enable_564;
    input nPICTURE;
    input \EMPH[2] ;
    output \ri[7] ;
    input Clk_enable_73;
    input n7934;
    output RGB_c_12;
    output RGB_c_13;
    input n11839;
    input EMP_G;
    input EMP_R;
    input B_W;
    input Clk_enable_202;
    input Clk_enable_204;
    input Clk_enable_206;
    input Clk_enable_207;
    input Clk_enable_210;
    output RGB_c_17;
    output RGB_c_18;
    output RGB_c_19;
    output RGB_c_20;
    output RGB_c_21;
    output RGB_c_22;
    output RGB_c_14;
    output RGB_c_15;
    output RGB_c_16;
    output RGB_c_23;
    input TH_MUX;
    input DB_PARR;
    input CGAH_N_1528;
    input \STEP3[4] ;
    input \THO_LATCH[4] ;
    input \EMPH[0] ;
    output RGB_c_0;
    output RGB_c_1;
    output RGB_c_2;
    output RGB_c_3;
    input R7;
    input [7:0]DBIN;
    output [7:0]n83;
    output RGB_c_4;
    output RGB_c_5;
    output RGB_c_6;
    output RGB_c_7;
    output RGB_c_8;
    output RGB_c_9;
    output RGB_c_10;
    output RGB_c_11;
    input PALSEL_c_2;
    input PALSEL_c_1;
    input PALSEL_c_0;
    input \CGA[3] ;
    input \CGA[2] ;
    input \CGA[1] ;
    input n11768;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]ro;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1564[10:12])
    wire [7:0]ro_7__N_1445;
    
    wire n10152;
    wire [7:0]bi;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1578[19:21])
    
    wire n1270, n1269, n10153;
    wire [7:0]ri;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1578[11:13])
    
    wire n3438, n10144;
    wire [7:0]bo_7__N_1502;
    
    wire n10145, n3718, PICTURER, n10168;
    wire [5:0]PIX;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(74[11:14])
    wire [3:0]CN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1568[11:13])
    
    wire n10151, n1272, n1271, PICTURER2;
    wire [7:0]go;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1564[14:16])
    wire [7:0]go_7__N_1453;
    wire [7:0]bo;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1564[18:20])
    wire [7:0]bo_7__N_1461;
    
    wire n10150, n1274, n1273, n10167, n3444, n10143, n10139, 
        n1280, n1279, n10140, n1275, n10166, n3440, n3442, n10165, 
        n3428, n10142, n1276;
    wire [7:0]n971;
    
    wire n11756;
    wire [5:0]C;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1569[11:12])
    
    wire n3719, n1278, n1277, n1282, n1281, n1283, C_5__N_1469;
    wire [4:0]Address;   // d:/ppu_reverse/fpga/ppu_mini/palette_ram.v(13[22:29])
    
    wire n11832, n11765, n10903, n10160;
    wire [7:0]gi;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1578[15:17])
    
    wire n3436, n3432, n3434, n3426, n3430, n3716, n3717, n3714, 
        n3715, n10159, n7928, n10158, n10157, n3624, n10138, n10141, 
        n3720, n1268;
    
    FD1S3AX ro_i1 (.D(ro_7__N_1445[1]), .CK(Clk), .Q(ro[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam ro_i1.GSR = "DISABLED";
    CCU2D add_495_rep_1_7 (.A0(bi[5]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(bi[6]), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n10152), 
          .COUT(n10153), .S0(n1270), .S1(n1269));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_495_rep_1_7.INIT0 = 16'h5555;
    defparam add_495_rep_1_7.INIT1 = 16'h5555;
    defparam add_495_rep_1_7.INJECT1_0 = "NO";
    defparam add_495_rep_1_7.INJECT1_1 = "NO";
    LUT4 mux_505_i2_3_lut (.A(ri[4]), .B(ri[3]), .C(n11798), .Z(n3438)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam mux_505_i2_3_lut.init = 16'h3535;
    CCU2D sub_34_add_2_7 (.A0(bi[5]), .B0(bi[7]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[6]), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n10144), 
          .COUT(n10145), .S0(bo_7__N_1502[5]), .S1(bo_7__N_1502[6]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1629[14:26])
    defparam sub_34_add_2_7.INIT0 = 16'h5999;
    defparam sub_34_add_2_7.INIT1 = 16'h5555;
    defparam sub_34_add_2_7.INJECT1_0 = "NO";
    defparam sub_34_add_2_7.INJECT1_1 = "NO";
    LUT4 i3229_3_lut (.A(n1270), .B(bo_7__N_1502[5]), .C(n960), .Z(n3718)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam i3229_3_lut.init = 16'hacac;
    FD1P3AX PICTURER_48 (.D(nPICTURE), .SP(Clk_enable_564), .CK(Clk), 
            .Q(PICTURER));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam PICTURER_48.GSR = "DISABLED";
    CCU2D add_639_9 (.A0(\EMPH[2] ), .B0(n11798), .C0(ri[6]), .D0(GND_net), 
          .A1(\EMPH[2] ), .B1(n11798), .C1(\ri[7] ), .D1(GND_net), .CIN(n10168), 
          .S0(ro_7__N_1445[6]), .S1(ro_7__N_1445[7]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_639_9.INIT0 = 16'h1e1e;
    defparam add_639_9.INIT1 = 16'h1e1e;
    defparam add_639_9.INJECT1_0 = "NO";
    defparam add_639_9.INJECT1_1 = "NO";
    FD1P3AX PIX_i0_i0 (.D(CN[0]), .SP(Clk_enable_73), .CK(Clk), .Q(PIX[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam PIX_i0_i0.GSR = "DISABLED";
    CCU2D add_495_rep_1_5 (.A0(bi[3]), .B0(bi[6]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[4]), .B1(bi[7]), .C1(GND_net), .D1(GND_net), .CIN(n10151), 
          .COUT(n10152), .S0(n1272), .S1(n1271));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_495_rep_1_5.INIT0 = 16'h5999;
    defparam add_495_rep_1_5.INIT1 = 16'h5999;
    defparam add_495_rep_1_5.INJECT1_0 = "NO";
    defparam add_495_rep_1_5.INJECT1_1 = "NO";
    FD1S3AX ro_i0 (.D(ro_7__N_1445[0]), .CK(Clk), .Q(ro[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam ro_i0.GSR = "DISABLED";
    FD1S3AX PICTURER2_49 (.D(PICTURER), .CK(Clk), .Q(PICTURER2)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam PICTURER2_49.GSR = "DISABLED";
    FD1S3AX go_i0 (.D(go_7__N_1453[0]), .CK(Clk), .Q(go[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam go_i0.GSR = "DISABLED";
    FD1S3AX bo_i0 (.D(bo_7__N_1461[0]), .CK(Clk), .Q(bo[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam bo_i0.GSR = "DISABLED";
    CCU2D add_495_rep_1_3 (.A0(bi[1]), .B0(bi[4]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[2]), .B1(bi[5]), .C1(GND_net), .D1(GND_net), .CIN(n10150), 
          .COUT(n10151), .S0(n1274), .S1(n1273));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_495_rep_1_3.INIT0 = 16'h5999;
    defparam add_495_rep_1_3.INIT1 = 16'h5999;
    defparam add_495_rep_1_3.INJECT1_0 = "NO";
    defparam add_495_rep_1_3.INJECT1_1 = "NO";
    CCU2D add_639_7 (.A0(ri[4]), .B0(n11798), .C0(\EMPH[2] ), .D0(n3444), 
          .A1(ri[5]), .B1(n11798), .C1(\EMPH[2] ), .D1(n7934), .CIN(n10167), 
          .COUT(n10168), .S0(ro_7__N_1445[4]), .S1(ro_7__N_1445[5]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_639_7.INIT0 = 16'h56aa;
    defparam add_639_7.INIT1 = 16'h56aa;
    defparam add_639_7.INJECT1_0 = "NO";
    defparam add_639_7.INJECT1_1 = "NO";
    CCU2D sub_34_add_2_5 (.A0(bi[3]), .B0(bi[5]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[4]), .B1(bi[6]), .C1(GND_net), .D1(GND_net), .CIN(n10143), 
          .COUT(n10144), .S0(bo_7__N_1502[3]), .S1(bo_7__N_1502[4]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1629[14:26])
    defparam sub_34_add_2_5.INIT0 = 16'h5999;
    defparam sub_34_add_2_5.INIT1 = 16'h5999;
    defparam sub_34_add_2_5.INJECT1_0 = "NO";
    defparam sub_34_add_2_5.INJECT1_1 = "NO";
    CCU2D add_495_rep_2_5 (.A0(bo_7__N_1502[3]), .B0(bi[6]), .C0(GND_net), 
          .D0(GND_net), .A1(bo_7__N_1502[4]), .B1(bi[7]), .C1(GND_net), 
          .D1(GND_net), .CIN(n10139), .COUT(n10140), .S0(n1280), .S1(n1279));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_495_rep_2_5.INIT0 = 16'h5999;
    defparam add_495_rep_2_5.INIT1 = 16'h5999;
    defparam add_495_rep_2_5.INJECT1_0 = "NO";
    defparam add_495_rep_2_5.INJECT1_1 = "NO";
    CCU2D add_495_rep_1_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(bi[0]), .B1(bi[3]), .C1(GND_net), .D1(GND_net), .COUT(n10150), 
          .S1(n1275));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_495_rep_1_1.INIT0 = 16'h0000;
    defparam add_495_rep_1_1.INIT1 = 16'h5999;
    defparam add_495_rep_1_1.INJECT1_0 = "NO";
    defparam add_495_rep_1_1.INJECT1_1 = "NO";
    CCU2D add_639_5 (.A0(ri[2]), .B0(n11798), .C0(\EMPH[2] ), .D0(n3440), 
          .A1(ri[3]), .B1(n11798), .C1(\EMPH[2] ), .D1(n3442), .CIN(n10166), 
          .COUT(n10167), .S0(ro_7__N_1445[2]), .S1(ro_7__N_1445[3]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_639_5.INIT0 = 16'h56aa;
    defparam add_639_5.INIT1 = 16'h56aa;
    defparam add_639_5.INJECT1_0 = "NO";
    defparam add_639_5.INJECT1_1 = "NO";
    LUT4 i7259_2_lut (.A(go[4]), .B(PICTURER2), .Z(RGB_c_12)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7259_2_lut.init = 16'h2222;
    LUT4 i7256_2_lut (.A(go[5]), .B(PICTURER2), .Z(RGB_c_13)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7256_2_lut.init = 16'h2222;
    CCU2D add_639_3 (.A0(ri[0]), .B0(n11798), .C0(\EMPH[2] ), .D0(n3428), 
          .A1(ri[1]), .B1(n11798), .C1(\EMPH[2] ), .D1(n3438), .CIN(n10165), 
          .COUT(n10166), .S0(ro_7__N_1445[0]), .S1(ro_7__N_1445[1]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_639_3.INIT0 = 16'h56aa;
    defparam add_639_3.INIT1 = 16'h56aa;
    defparam add_639_3.INJECT1_0 = "NO";
    defparam add_639_3.INJECT1_1 = "NO";
    CCU2D add_639_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(n11839), .B1(EMP_G), .C1(EMP_R), .D1(\EMPH[2] ), .COUT(n10165));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_639_1.INIT0 = 16'hF000;
    defparam add_639_1.INIT1 = 16'h0027;
    defparam add_639_1.INJECT1_0 = "NO";
    defparam add_639_1.INJECT1_1 = "NO";
    CCU2D sub_34_add_2_3 (.A0(bi[1]), .B0(bi[3]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[2]), .B1(bi[4]), .C1(GND_net), .D1(GND_net), .CIN(n10142), 
          .COUT(n10143), .S0(bo_7__N_1502[1]), .S1(bo_7__N_1502[2]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1629[14:26])
    defparam sub_34_add_2_3.INIT0 = 16'h5999;
    defparam sub_34_add_2_3.INIT1 = 16'h5999;
    defparam sub_34_add_2_3.INJECT1_0 = "NO";
    defparam sub_34_add_2_3.INJECT1_1 = "NO";
    FD1S3AX ro_i2 (.D(ro_7__N_1445[2]), .CK(Clk), .Q(ro[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam ro_i2.GSR = "DISABLED";
    LUT4 mux_477_i8_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[7]), .D(n1276), 
         .Z(n971[7])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_477_i8_3_lut_4_lut.init = 16'hfe10;
    LUT4 C_3__I_0_i1_2_lut_4_lut (.A(B_W), .B(nPICTURE), .C(n11756), .D(C[0]), 
         .Z(CN[0])) /* synthesis lut_function=(!(A+!(B (C (D))+!B (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1572[16:45])
    defparam C_3__I_0_i1_2_lut_4_lut.init = 16'h5100;
    LUT4 C_3__I_0_i4_2_lut_4_lut (.A(B_W), .B(nPICTURE), .C(n11756), .D(C[3]), 
         .Z(CN[3])) /* synthesis lut_function=(!(A+!(B (C (D))+!B (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1572[16:45])
    defparam C_3__I_0_i4_2_lut_4_lut.init = 16'h5100;
    LUT4 i3230_3_lut (.A(n1269), .B(bo_7__N_1502[6]), .C(n960), .Z(n3719)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam i3230_3_lut.init = 16'hacac;
    LUT4 C_3__I_0_i3_2_lut_4_lut (.A(B_W), .B(nPICTURE), .C(n11756), .D(C[2]), 
         .Z(CN[2])) /* synthesis lut_function=(!(A+!(B (C (D))+!B (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1572[16:45])
    defparam C_3__I_0_i3_2_lut_4_lut.init = 16'h5100;
    LUT4 mux_477_i6_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[5]), .D(n1278), 
         .Z(n971[5])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_477_i6_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_477_i7_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[6]), .D(n1277), 
         .Z(n971[6])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_477_i7_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_477_i4_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[3]), .D(n1280), 
         .Z(n971[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_477_i4_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_477_i5_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[4]), .D(n1279), 
         .Z(n971[4])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_477_i5_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_477_i2_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[1]), .D(n1282), 
         .Z(n971[1])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_477_i2_3_lut_4_lut.init = 16'hfe10;
    LUT4 C_3__I_0_i2_2_lut_4_lut (.A(B_W), .B(nPICTURE), .C(n11756), .D(C[1]), 
         .Z(CN[1])) /* synthesis lut_function=(!(A+!(B (C (D))+!B (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1572[16:45])
    defparam C_3__I_0_i2_2_lut_4_lut.init = 16'h5100;
    LUT4 mux_477_i3_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[2]), .D(n1281), 
         .Z(n971[2])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_477_i3_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_477_i1_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[0]), .D(n1283), 
         .Z(n971[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_477_i1_3_lut_4_lut.init = 16'hfe10;
    FD1P3AX PIX_i0_i5 (.D(C[5]), .SP(Clk_enable_202), .CK(Clk), .Q(PIX[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam PIX_i0_i5.GSR = "DISABLED";
    FD1P3AX PIX_i0_i4 (.D(C[4]), .SP(Clk_enable_204), .CK(Clk), .Q(PIX[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam PIX_i0_i4.GSR = "DISABLED";
    FD1P3AX PIX_i0_i3 (.D(CN[3]), .SP(Clk_enable_206), .CK(Clk), .Q(PIX[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam PIX_i0_i3.GSR = "DISABLED";
    FD1P3AX PIX_i0_i2 (.D(CN[2]), .SP(Clk_enable_207), .CK(Clk), .Q(PIX[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam PIX_i0_i2.GSR = "DISABLED";
    FD1P3AX PIX_i0_i1 (.D(CN[1]), .SP(Clk_enable_210), .CK(Clk), .Q(PIX[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam PIX_i0_i1.GSR = "DISABLED";
    LUT4 i7246_2_lut (.A(ro[1]), .B(PICTURER2), .Z(RGB_c_17)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7246_2_lut.init = 16'h2222;
    LUT4 i7243_2_lut (.A(ro[2]), .B(PICTURER2), .Z(RGB_c_18)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7243_2_lut.init = 16'h2222;
    LUT4 i7242_2_lut (.A(ro[3]), .B(PICTURER2), .Z(RGB_c_19)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7242_2_lut.init = 16'h2222;
    LUT4 i7241_2_lut (.A(ro[4]), .B(PICTURER2), .Z(RGB_c_20)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7241_2_lut.init = 16'h2222;
    LUT4 i7240_2_lut (.A(ro[5]), .B(PICTURER2), .Z(RGB_c_21)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7240_2_lut.init = 16'h2222;
    LUT4 i7239_2_lut (.A(ro[6]), .B(PICTURER2), .Z(RGB_c_22)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7239_2_lut.init = 16'h2222;
    LUT4 i7253_2_lut (.A(go[6]), .B(PICTURER2), .Z(RGB_c_14)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7253_2_lut.init = 16'h2222;
    LUT4 i7252_2_lut (.A(go[7]), .B(PICTURER2), .Z(RGB_c_15)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7252_2_lut.init = 16'h2222;
    LUT4 i7249_2_lut (.A(ro[0]), .B(PICTURER2), .Z(RGB_c_16)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7249_2_lut.init = 16'h2222;
    LUT4 i7238_2_lut (.A(ro[7]), .B(PICTURER2), .Z(RGB_c_23)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7238_2_lut.init = 16'h2222;
    LUT4 TH_MUX_I_0_2_lut (.A(TH_MUX), .B(DB_PARR), .Z(C_5__N_1469)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1575[47:63])
    defparam TH_MUX_I_0_2_lut.init = 16'h8888;
    LUT4 CGAH_I_0_4_lut (.A(CGAH_N_1528), .B(\STEP3[4] ), .C(\THO_LATCH[4] ), 
         .D(TH_MUX), .Z(Address[4])) /* synthesis lut_function=(A (B (C+!(D))+!B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1567[15:43])
    defparam CGAH_I_0_4_lut.init = 16'ha088;
    LUT4 i1_2_lut_rep_356 (.A(EMP_G), .B(EMP_R), .Z(n11832)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam i1_2_lut_rep_356.init = 16'h8888;
    LUT4 i7544_3_lut_rep_289_4_lut (.A(EMP_G), .B(EMP_R), .C(\EMPH[2] ), 
         .D(\EMPH[0] ), .Z(n11765)) /* synthesis lut_function=(A (B (C (D)+!C !(D))+!B ((D)+!C))+!A ((D)+!C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam i7544_3_lut_rep_289_4_lut.init = 16'hf70f;
    LUT4 i10866_3_lut_4_lut_3_lut (.A(EMP_G), .B(EMP_R), .C(\EMPH[2] ), 
         .Z(n10903)) /* synthesis lut_function=(!(A ((C)+!B)+!A (B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam i10866_3_lut_4_lut_3_lut.init = 16'h1919;
    LUT4 i7233_2_lut (.A(bo[0]), .B(PICTURER2), .Z(RGB_c_0)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7233_2_lut.init = 16'h2222;
    LUT4 i7270_2_lut (.A(bo[1]), .B(PICTURER2), .Z(RGB_c_1)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7270_2_lut.init = 16'h2222;
    FD1S3AX ro_i3 (.D(ro_7__N_1445[3]), .CK(Clk), .Q(ro[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam ro_i3.GSR = "DISABLED";
    FD1S3AX ro_i4 (.D(ro_7__N_1445[4]), .CK(Clk), .Q(ro[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam ro_i4.GSR = "DISABLED";
    FD1S3AX ro_i5 (.D(ro_7__N_1445[5]), .CK(Clk), .Q(ro[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam ro_i5.GSR = "DISABLED";
    FD1S3AX ro_i6 (.D(ro_7__N_1445[6]), .CK(Clk), .Q(ro[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam ro_i6.GSR = "DISABLED";
    FD1S3AX ro_i7 (.D(ro_7__N_1445[7]), .CK(Clk), .Q(ro[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam ro_i7.GSR = "DISABLED";
    FD1S3AX go_i1 (.D(go_7__N_1453[1]), .CK(Clk), .Q(go[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam go_i1.GSR = "DISABLED";
    FD1S3AX go_i2 (.D(go_7__N_1453[2]), .CK(Clk), .Q(go[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam go_i2.GSR = "DISABLED";
    FD1S3AX go_i3 (.D(go_7__N_1453[3]), .CK(Clk), .Q(go[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam go_i3.GSR = "DISABLED";
    FD1S3AX go_i4 (.D(go_7__N_1453[4]), .CK(Clk), .Q(go[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam go_i4.GSR = "DISABLED";
    FD1S3AX go_i5 (.D(go_7__N_1453[5]), .CK(Clk), .Q(go[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam go_i5.GSR = "DISABLED";
    FD1S3AX go_i6 (.D(go_7__N_1453[6]), .CK(Clk), .Q(go[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam go_i6.GSR = "DISABLED";
    FD1S3AX go_i7 (.D(go_7__N_1453[7]), .CK(Clk), .Q(go[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam go_i7.GSR = "DISABLED";
    FD1S3AX bo_i1 (.D(bo_7__N_1461[1]), .CK(Clk), .Q(bo[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam bo_i1.GSR = "DISABLED";
    FD1S3AX bo_i2 (.D(bo_7__N_1461[2]), .CK(Clk), .Q(bo[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam bo_i2.GSR = "DISABLED";
    FD1S3AX bo_i3 (.D(bo_7__N_1461[3]), .CK(Clk), .Q(bo[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam bo_i3.GSR = "DISABLED";
    FD1S3AX bo_i4 (.D(bo_7__N_1461[4]), .CK(Clk), .Q(bo[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam bo_i4.GSR = "DISABLED";
    FD1S3AX bo_i5 (.D(bo_7__N_1461[5]), .CK(Clk), .Q(bo[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam bo_i5.GSR = "DISABLED";
    FD1S3AX bo_i6 (.D(bo_7__N_1461[6]), .CK(Clk), .Q(bo[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam bo_i6.GSR = "DISABLED";
    FD1S3AX bo_i7 (.D(bo_7__N_1461[7]), .CK(Clk), .Q(bo[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=444, LSE_RLINE=460 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam bo_i7.GSR = "DISABLED";
    CCU2D add_642_9 (.A0(\EMPH[0] ), .B0(\EMPH[2] ), .C0(gi[6]), .D0(GND_net), 
          .A1(\EMPH[0] ), .B1(\EMPH[2] ), .C1(gi[7]), .D1(GND_net), 
          .CIN(n10160), .S0(go_7__N_1453[6]), .S1(go_7__N_1453[7]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_642_9.INIT0 = 16'h1e1e;
    defparam add_642_9.INIT1 = 16'h1e1e;
    defparam add_642_9.INJECT1_0 = "NO";
    defparam add_642_9.INJECT1_1 = "NO";
    LUT4 i7269_2_lut (.A(bo[2]), .B(PICTURER2), .Z(RGB_c_2)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7269_2_lut.init = 16'h2222;
    LUT4 i7268_2_lut (.A(bo[3]), .B(PICTURER2), .Z(RGB_c_3)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7268_2_lut.init = 16'h2222;
    LUT4 mux_505_i5_3_lut (.A(\ri[7] ), .B(ri[6]), .C(n11798), .Z(n3444)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam mux_505_i5_3_lut.init = 16'h3535;
    LUT4 mux_506_i5_3_lut (.A(gi[6]), .B(gi[7]), .C(n11765), .Z(n3436)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam mux_506_i5_3_lut.init = 16'h5353;
    LUT4 mux_506_i3_3_lut (.A(gi[4]), .B(gi[5]), .C(n11765), .Z(n3432)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam mux_506_i3_3_lut.init = 16'h5353;
    LUT4 mux_506_i4_3_lut (.A(gi[5]), .B(gi[6]), .C(n11765), .Z(n3434)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam mux_506_i4_3_lut.init = 16'h5353;
    LUT4 mux_506_i1_3_lut (.A(gi[2]), .B(gi[3]), .C(n11765), .Z(n3426)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam mux_506_i1_3_lut.init = 16'h5353;
    LUT4 mux_506_i2_3_lut (.A(gi[3]), .B(gi[4]), .C(n11765), .Z(n3430)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam mux_506_i2_3_lut.init = 16'h5353;
    LUT4 i3227_3_lut (.A(n1272), .B(bo_7__N_1502[3]), .C(n960), .Z(n3716)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam i3227_3_lut.init = 16'hacac;
    LUT4 mux_505_i3_3_lut (.A(ri[5]), .B(ri[4]), .C(n11798), .Z(n3440)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam mux_505_i3_3_lut.init = 16'h3535;
    LUT4 mux_505_i4_3_lut (.A(ri[6]), .B(ri[5]), .C(n11798), .Z(n3442)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam mux_505_i4_3_lut.init = 16'h3535;
    LUT4 i3228_3_lut (.A(n1271), .B(bo_7__N_1502[4]), .C(n960), .Z(n3717)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam i3228_3_lut.init = 16'hacac;
    LUT4 i3225_3_lut (.A(n1274), .B(bo_7__N_1502[1]), .C(n960), .Z(n3714)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam i3225_3_lut.init = 16'hacac;
    LUT4 i3226_3_lut (.A(n1273), .B(bo_7__N_1502[2]), .C(n960), .Z(n3715)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam i3226_3_lut.init = 16'hacac;
    LUT4 R7_I_0_2_lut_rep_280 (.A(R7), .B(TH_MUX), .Z(n11756)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1573[15:26])
    defparam R7_I_0_2_lut_rep_280.init = 16'h8888;
    LUT4 and_36_i8_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(DBIN[7]), .Z(n83[7])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1573[15:26])
    defparam and_36_i8_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i1_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[0]), .Z(n83[0])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1573[15:26])
    defparam and_36_i1_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i7_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(DBIN[6]), .Z(n83[6])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1573[15:26])
    defparam and_36_i7_2_lut_3_lut.init = 16'h8080;
    CCU2D add_642_7 (.A0(gi[4]), .B0(\EMPH[2] ), .C0(\EMPH[0] ), .D0(n3436), 
          .A1(gi[5]), .B1(\EMPH[2] ), .C1(\EMPH[0] ), .D1(n7928), .CIN(n10159), 
          .COUT(n10160), .S0(go_7__N_1453[4]), .S1(go_7__N_1453[5]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_642_7.INIT0 = 16'h56aa;
    defparam add_642_7.INIT1 = 16'h56aa;
    defparam add_642_7.INJECT1_0 = "NO";
    defparam add_642_7.INJECT1_1 = "NO";
    LUT4 and_36_i6_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[5]), .Z(n83[5])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1573[15:26])
    defparam and_36_i6_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i5_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[4]), .Z(n83[4])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1573[15:26])
    defparam and_36_i5_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i4_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[3]), .Z(n83[3])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1573[15:26])
    defparam and_36_i4_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i3_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[2]), .Z(n83[2])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1573[15:26])
    defparam and_36_i3_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i2_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[1]), .Z(n83[1])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1573[15:26])
    defparam and_36_i2_2_lut_3_lut.init = 16'h8080;
    CCU2D add_642_5 (.A0(gi[2]), .B0(\EMPH[2] ), .C0(\EMPH[0] ), .D0(n3432), 
          .A1(gi[3]), .B1(\EMPH[2] ), .C1(\EMPH[0] ), .D1(n3434), .CIN(n10158), 
          .COUT(n10159), .S0(go_7__N_1453[2]), .S1(go_7__N_1453[3]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_642_5.INIT0 = 16'h56aa;
    defparam add_642_5.INIT1 = 16'h56aa;
    defparam add_642_5.INJECT1_0 = "NO";
    defparam add_642_5.INJECT1_1 = "NO";
    CCU2D add_642_3 (.A0(gi[0]), .B0(\EMPH[2] ), .C0(\EMPH[0] ), .D0(n3426), 
          .A1(gi[1]), .B1(\EMPH[2] ), .C1(\EMPH[0] ), .D1(n3430), .CIN(n10157), 
          .COUT(n10158), .S0(go_7__N_1453[0]), .S1(go_7__N_1453[1]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_642_3.INIT0 = 16'h56aa;
    defparam add_642_3.INIT1 = 16'h56aa;
    defparam add_642_3.INJECT1_0 = "NO";
    defparam add_642_3.INJECT1_1 = "NO";
    LUT4 i7267_2_lut (.A(bo[4]), .B(PICTURER2), .Z(RGB_c_4)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7267_2_lut.init = 16'h2222;
    LUT4 i7266_2_lut (.A(bo[5]), .B(PICTURER2), .Z(RGB_c_5)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7266_2_lut.init = 16'h2222;
    LUT4 i3140_3_lut (.A(n1275), .B(bo_7__N_1502[0]), .C(n960), .Z(n3624)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam i3140_3_lut.init = 16'hacac;
    CCU2D sub_34_add_2_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(bi[0]), .B1(bi[2]), .C1(GND_net), .D1(GND_net), .COUT(n10142), 
          .S1(bo_7__N_1502[0]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1629[14:26])
    defparam sub_34_add_2_1.INIT0 = 16'h0000;
    defparam sub_34_add_2_1.INIT1 = 16'h5999;
    defparam sub_34_add_2_1.INJECT1_0 = "NO";
    defparam sub_34_add_2_1.INJECT1_1 = "NO";
    CCU2D add_495_rep_2_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(bo_7__N_1502[0]), .B1(bi[3]), .C1(GND_net), .D1(GND_net), 
          .COUT(n10138), .S1(n1283));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_495_rep_2_1.INIT0 = 16'h0000;
    defparam add_495_rep_2_1.INIT1 = 16'h5999;
    defparam add_495_rep_2_1.INJECT1_0 = "NO";
    defparam add_495_rep_2_1.INJECT1_1 = "NO";
    CCU2D add_495_rep_2_9 (.A0(bo_7__N_1502[7]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n10141), .S0(n1276));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_495_rep_2_9.INIT0 = 16'h5555;
    defparam add_495_rep_2_9.INIT1 = 16'h0000;
    defparam add_495_rep_2_9.INJECT1_0 = "NO";
    defparam add_495_rep_2_9.INJECT1_1 = "NO";
    CCU2D sub_34_add_2_9 (.A0(bi[7]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n10145), 
          .S0(bo_7__N_1502[7]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1629[14:26])
    defparam sub_34_add_2_9.INIT0 = 16'h5555;
    defparam sub_34_add_2_9.INIT1 = 16'h0000;
    defparam sub_34_add_2_9.INJECT1_0 = "NO";
    defparam sub_34_add_2_9.INJECT1_1 = "NO";
    CCU2D add_642_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(n11839), .B1(EMP_G), .C1(EMP_R), .D1(\EMPH[2] ), .COUT(n10157));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_642_1.INIT0 = 16'hF000;
    defparam add_642_1.INIT1 = 16'h001b;
    defparam add_642_1.INJECT1_0 = "NO";
    defparam add_642_1.INJECT1_1 = "NO";
    LUT4 i10846_2_lut_4_lut (.A(n11832), .B(\EMPH[0] ), .C(\EMPH[2] ), 
         .D(gi[7]), .Z(n7928)) /* synthesis lut_function=(!(A (B (C (D))+!B !(C+!(D)))+!A (B (D)+!B !(C+!(D))))) */ ;
    defparam i10846_2_lut_4_lut.init = 16'h38ff;
    PFUMX mux_472_i8 (.BLUT(n3720), .ALUT(n971[7]), .C0(n10903), .Z(bo_7__N_1461[7]));
    PFUMX mux_472_i6 (.BLUT(n3718), .ALUT(n971[5]), .C0(n10903), .Z(bo_7__N_1461[5]));
    PFUMX mux_472_i7 (.BLUT(n3719), .ALUT(n971[6]), .C0(n10903), .Z(bo_7__N_1461[6]));
    PFUMX mux_472_i4 (.BLUT(n3716), .ALUT(n971[3]), .C0(n10903), .Z(bo_7__N_1461[3]));
    PFUMX mux_472_i5 (.BLUT(n3717), .ALUT(n971[4]), .C0(n10903), .Z(bo_7__N_1461[4]));
    PFUMX mux_472_i2 (.BLUT(n3714), .ALUT(n971[1]), .C0(n10903), .Z(bo_7__N_1461[1]));
    PFUMX mux_472_i3 (.BLUT(n3715), .ALUT(n971[2]), .C0(n10903), .Z(bo_7__N_1461[2]));
    LUT4 mux_505_i1_3_lut (.A(ri[3]), .B(ri[2]), .C(n11798), .Z(n3428)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam mux_505_i1_3_lut.init = 16'h3535;
    CCU2D add_495_rep_2_7 (.A0(bo_7__N_1502[5]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(bo_7__N_1502[6]), .B1(GND_net), .C1(GND_net), 
          .D1(GND_net), .CIN(n10140), .COUT(n10141), .S0(n1278), .S1(n1277));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_495_rep_2_7.INIT0 = 16'h5555;
    defparam add_495_rep_2_7.INIT1 = 16'h5555;
    defparam add_495_rep_2_7.INJECT1_0 = "NO";
    defparam add_495_rep_2_7.INJECT1_1 = "NO";
    CCU2D add_495_rep_2_3 (.A0(bo_7__N_1502[1]), .B0(bi[4]), .C0(GND_net), 
          .D0(GND_net), .A1(bo_7__N_1502[2]), .B1(bi[5]), .C1(GND_net), 
          .D1(GND_net), .CIN(n10138), .COUT(n10139), .S0(n1282), .S1(n1281));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_495_rep_2_3.INIT0 = 16'h5999;
    defparam add_495_rep_2_3.INIT1 = 16'h5999;
    defparam add_495_rep_2_3.INJECT1_0 = "NO";
    defparam add_495_rep_2_3.INJECT1_1 = "NO";
    LUT4 i7265_2_lut (.A(bo[6]), .B(PICTURER2), .Z(RGB_c_6)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7265_2_lut.init = 16'h2222;
    LUT4 i7264_2_lut (.A(bo[7]), .B(PICTURER2), .Z(RGB_c_7)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7264_2_lut.init = 16'h2222;
    PFUMX mux_472_i1 (.BLUT(n3624), .ALUT(n971[0]), .C0(n10903), .Z(bo_7__N_1461[0]));
    LUT4 i7263_2_lut (.A(go[0]), .B(PICTURER2), .Z(RGB_c_8)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7263_2_lut.init = 16'h2222;
    LUT4 i3231_3_lut (.A(n1268), .B(bo_7__N_1502[7]), .C(n960), .Z(n3720)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam i3231_3_lut.init = 16'hacac;
    LUT4 i7262_2_lut (.A(go[1]), .B(PICTURER2), .Z(RGB_c_9)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7262_2_lut.init = 16'h2222;
    LUT4 i7261_2_lut (.A(go[2]), .B(PICTURER2), .Z(RGB_c_10)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7261_2_lut.init = 16'h2222;
    LUT4 i7260_2_lut (.A(go[3]), .B(PICTURER2), .Z(RGB_c_11)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1580[20:74])
    defparam i7260_2_lut.init = 16'h2222;
    CCU2D add_495_rep_1_9 (.A0(bi[7]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n10153), 
          .S0(n1268));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1590[7] 1631[14])
    defparam add_495_rep_1_9.INIT0 = 16'h5555;
    defparam add_495_rep_1_9.INIT1 = 16'h0000;
    defparam add_495_rep_1_9.INJECT1_0 = "NO";
    defparam add_495_rep_1_9.INJECT1_1 = "NO";
    PALETTE_RGB_TABLE MOD_PALETTE_RGB_TABLE (.PALSEL_c_2(PALSEL_c_2), .PALSEL_c_1(PALSEL_c_1), 
            .PALSEL_c_0(PALSEL_c_0), .PIX({PIX}), .Clk(Clk), .GND_net(GND_net), 
            .ri({\ri[7] , ri[6:0]}), .gi({gi}), .bi({bi})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1576[19:113])
    PALETTE_RAM C_5__I_0 (.Clk(Clk), .GND_net(GND_net), .C_5__N_1469(C_5__N_1469), 
            .CGAH(Address[4]), .\CGA[3] (\CGA[3] ), .\CGA[2] (\CGA[2] ), 
            .\CGA[1] (\CGA[1] ), .n11768(n11768), .\DBIN[5] (DBIN[5]), 
            .\DBIN[4] (DBIN[4]), .\DBIN[3] (DBIN[3]), .\DBIN[2] (DBIN[2]), 
            .\DBIN[1] (DBIN[1]), .\DBIN[0] (DBIN[0]), .C({C})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1575[13:100])
    
endmodule
//
// Verilog Description of module PALETTE_RGB_TABLE
//

module PALETTE_RGB_TABLE (PALSEL_c_2, PALSEL_c_1, PALSEL_c_0, PIX, Clk, 
            GND_net, ri, gi, bi) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input PALSEL_c_2;
    input PALSEL_c_1;
    input PALSEL_c_0;
    input [5:0]PIX;
    input Clk;
    input GND_net;
    output [7:0]ri;
    output [7:0]gi;
    output [7:0]bi;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire VCC_net;
    
    DP8KC PALETTE_RGB_TABLE_0_1_0 (.DIA0(GND_net), .DIA1(GND_net), .DIA2(GND_net), 
          .DIA3(GND_net), .DIA4(GND_net), .DIA5(GND_net), .DIA6(GND_net), 
          .DIA7(GND_net), .DIA8(GND_net), .ADA0(GND_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(PIX[0]), .ADA4(PIX[1]), .ADA5(PIX[2]), 
          .ADA6(PIX[3]), .ADA7(PIX[4]), .ADA8(PIX[5]), .ADA9(PALSEL_c_0), 
          .ADA10(PALSEL_c_1), .ADA11(PALSEL_c_2), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(GND_net), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), 
          .ADB4(GND_net), .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), 
          .ADB8(GND_net), .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), 
          .ADB12(VCC_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(Clk), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(ri[2]), .DOA1(ri[3]), .DOA2(ri[4]), 
          .DOA3(ri[5]), .DOA4(ri[6]), .DOA5(ri[7])) /* synthesis MEM_LPC_FILE="PALETTE_RGB_TABLE.lpc", MEM_INIT_FILE="pal_table.mem", syn_instantiated=1, LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=113, LSE_LLINE=1576, LSE_RLINE=1576 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1576[19:113])
    defparam PALETTE_RGB_TABLE_0_1_0.DATA_WIDTH_A = 9;
    defparam PALETTE_RGB_TABLE_0_1_0.DATA_WIDTH_B = 9;
    defparam PALETTE_RGB_TABLE_0_1_0.REGMODE_A = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_1_0.REGMODE_B = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_1_0.CSDECODE_A = "0b000";
    defparam PALETTE_RGB_TABLE_0_1_0.CSDECODE_B = "0b000";
    defparam PALETTE_RGB_TABLE_0_1_0.WRITEMODE_A = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_1_0.WRITEMODE_B = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_1_0.GSR = "ENABLED";
    defparam PALETTE_RGB_TABLE_0_1_0.RESETMODE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_1_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_1_0.INIT_DATA = "STATIC";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_00 = "0x0000000000000000121603C2604E240341100C2B0000000000000000000701C1302C1501A0600019";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_01 = "0x0000005C2F05E3106A3B07C3F07E3E074360623F0000002613024160402E06C3C0763805A230323F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_02 = "0x0040200400000000181B052320642B03E0E0002B0040200400000000040D0301E03C1901E0400019";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_03 = "0x0040205A2B0542D0663907E3F07E3F0743405C3F004020260D018130403007C3F07E3F0662302A3F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_04 = "0x00000000000000000C1503E260522703610006290000000000000000000601E150321801E0700018";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_05 = "0x000000582A0542D062380783D07A390642F0563F000000240D01A1003C2C06A3C0783604C1C0263F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_06 = "0x0000000000000000161B0543406A2A03005000280000000000000000040D02E1E03C170160000016";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_07 = "0x000000562404A2A0623A07E3F07E3F0702F0503F00000020010080E03C3107E3F07E3F05A1700E3F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_08 = "0x0000001200000000122406C3F07E2D048000002D0000000000000000121B0482D05A24036000001B";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_09 = "0x00000048240242405A3F07E3F07E3F07E3605A3F0000002400024000363607E3F07E3F06C240363F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0A = "0x000000000000000010190442A0562703A1000A2D0000000000000000000A0241603218020080001A";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0B = "0x0000005E2D05A2F0683A0783F07E3B0703405E3F0000002813024170443606E3D07A3A0601F0303F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0C = "0x00402008000000701E3106A3F07E3F05A11000320020100000000000001E0482C05A2E0420D00020";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0D = "0x0080406E2C0542B0663F07E3F07E3F0682E0423F0060303200026140523F07E3F07E3F06A1B0003F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0E = "0x00000000000000000E1303E27052240340D002260000000000000000000601E1502C120160100014";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0F = "0x000000502804E2905A3306E3B0763906A300563A0000001E0E01811036280683B07A3805C2102A3A";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    DP8KC PALETTE_RGB_TABLE_0_0_1 (.DIA0(GND_net), .DIA1(GND_net), .DIA2(GND_net), 
          .DIA3(GND_net), .DIA4(GND_net), .DIA5(GND_net), .DIA6(GND_net), 
          .DIA7(GND_net), .DIA8(GND_net), .ADA0(GND_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(PIX[0]), .ADA4(PIX[1]), .ADA5(PIX[2]), 
          .ADA6(PIX[3]), .ADA7(PIX[4]), .ADA8(PIX[5]), .ADA9(PALSEL_c_0), 
          .ADA10(PALSEL_c_1), .ADA11(PALSEL_c_2), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(GND_net), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(PIX[0]), 
          .ADB4(PIX[1]), .ADB5(PIX[2]), .ADB6(PIX[3]), .ADB7(PIX[4]), 
          .ADB8(PIX[5]), .ADB9(PALSEL_c_0), .ADB10(PALSEL_c_1), .ADB11(PALSEL_c_2), 
          .ADB12(VCC_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(Clk), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(bi[0]), .DOA1(bi[1]), .DOA2(bi[2]), 
          .DOA3(bi[3]), .DOA4(bi[4]), .DOA5(bi[5]), .DOA6(bi[6]), .DOA7(bi[7]), 
          .DOA8(gi[0]), .DOB0(gi[1]), .DOB1(gi[2]), .DOB2(gi[3]), .DOB3(gi[4]), 
          .DOB4(gi[5]), .DOB5(gi[6]), .DOB6(gi[7]), .DOB7(ri[0]), .DOB8(ri[1])) /* synthesis MEM_LPC_FILE="PALETTE_RGB_TABLE.lpc", MEM_INIT_FILE="pal_table.mem", syn_instantiated=1, LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=113, LSE_LLINE=1576, LSE_RLINE=1576 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1576[19:113])
    defparam PALETTE_RGB_TABLE_0_0_1.DATA_WIDTH_A = 9;
    defparam PALETTE_RGB_TABLE_0_0_1.DATA_WIDTH_B = 9;
    defparam PALETTE_RGB_TABLE_0_0_1.REGMODE_A = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_0_1.REGMODE_B = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_0_1.CSDECODE_A = "0b000";
    defparam PALETTE_RGB_TABLE_0_0_1.CSDECODE_B = "0b000";
    defparam PALETTE_RGB_TABLE_0_0_1.WRITEMODE_A = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_0_1.WRITEMODE_B = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_0_1.GSR = "ENABLED";
    defparam PALETTE_RGB_TABLE_0_0_1.RESETMODE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_0_1.ASYNC_RESET_RELEASE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_0_1.INIT_DATA = "STATIC";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_00 = "0x000000008A07C0000100200000BDAE3AFE3191AF000000005522F0020100201000305D1048E0FB65";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_01 = "0x00000373F11A6B8148A4362CB1E2FF3FFFF3FFFF00000099CB2FC3F2180A0586A189FF1FFFF3FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_02 = "0x2130921298255002000020015306E53FEFF3EAAE213092135520400200000010008A8F178C033765";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_03 = "0x2130936EF7193A030F84332C03FFFF3FEFF3FFFF2130909DEA0F5160010020D641A9FF1FFFF3FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_04 = "0x000002038F07D00000000000009BAB3B3EB3A8A6000000015C03F00001002010002E601149B11E60";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_05 = "0x00000363E7187A812A95340B91C2FD3FEFF1FFFF00000094C60EC320070C21F5016CFF1FEFF1FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_06 = "0x00000001A90A5062000000000083981C8FE3DDA1000000005D04500200000000002E7230B9B31858";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_07 = "0x00000158FE1B2B03248631DA93A0FB1FCFE3FDFF00000085FE3494A020002113C321F61FDFE3FDFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_08 = "0x00000048920DA000010020000124FF1FFFF3B6B600000001490012420100200000DA6D3B6DB1256D";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_09 = "0x00000125FF3B76D2936D2939216CFF1FEFF3FFFF00000293FF3B70020100000003FEFF3FEFF1FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0A = "0x00000000912880020100200002C9B93BFEF3A6B4000000005903B08200000000003C671189A3116B";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0B = "0x0000037EF139CB4345A015AC63C3FF1FEFF3FFFF000000A5D210C3E01D0A0526B19BFF3FCFF1FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0C = "0x21309222C42CC15200002011A2BDAA398FF3FEC820B05001660440D001000000003C6A14CBF17480";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0D = "0x223113BAFF1DCB7333A215CB7399EA3FFFF3FEFE21B0D0CDFF35D6A200332BF59333CC3FEFF3FEFE";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0E = "0x00000001850570020100201000B3AD3CBF119D99000000014320100000000000004261116950F551";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0F = "0x00000346E237A9A1087F31BAB1A0F31FFFF1FEEA0000027BD70FA280010001050357FF3FEFF3FEEA";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_10 = "0x000000003707A4127BB334A9921B8D31F9714FD7000000001703A2003C98019822010020000012B2";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_11 = "0x000001B9F82F6FC2F4F50DFEA3CCE71D0EC3E5FF0000004CE32D1EB3CADA0984036C37277440A9FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_12 = "0x108841084209A4F291B934C153138701D9F1615710884108220562D04F1C01C80301003008702AB2";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_13 = "0x108843B6772F97C0F2F30D7E43BFDE3C2E82DFFF1088424E6A0ECF81E26109DBC363AE06D452B1FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_14 = "0x00000100330763F2783204A9931A0B01C9634B53000000001803C220439901F86200003010101430";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_15 = "0x000001B1F22E6F52EDF00D6E41BF5F2B9E02D7FF0000024BDE0CAE90C5D7193BD064B23653C09DFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_16 = "0x00000000340783E1722F2451601E8E0289E052D0000000001903C1F138953190420080104090222C";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_17 = "0x000000ACF21EC773E8EF2D1622BD5E1C2E60D9FF000002435F1D16A1CA592933B26732173443A5FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_18 = "0x00000024490B6490933636D80301002002406D5B000000002409236048A4249122010014800024B6";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_19 = "0x000002936D1FF7F2FFFF3FFED3B7C93B7DB2DBFF000001487F1FE7F1DBED3B7C936D8036D491B7FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1A = "0x000000003B080451833524B1600E0C0259B1545A000000001B042240441B01684000000008001BB5";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1B = "0x000003BF761F07A2EDF12DBE53C3E31C9690DFFF00000252E73D86F1D3ED1A044172BB07C4E3B3FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1C = "0x1088411042094C207A3114B1B237193321E05864104820001703C2403F9512780301800018000040";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1D = "0x110881DDF72F9770E16C2CD622BF5F0BBDD0BF7F10C862666C1D4EC2BF512913D26F3B16FC20957F";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1E = "0x00000000310783F075AE23E9000C0200E93246CC00000000140381E0369210C802018000080012A8";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1F = "0x000003A2EA2DD703DC693C45C3B1D72B2DD2C9750000013C5A2CAE82C6D7091B925D2B161BC39775";
    VHI i1 (.Z(VCC_net));
    
endmodule
//
// Verilog Description of module PALETTE_RAM
//

module PALETTE_RAM (Clk, GND_net, C_5__N_1469, CGAH, \CGA[3] , \CGA[2] , 
            \CGA[1] , n11768, \DBIN[5] , \DBIN[4] , \DBIN[3] , \DBIN[2] , 
            \DBIN[1] , \DBIN[0] , C) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input Clk;
    input GND_net;
    input C_5__N_1469;
    input CGAH;
    input \CGA[3] ;
    input \CGA[2] ;
    input \CGA[1] ;
    input n11768;
    input \DBIN[5] ;
    input \DBIN[4] ;
    input \DBIN[3] ;
    input \DBIN[2] ;
    input \DBIN[1] ;
    input \DBIN[0] ;
    output [5:0]C;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire VCC_net;
    
    DP8KC PALETTE_RAM_0_0_0 (.DIA0(\DBIN[0] ), .DIA1(\DBIN[1] ), .DIA2(\DBIN[2] ), 
          .DIA3(\DBIN[3] ), .DIA4(\DBIN[4] ), .DIA5(\DBIN[5] ), .DIA6(GND_net), 
          .DIA7(GND_net), .DIA8(GND_net), .ADA0(VCC_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(n11768), .ADA4(\CGA[1] ), .ADA5(\CGA[2] ), 
          .ADA6(\CGA[3] ), .ADA7(CGAH), .ADA8(GND_net), .ADA9(GND_net), 
          .ADA10(GND_net), .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(C_5__N_1469), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), 
          .ADB4(GND_net), .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), 
          .ADB8(GND_net), .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), 
          .ADB12(GND_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(GND_net), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(C[0]), .DOA1(C[1]), .DOA2(C[2]), .DOA3(C[3]), 
          .DOA4(C[4]), .DOA5(C[5])) /* synthesis MEM_LPC_FILE="PALETTE_RAM.lpc", MEM_INIT_FILE="INIT_ALL_0s", syn_instantiated=1, LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=100, LSE_LLINE=1575, LSE_RLINE=1575 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1575[13:100])
    defparam PALETTE_RAM_0_0_0.DATA_WIDTH_A = 9;
    defparam PALETTE_RAM_0_0_0.DATA_WIDTH_B = 9;
    defparam PALETTE_RAM_0_0_0.REGMODE_A = "NOREG";
    defparam PALETTE_RAM_0_0_0.REGMODE_B = "NOREG";
    defparam PALETTE_RAM_0_0_0.CSDECODE_A = "0b000";
    defparam PALETTE_RAM_0_0_0.CSDECODE_B = "0b111";
    defparam PALETTE_RAM_0_0_0.WRITEMODE_A = "NORMAL";
    defparam PALETTE_RAM_0_0_0.WRITEMODE_B = "NORMAL";
    defparam PALETTE_RAM_0_0_0.GSR = "ENABLED";
    defparam PALETTE_RAM_0_0_0.RESETMODE = "ASYNC";
    defparam PALETTE_RAM_0_0_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam PALETTE_RAM_0_0_0.INIT_DATA = "STATIC";
    defparam PALETTE_RAM_0_0_0.INITVAL_00 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_01 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_02 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_03 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_04 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_05 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_06 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_07 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    VHI i1 (.Z(VCC_net));
    
endmodule
//
// Verilog Description of module OBJ_FIFO
//

module OBJ_FIFO (n12292, SEL_LATCH, OB, Clk, ATR_IN0_2__N_1353, CLIPOR, 
            PD_out_4, PD_out_3, SPR0HIT_LATCH, Clk_enable_564, Clk_enable_562, 
            SH2, SH2_N_1365, ATR_IN1_2__N_1355, ATR_IN2_2__N_1356, ATR_IN3_2__N_1357, 
            ATR_IN4_2__N_1358, ATR_IN5_2__N_1359, ATR_IN6_2__N_1360, ATR_IN7_2__N_1361, 
            O_HPOS, Clk_enable_185, SH3_N_1374, SH5_N_1378, SH7_N_1383, 
            Clk_enable_208, PD_FIFO, Clk_enable_530, Clk_enable_549, 
            Clk_enable_423, PD_out_0, PD_out_7, \Hnn[5] , \Hnn[4] , 
            \Hnn[3] , ZCOL, Clk_enable_526, n5788, PD_out_6, PD_out_1, 
            PD_out_5, PD_out_2, n12276, nVIS, Clk_enable_473) /* synthesis syn_module_defined=1 */ ;
    input n12292;
    output [7:0]SEL_LATCH;
    input [7:0]OB;
    input Clk;
    input ATR_IN0_2__N_1353;
    input CLIPOR;
    input PD_out_4;
    input PD_out_3;
    output SPR0HIT_LATCH;
    input Clk_enable_564;
    input Clk_enable_562;
    output SH2;
    input SH2_N_1365;
    input ATR_IN1_2__N_1355;
    input ATR_IN2_2__N_1356;
    input ATR_IN3_2__N_1357;
    input ATR_IN4_2__N_1358;
    input ATR_IN5_2__N_1359;
    input ATR_IN6_2__N_1360;
    input ATR_IN7_2__N_1361;
    input O_HPOS;
    input Clk_enable_185;
    input SH3_N_1374;
    input SH5_N_1378;
    input SH7_N_1383;
    input Clk_enable_208;
    input PD_FIFO;
    input Clk_enable_530;
    input Clk_enable_549;
    input Clk_enable_423;
    input PD_out_0;
    input PD_out_7;
    input \Hnn[5] ;
    input \Hnn[4] ;
    input \Hnn[3] ;
    output [4:0]ZCOL;
    input Clk_enable_526;
    input n5788;
    input PD_out_6;
    input PD_out_1;
    input PD_out_5;
    input PD_out_2;
    input n12276;
    input nVIS;
    input Clk_enable_473;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]EN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1334[11:13])
    wire [7:0]QP;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5353, n5349, n5345, n5343, n11851, n11852, n11853, SH5, 
        n11726, n11728, n11731, n11733, n11735, n11737, n11739, 
        n11779;
    wire [7:0]CNT;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1448[11:14])
    
    wire SH3, n11858, CNT1, ZH_FF, n11857, n11864, CNT1_adj_1909, 
        n11863, n11867, CNT1_adj_1910, n11866;
    wire [2:0]ATR_IN0;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1327[11:18])
    wire [7:0]CNT_adj_2250;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1448[11:14])
    
    wire n11882, CNT1_adj_1911, ZH_FF_adj_1912, n11881, n11885, CNT1_adj_1913, 
        n11884, n11888, CNT1_adj_1914, n11887, n11891, CNT1_adj_1915, 
        n11890, n11894, CNT1_adj_1916, n11893, n11897, CNT1_adj_1918, 
        n11896, n11900, CNT1_adj_1920, n11899, n11903, CNT1_adj_1922, 
        n11902;
    wire [7:0]CNT_adj_2251;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1448[11:14])
    
    wire n11912, CNT1_adj_1924, ZH_FF_adj_1925, n11911, n11915, CNT1_adj_1927, 
        n11914, n11918, CNT1_adj_1929, n11917, n11921, CNT1_adj_1931, 
        n11920, n11924, CNT1_adj_1933, n11923, n11927, CNT1_adj_1935, 
        n11926;
    wire [2:0]ATR6;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1328[47:51])
    wire [2:0]ATR7;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1328[53:57])
    
    wire SPR_6__N_1267, SPR_7__N_1254;
    wire [4:0]n326;
    
    wire n11930, CNT1_adj_1937, n11929, n11837, n4, n11758, n11760, 
        n11933, CNT1_adj_1939, n11932, n7900, n11759, n7952, n11718, 
        n11713;
    wire [7:0]CNT_adj_2252;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1448[11:14])
    
    wire n11936, CNT1_adj_1941, ZH_FF_adj_1942, n11935;
    wire [7:0]QP_adj_2253;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2254;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5715, n5713, n5711, n5709, n5707, n5705, MIRR_LATCH;
    wire [7:0]MIRR_MUX;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1331[11:19])
    
    wire n11939, CNT1_adj_1950, n11938, n11942, CNT1_adj_1952, n11941, 
        n11945, CNT1_adj_1954, n11944, n11848, n11849, n11850, n11948;
    wire [7:0]COL0;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1346[10:14])
    wire [4:0]n344;
    wire [4:0]ZCOL_4__N_1330;
    
    wire n11353, n10978;
    wire [7:0]COL1;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1346[16:20])
    wire [2:0]ATR0;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1328[11:15])
    
    wire CNT1_adj_1956, n11947, n11951, CNT1_adj_1958, n11950, n11954, 
        CNT1_adj_1960, n11953, n11799, n11957, CNT1_adj_1962, n11956;
    wire [7:0]CNT_adj_2255;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1448[11:14])
    
    wire n11960, CNT1_adj_1964, ZH_FF_adj_1965, n11959, n11963, CNT1_adj_1967, 
        n11962, n11966, CNT1_adj_1969, n11965, n11969, CNT1_adj_1971, 
        n11968;
    wire [7:0]PD_LATCH;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1325[10:18])
    wire [2:0]ATR1;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1328[17:21])
    wire [2:0]ATR_IN1;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1327[20:27])
    wire [2:0]ATR2;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1328[23:27])
    wire [2:0]ATR_IN2;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1327[29:36])
    wire [2:0]ATR3;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1328[29:33])
    wire [2:0]ATR_IN3;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1327[38:45])
    wire [2:0]ATR4;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1328[35:39])
    wire [2:0]ATR_IN4;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1327[47:54])
    wire [2:0]ATR5;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1328[41:45])
    wire [2:0]ATR_IN5;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1327[56:63])
    wire [2:0]ATR_IN6;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1327[65:72])
    wire [2:0]ATR_IN7;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1327[74:81])
    
    wire n11972;
    wire [2:0]ZPOS;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1324[10:14])
    
    wire CNT1_adj_1973, n11971, n7886, n7704, n10787, n11975, CNT1_adj_1975, 
        n11974, n11978, CNT1_adj_1977, n11977, n10919, n11981, CNT1_adj_1979, 
        n11980;
    wire [7:0]CNT_adj_2256;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1448[11:14])
    
    wire n11984, CNT1_adj_1981, ZH_FF_adj_1982, n11983, n11987, CNT1_adj_1984, 
        n11986, n11990, CNT1_adj_1986, n11989, n11846, n11993, CNT1_adj_1989, 
        n11992, n11996, CNT1_adj_1991, n11995, n5703;
    wire [7:0]QP_adj_2257;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2258;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5701, n11999, CNT1_adj_1997, n11998, n5699, n5697, n12002, 
        CNT1_adj_2003, n12001, n12005, CNT1_adj_2005, n12004;
    wire [7:0]CNT_adj_2259;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1448[11:14])
    
    wire n12008, CNT1_adj_2007, ZH_FF_adj_2008, n12007, n12011, CNT1_adj_2010, 
        n12010, n12014, CNT1_adj_2012, n12013, n12017, CNT1_adj_2014, 
        n12016, n12020, CNT1_adj_2016, n12019, n12023, CNT1_adj_2018, 
        n12022, n12026, CNT1_adj_2020, n12025, n12029, CNT1_adj_2022, 
        n12028;
    wire [7:0]CNT_adj_2260;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1448[11:14])
    
    wire n12032, CNT1_adj_2024, ZH_FF_adj_2025, n12031, n12035, CNT1_adj_2027, 
        n12034, n12038, CNT1_adj_2029, n12037, n12041, CNT1_adj_2031, 
        n12040, n12044, CNT1_adj_2033, n12043, n12047, CNT1_adj_2035, 
        n12046, n12050, CNT1_adj_2037, n12049, n12053, SH7, CNT1_adj_2039, 
        n12052, n12056, CNT1_adj_2041, n12055, n5695, n5693, n12059, 
        CNT1_adj_2047, n12058, n11777;
    wire [7:0]SDATA;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1344[11:16])
    
    wire n5204, n5205, n5691, n5689, n5209, n5210, n5215, n5216, 
        n5227, n5228, n5231, n5232, n5235, n5236, n5239, n5240, 
        n11778, n5243, n5244, n5250, n5251, n5252, n5253, n5260, 
        n5261, n5264, n5265, n5268, n5269, n5276, n5277, n5278, 
        n5279, n5282, n5283, n5291, n5292, n5299, n5300;
    wire [4:0]ZCOL_4__N_1145;
    
    wire n5301, n5302, n5307, n5308, n5315, n5316, n5317, n5318, 
        n5319, n5320, CNT_7__N_1385, CNT1_adj_2053, n5321, n5322, 
        n5323, n5324, n5327, n5328, n5335, n5336, n5339, n5340, 
        n5344, n5346, n5350, CNT1_adj_2054, n11845, n5354, n5359, 
        n5360, n5363, n5364, n5367, n5368, n5371, n5372, n5375, 
        n5376, n5379, n5380, n5383, n5384, n5387, n5388, n5391, 
        n5392, n5401, n5402;
    wire [4:0]n332;
    
    wire n11827, n5411, n5412, n5421, n5422, n5433, n5434, n5447, 
        n5448, n5457, n5458, n5461, n5462, n5465, n5466, n5468, 
        n5469, n5472, n5473, n5477, n5478, n5481, n5482, n5484, 
        n5485, n5486, n5487, n5497, n5498, n5501, n5502, CNT_7__N_1385_adj_2055, 
        CNT_7__N_1385_adj_2056, CNT_7__N_1385_adj_2057, n5507, n5508, 
        CNT_7__N_1385_adj_2058, n5509, n5510, n5511, n5512, n5513, 
        n5514, n5515, n5516, n5521, n5522, n11773;
    wire [7:0]QP_adj_2261;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2262;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5523, n5524, n5525, n5526, n5623, n5624, n5625, n5626, 
        n5627, n5628, n5629, n5630, n11793, n5631, n5632, n5633, 
        n5634, n5635, n5636, n5637, n5638, n5639, n5640, n5641, 
        n5642, n5643, n5644, n5645, n5646, n5647, n5648, n5649, 
        n5650, n5651, n5652, n5653, n5654, n5655, n5656;
    wire [7:0]QP_adj_2263;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2264;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5657, n5658, n5659, n5660, n5661, n5662, n5663, n5664, 
        n5665, n5666, n5667, n5668, n5669, n5670, n5671, n5672, 
        n5673, n5674, n5675, n5676, n5677, n5678, n5679, n5680, 
        n5681, n5682, n5683, n5684, n5685, n5686, n5687, n5688, 
        n5690, n5692, n5694, n5696, n5698, n5700, n5702, n5704, 
        n5706, n5708, n5710, n5712, n5714, n5716, CNT1_adj_2078, 
        n10759, n5801, n4239, n4236, n4242, n7663;
    wire [4:0]n338;
    
    wire n11847, n11699, SPR_7__N_1266, n11769;
    wire [7:0]QP_adj_2265;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2266;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    wire [7:0]QP_adj_2267;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2268;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n11770;
    wire [7:0]QP_adj_2269;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2270;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    wire [7:0]QP_adj_2271;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2272;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n11771;
    wire [7:0]QP_adj_2273;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2274;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n12060, n12057, n12054, n12051, n12048, n12045, n11774, 
        n12042;
    wire [7:0]QP_adj_2275;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2276;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n12039, n12036, n12033;
    wire [7:0]QP_adj_2277;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2278;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n12030, n12027, n12024, n11775, n12021;
    wire [7:0]QP_adj_2279;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2280;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n12018, n12015, n12012, n12009, n12006, n12003, n12000, 
        n11997;
    wire [7:0]QP_adj_2281;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2282;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n11994, CNT_7__N_1385_adj_2211, n11991, n11988, n11985, n11982, 
        n11979, n11976, n11973, n11970, n11967, n11776, n11964;
    wire [7:0]QP_adj_2283;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2284;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n11961, n11958, n11955, n11952, n11949, n11946, n11943, 
        n11940;
    wire [7:0]QP_adj_2285;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    wire [7:0]QS_IN_adj_2286;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n11937, n11934, n11931, n11928, n11925, n11922, n11919, 
        n11916, n11913, n11722, n11904, n11901, n11898, n11725, 
        n11895, n11727, n11730, n11892, n11732, n11734, n11889, 
        n11736, n11886, n11883, n11723, n11738, n11868, n11865, 
        n11859, Clk_enable_272, n4024, Clk_enable_270, n4045, Clk_enable_268, 
        n4065, Clk_enable_265, n4075, Clk_enable_260, n4076, Clk_enable_258, 
        n4077, Clk_enable_250, n4078;
    
    LUT4 i4848_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP[3]), .D(QS_IN[4]), 
         .Z(n5353)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4848_3_lut_4_lut.init = 16'hf780;
    LUT4 i4844_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP[4]), .D(QS_IN[5]), 
         .Z(n5349)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4844_3_lut_4_lut.init = 16'hf780;
    LUT4 i4840_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP[5]), .D(QS_IN[6]), 
         .Z(n5345)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4840_3_lut_4_lut.init = 16'hf780;
    LUT4 i4838_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP[6]), .D(QS_IN[7]), 
         .Z(n5343)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4838_3_lut_4_lut.init = 16'hf780;
    PFUMX i10936 (.BLUT(n11851), .ALUT(n11852), .C0(n12292), .Z(n11853));
    LUT4 COL0_7__N_1230_I_0_312_2_lut_rep_250_3_lut (.A(n12292), .B(SH5), 
         .C(SEL_LATCH[6]), .Z(n11726)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[54:64])
    defparam COL0_7__N_1230_I_0_312_2_lut_rep_250_3_lut.init = 16'h8080;
    LUT4 COL0_7__N_1230_I_0_314_2_lut_rep_252_3_lut (.A(n12292), .B(SH5), 
         .C(SEL_LATCH[5]), .Z(n11728)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[54:64])
    defparam COL0_7__N_1230_I_0_314_2_lut_rep_252_3_lut.init = 16'h8080;
    LUT4 COL0_7__N_1230_I_0_316_2_lut_rep_255_3_lut (.A(n12292), .B(SH5), 
         .C(SEL_LATCH[4]), .Z(n11731)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[54:64])
    defparam COL0_7__N_1230_I_0_316_2_lut_rep_255_3_lut.init = 16'h8080;
    LUT4 COL0_7__N_1230_I_0_318_2_lut_rep_257_3_lut (.A(n12292), .B(SH5), 
         .C(SEL_LATCH[3]), .Z(n11733)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[54:64])
    defparam COL0_7__N_1230_I_0_318_2_lut_rep_257_3_lut.init = 16'h8080;
    LUT4 COL0_7__N_1230_I_0_320_2_lut_rep_259_3_lut (.A(n12292), .B(SH5), 
         .C(SEL_LATCH[2]), .Z(n11735)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[54:64])
    defparam COL0_7__N_1230_I_0_320_2_lut_rep_259_3_lut.init = 16'h8080;
    LUT4 COL0_7__N_1230_I_0_322_2_lut_rep_261_3_lut (.A(n12292), .B(SH5), 
         .C(SEL_LATCH[1]), .Z(n11737)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[54:64])
    defparam COL0_7__N_1230_I_0_322_2_lut_rep_261_3_lut.init = 16'h8080;
    LUT4 COL0_7__N_1230_I_0_2_lut_rep_263_3_lut (.A(n12292), .B(SH5), .C(SEL_LATCH[0]), 
         .Z(n11739)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[54:64])
    defparam COL0_7__N_1230_I_0_2_lut_rep_263_3_lut.init = 16'h8080;
    LUT4 PCLK_I_0_323_2_lut_rep_303 (.A(n12292), .B(EN[0]), .Z(n11779)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam PCLK_I_0_323_2_lut_rep_303.init = 16'h8888;
    LUT4 i4861_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[2]), .C(CNT[2]), 
         .D(SH3), .Z(n11858)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4861_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4861_3_lut_4_lut_else_4_lut (.A(CNT[2]), .B(CNT1), .C(ZH_FF), 
         .Z(n11857)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4861_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4853_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[0]), .C(CNT[0]), 
         .D(SH3), .Z(n11864)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4853_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4853_3_lut_4_lut_else_4_lut (.A(CNT[0]), .B(CNT1_adj_1909), .C(ZH_FF), 
         .Z(n11863)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4853_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4857_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[1]), .C(CNT[1]), 
         .D(SH3), .Z(n11867)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4857_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4857_3_lut_4_lut_else_4_lut (.A(CNT[1]), .B(CNT1_adj_1910), .C(ZH_FF), 
         .Z(n11866)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4857_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    FD1P3AX ATR_IN0_i0_i2 (.D(OB[5]), .SP(ATR_IN0_2__N_1353), .CK(Clk), 
            .Q(ATR_IN0[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN0_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN0_i0_i1 (.D(OB[1]), .SP(ATR_IN0_2__N_1353), .CK(Clk), 
            .Q(ATR_IN0[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN0_i0_i1.GSR = "DISABLED";
    LUT4 i4951_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[7]), .C(CNT_adj_2250[7]), 
         .D(SH3), .Z(n11882)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i4951_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4951_3_lut_4_lut_else_4_lut (.A(CNT_adj_2250[7]), .B(CNT1_adj_1911), 
         .C(ZH_FF_adj_1912), .Z(n11881)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i4951_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4717_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[6]), .C(CNT_adj_2250[6]), 
         .D(SH3), .Z(n11885)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i4717_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4717_3_lut_4_lut_else_4_lut (.A(CNT_adj_2250[6]), .B(CNT1_adj_1913), 
         .C(ZH_FF_adj_1912), .Z(n11884)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i4717_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4719_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[5]), .C(CNT_adj_2250[5]), 
         .D(SH3), .Z(n11888)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i4719_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4719_3_lut_4_lut_else_4_lut (.A(CNT_adj_2250[5]), .B(CNT1_adj_1914), 
         .C(ZH_FF_adj_1912), .Z(n11887)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i4719_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4636_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[4]), .C(CNT_adj_2250[4]), 
         .D(SH3), .Z(n11891)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i4636_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4636_3_lut_4_lut_else_4_lut (.A(CNT_adj_2250[4]), .B(CNT1_adj_1915), 
         .C(ZH_FF_adj_1912), .Z(n11890)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i4636_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4634_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[3]), .C(CNT_adj_2250[3]), 
         .D(SH3), .Z(n11894)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i4634_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4634_3_lut_4_lut_else_4_lut (.A(CNT_adj_2250[3]), .B(CNT1_adj_1916), 
         .C(ZH_FF_adj_1912), .Z(n11893)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i4634_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5099_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[2]), .C(CNT_adj_2250[2]), 
         .D(SH3), .Z(n11897)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i5099_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5099_3_lut_4_lut_else_4_lut (.A(CNT_adj_2250[2]), .B(CNT1_adj_1918), 
         .C(ZH_FF_adj_1912), .Z(n11896)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i5099_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5079_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[0]), .C(CNT_adj_2250[0]), 
         .D(SH3), .Z(n11900)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i5079_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5079_3_lut_4_lut_else_4_lut (.A(CNT_adj_2250[0]), .B(CNT1_adj_1920), 
         .C(ZH_FF_adj_1912), .Z(n11899)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i5079_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5091_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[1]), .C(CNT_adj_2250[1]), 
         .D(SH3), .Z(n11903)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i5091_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5091_3_lut_4_lut_else_4_lut (.A(CNT_adj_2250[1]), .B(CNT1_adj_1922), 
         .C(ZH_FF_adj_1912), .Z(n11902)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[51:78])
    defparam i5091_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4843_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[7]), .C(CNT_adj_2251[7]), 
         .D(SH3), .Z(n11912)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4843_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4843_3_lut_4_lut_else_4_lut (.A(CNT_adj_2251[7]), .B(CNT1_adj_1924), 
         .C(ZH_FF_adj_1925), .Z(n11911)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4843_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4829_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[6]), .C(CNT_adj_2251[6]), 
         .D(SH3), .Z(n11915)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4829_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4829_3_lut_4_lut_else_4_lut (.A(CNT_adj_2251[6]), .B(CNT1_adj_1927), 
         .C(ZH_FF_adj_1925), .Z(n11914)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4829_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4827_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[5]), .C(CNT_adj_2251[5]), 
         .D(SH3), .Z(n11918)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4827_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4827_3_lut_4_lut_else_4_lut (.A(CNT_adj_2251[5]), .B(CNT1_adj_1929), 
         .C(ZH_FF_adj_1925), .Z(n11917)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4827_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4821_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[4]), .C(CNT_adj_2251[4]), 
         .D(SH3), .Z(n11921)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4821_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4821_3_lut_4_lut_else_4_lut (.A(CNT_adj_2251[4]), .B(CNT1_adj_1931), 
         .C(ZH_FF_adj_1925), .Z(n11920)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4821_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4807_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[3]), .C(CNT_adj_2251[3]), 
         .D(SH3), .Z(n11924)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4807_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4807_3_lut_4_lut_else_4_lut (.A(CNT_adj_2251[3]), .B(CNT1_adj_1933), 
         .C(ZH_FF_adj_1925), .Z(n11923)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4807_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4783_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[2]), .C(CNT_adj_2251[2]), 
         .D(SH3), .Z(n11927)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4783_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4783_3_lut_4_lut_else_4_lut (.A(CNT_adj_2251[2]), .B(CNT1_adj_1935), 
         .C(ZH_FF_adj_1925), .Z(n11926)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4783_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 mux_154_i4_4_lut (.A(ATR6[1]), .B(ATR7[1]), .C(SPR_6__N_1267), 
         .D(SPR_7__N_1254), .Z(n326[3])) /* synthesis lut_function=(!(A (B (C (D))+!B (C))+!A (((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1381[20] 1383[28])
    defparam mux_154_i4_4_lut.init = 16'h0aca;
    LUT4 i4766_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[0]), .C(CNT_adj_2251[0]), 
         .D(SH3), .Z(n11930)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4766_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4766_3_lut_4_lut_else_4_lut (.A(CNT_adj_2251[0]), .B(CNT1_adj_1937), 
         .C(ZH_FF_adj_1925), .Z(n11929)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4766_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i2_2_lut_rep_282_3_lut (.A(CLIPOR), .B(n11837), .C(n4), .Z(n11758)) /* synthesis lut_function=((B+(C))+!A) */ ;
    defparam i2_2_lut_rep_282_3_lut.init = 16'hfdfd;
    LUT4 i1_2_lut_rep_284_3_lut (.A(CLIPOR), .B(n11837), .C(n4), .Z(n11760)) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;
    defparam i1_2_lut_rep_284_3_lut.init = 16'h2020;
    LUT4 i4776_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[1]), .C(CNT_adj_2251[1]), 
         .D(SH3), .Z(n11933)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4776_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4776_3_lut_4_lut_else_4_lut (.A(CNT_adj_2251[1]), .B(CNT1_adj_1939), 
         .C(ZH_FF_adj_1925), .Z(n11932)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[51:78])
    defparam i4776_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i7458_2_lut_rep_283_3_lut (.A(CLIPOR), .B(n11837), .C(n7900), 
         .Z(n11759)) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;
    defparam i7458_2_lut_rep_283_3_lut.init = 16'h2020;
    LUT4 i1_2_lut_rep_242_3_lut_4_lut (.A(CLIPOR), .B(n11837), .C(n7952), 
         .D(n4), .Z(n11718)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;
    defparam i1_2_lut_rep_242_3_lut_4_lut.init = 16'h0200;
    LUT4 i10612_2_lut_rep_237_3_lut_3_lut_4_lut (.A(CLIPOR), .B(n11837), 
         .C(n4), .D(n7900), .Z(n11713)) /* synthesis lut_function=(!((B+!((D)+!C))+!A)) */ ;
    defparam i10612_2_lut_rep_237_3_lut_3_lut_4_lut.init = 16'h2202;
    LUT4 i4768_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[6]), .C(CNT_adj_2252[6]), 
         .D(SH3), .Z(n11936)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i4768_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4768_3_lut_4_lut_else_4_lut (.A(CNT_adj_2252[6]), .B(CNT1_adj_1941), 
         .C(ZH_FF_adj_1942), .Z(n11935)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i4768_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5210_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2253[0]), 
         .D(QS_IN_adj_2254[1]), .Z(n5715)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5210_3_lut_4_lut.init = 16'hf780;
    LUT4 i5208_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2253[1]), 
         .D(QS_IN_adj_2254[2]), .Z(n5713)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5208_3_lut_4_lut.init = 16'hf780;
    LUT4 i5206_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2253[2]), 
         .D(QS_IN_adj_2254[3]), .Z(n5711)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5206_3_lut_4_lut.init = 16'hf780;
    LUT4 i5204_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2253[3]), 
         .D(QS_IN_adj_2254[4]), .Z(n5709)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5204_3_lut_4_lut.init = 16'hf780;
    LUT4 i5202_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2253[4]), 
         .D(QS_IN_adj_2254[5]), .Z(n5707)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5202_3_lut_4_lut.init = 16'hf780;
    LUT4 i5200_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2253[5]), 
         .D(QS_IN_adj_2254[6]), .Z(n5705)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5200_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_7__I_0_i5_3_lut (.A(PD_out_4), .B(PD_out_3), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1332[24:96])
    defparam PD_7__I_0_i5_3_lut.init = 16'hcaca;
    LUT4 i4683_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[5]), .C(CNT_adj_2252[5]), 
         .D(SH3), .Z(n11939)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i4683_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4683_3_lut_4_lut_else_4_lut (.A(CNT_adj_2252[5]), .B(CNT1_adj_1950), 
         .C(ZH_FF_adj_1942), .Z(n11938)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i4683_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5235_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[4]), .C(CNT_adj_2252[4]), 
         .D(SH3), .Z(n11942)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i5235_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5235_3_lut_4_lut_else_4_lut (.A(CNT_adj_2252[4]), .B(CNT1_adj_1952), 
         .C(ZH_FF_adj_1942), .Z(n11941)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i5235_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5233_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[0]), .C(CNT_adj_2252[0]), 
         .D(SH3), .Z(n11945)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i5233_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5233_3_lut_4_lut_else_4_lut (.A(CNT_adj_2252[0]), .B(CNT1_adj_1954), 
         .C(ZH_FF_adj_1942), .Z(n11944)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i5233_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    PFUMX i10934 (.BLUT(n11848), .ALUT(n11849), .C0(n12292), .Z(n11850));
    LUT4 mux_154_i5_4_lut (.A(ATR6[2]), .B(ATR7[2]), .C(SPR_6__N_1267), 
         .D(SPR_7__N_1254), .Z(n326[4])) /* synthesis lut_function=(!(A (B (C (D))+!B (C))+!A (((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1381[20] 1383[28])
    defparam mux_154_i5_4_lut.init = 16'h0aca;
    LUT4 i4999_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[2]), .C(CNT_adj_2252[2]), 
         .D(SH3), .Z(n11948)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i4999_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 mux_158_i1_3_lut_4_lut (.A(CLIPOR), .B(n11837), .C(COL0[0]), 
         .D(n344[0]), .Z(ZCOL_4__N_1330[0])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_158_i1_3_lut_4_lut.init = 16'hf780;
    LUT4 i10888_2_lut_3_lut (.A(CLIPOR), .B(n11837), .C(n11353), .Z(n10978)) /* synthesis lut_function=(A (B+(C))+!A (C)) */ ;
    defparam i10888_2_lut_3_lut.init = 16'hf8f8;
    LUT4 mux_158_i2_3_lut_4_lut (.A(CLIPOR), .B(n11837), .C(COL1[0]), 
         .D(n344[1]), .Z(ZCOL_4__N_1330[1])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_158_i2_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_158_i4_3_lut_4_lut (.A(CLIPOR), .B(n11837), .C(ATR0[1]), 
         .D(n344[3]), .Z(ZCOL_4__N_1330[3])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_158_i4_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_158_i3_3_lut_4_lut (.A(CLIPOR), .B(n11837), .C(ATR0[0]), 
         .D(n344[2]), .Z(ZCOL_4__N_1330[2])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_158_i3_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_158_i5_3_lut_4_lut (.A(CLIPOR), .B(n11837), .C(ATR0[2]), 
         .D(n344[4]), .Z(ZCOL_4__N_1330[4])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_158_i5_3_lut_4_lut.init = 16'hf780;
    LUT4 i4999_3_lut_4_lut_else_4_lut (.A(CNT_adj_2252[2]), .B(CNT1_adj_1956), 
         .C(ZH_FF_adj_1942), .Z(n11947)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i4999_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4721_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[7]), .C(CNT_adj_2252[7]), 
         .D(SH3), .Z(n11951)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i4721_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4721_3_lut_4_lut_else_4_lut (.A(CNT_adj_2252[7]), .B(CNT1_adj_1958), 
         .C(ZH_FF_adj_1942), .Z(n11950)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i4721_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4709_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[1]), .C(CNT_adj_2252[1]), 
         .D(SH3), .Z(n11954)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i4709_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4709_3_lut_4_lut_else_4_lut (.A(CNT_adj_2252[1]), .B(CNT1_adj_1960), 
         .C(ZH_FF_adj_1942), .Z(n11953)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i4709_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    FD1P3AX SPR0HIT_LATCH_277 (.D(n11799), .SP(Clk_enable_564), .CK(Clk), 
            .Q(SPR0HIT_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam SPR0HIT_LATCH_277.GSR = "DISABLED";
    LUT4 i5081_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[3]), .C(CNT_adj_2252[3]), 
         .D(SH3), .Z(n11957)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i5081_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5081_3_lut_4_lut_else_4_lut (.A(CNT_adj_2252[3]), .B(CNT1_adj_1962), 
         .C(ZH_FF_adj_1942), .Z(n11956)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[51:78])
    defparam i5081_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5087_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[7]), .C(CNT_adj_2255[7]), 
         .D(SH3), .Z(n11960)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5087_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5087_3_lut_4_lut_else_4_lut (.A(CNT_adj_2255[7]), .B(CNT1_adj_1964), 
         .C(ZH_FF_adj_1965), .Z(n11959)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5087_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5085_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[2]), .C(CNT_adj_2255[2]), 
         .D(SH3), .Z(n11963)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5085_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5085_3_lut_4_lut_else_4_lut (.A(CNT_adj_2255[2]), .B(CNT1_adj_1967), 
         .C(ZH_FF_adj_1965), .Z(n11962)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5085_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5039_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[1]), .C(CNT_adj_2255[1]), 
         .D(SH3), .Z(n11966)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5039_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5039_3_lut_4_lut_else_4_lut (.A(CNT_adj_2255[1]), .B(CNT1_adj_1969), 
         .C(ZH_FF_adj_1965), .Z(n11965)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5039_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5033_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[6]), .C(CNT_adj_2255[6]), 
         .D(SH3), .Z(n11969)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5033_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5033_3_lut_4_lut_else_4_lut (.A(CNT_adj_2255[6]), .B(CNT1_adj_1971), 
         .C(ZH_FF_adj_1965), .Z(n11968)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5033_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    FD1P3AX ATR_IN0_i0_i0 (.D(OB[0]), .SP(ATR_IN0_2__N_1353), .CK(Clk), 
            .Q(ATR_IN0[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN0_i0_i0.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i0 (.D(MIRR_MUX[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(PD_LATCH[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam PD_LATCH_i0_i0.GSR = "DISABLED";
    FD1P3AX SH2_278 (.D(SH2_N_1365), .SP(Clk_enable_562), .CK(Clk), .Q(SH2));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam SH2_278.GSR = "DISABLED";
    FD1P3AX ATR0_i0_i0 (.D(ATR_IN0[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(ATR0[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR0_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR1_i0_i0 (.D(ATR_IN1[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(ATR1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR1_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR2_i0_i0 (.D(ATR_IN2[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(ATR2[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR2_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR3_i0_i0 (.D(ATR_IN3[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(ATR3[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR3_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR4_i0_i0 (.D(ATR_IN4[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(ATR4[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR4_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR5_i0_i0 (.D(ATR_IN5[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(ATR5[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR5_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR6_i0_i0 (.D(ATR_IN6[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(ATR6[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR6_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR7_i0_i0 (.D(ATR_IN7[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(ATR7[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR7_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN1_i0_i0 (.D(OB[0]), .SP(ATR_IN1_2__N_1355), .CK(Clk), 
            .Q(ATR_IN1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN1_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN2_i0_i0 (.D(OB[0]), .SP(ATR_IN2_2__N_1356), .CK(Clk), 
            .Q(ATR_IN2[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN2_i0_i0.GSR = "DISABLED";
    LUT4 i5095_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[3]), .C(CNT_adj_2255[3]), 
         .D(SH3), .Z(n11972)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5095_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    FD1P3AX ATR_IN3_i0_i0 (.D(OB[0]), .SP(ATR_IN3_2__N_1357), .CK(Clk), 
            .Q(ATR_IN3[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN3_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN4_i0_i0 (.D(OB[0]), .SP(ATR_IN4_2__N_1358), .CK(Clk), 
            .Q(ATR_IN4[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN4_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN5_i0_i0 (.D(OB[0]), .SP(ATR_IN5_2__N_1359), .CK(Clk), 
            .Q(ATR_IN5[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN5_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN6_i0_i0 (.D(OB[0]), .SP(ATR_IN6_2__N_1360), .CK(Clk), 
            .Q(ATR_IN6[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN6_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN7_i0_i0 (.D(OB[0]), .SP(ATR_IN7_2__N_1361), .CK(Clk), 
            .Q(ATR_IN7[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN7_i0_i0.GSR = "DISABLED";
    FD1P3AX ZPOS_i0 (.D(O_HPOS), .SP(Clk_enable_562), .CK(Clk), .Q(ZPOS[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ZPOS_i0.GSR = "DISABLED";
    LUT4 i5095_3_lut_4_lut_else_4_lut (.A(CNT_adj_2255[3]), .B(CNT1_adj_1973), 
         .C(ZH_FF_adj_1965), .Z(n11971)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5095_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i1_3_lut_4_lut_4_lut (.A(n7952), .B(n11760), .C(n7886), .D(n7704), 
         .Z(n10787)) /* synthesis lut_function=(A+((C+(D))+!B)) */ ;
    defparam i1_3_lut_4_lut_4_lut.init = 16'hfffb;
    LUT4 i5083_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[4]), .C(CNT_adj_2255[4]), 
         .D(SH3), .Z(n11975)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5083_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5083_3_lut_4_lut_else_4_lut (.A(CNT_adj_2255[4]), .B(CNT1_adj_1975), 
         .C(ZH_FF_adj_1965), .Z(n11974)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5083_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5027_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[0]), .C(CNT_adj_2255[0]), 
         .D(SH3), .Z(n11978)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5027_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5027_3_lut_4_lut_else_4_lut (.A(CNT_adj_2255[0]), .B(CNT1_adj_1977), 
         .C(ZH_FF_adj_1965), .Z(n11977)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i5027_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i10424_3_lut_4_lut_3_lut_4_lut (.A(n7952), .B(n11760), .C(n7886), 
         .D(n7704), .Z(n10919)) /* synthesis lut_function=(A+!(B (C+(D)))) */ ;
    defparam i10424_3_lut_4_lut_3_lut_4_lut.init = 16'hbbbf;
    LUT4 i4681_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[5]), .C(CNT_adj_2255[5]), 
         .D(SH3), .Z(n11981)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i4681_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4681_3_lut_4_lut_else_4_lut (.A(CNT_adj_2255[5]), .B(CNT1_adj_1979), 
         .C(ZH_FF_adj_1965), .Z(n11980)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[51:78])
    defparam i4681_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5013_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[7]), .C(CNT_adj_2256[7]), 
         .D(SH3), .Z(n11984)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i5013_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5013_3_lut_4_lut_else_4_lut (.A(CNT_adj_2256[7]), .B(CNT1_adj_1981), 
         .C(ZH_FF_adj_1982), .Z(n11983)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i5013_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4995_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[6]), .C(CNT_adj_2256[6]), 
         .D(SH3), .Z(n11987)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4995_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4995_3_lut_4_lut_else_4_lut (.A(CNT_adj_2256[6]), .B(CNT1_adj_1984), 
         .C(ZH_FF_adj_1982), .Z(n11986)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4995_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4988_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[5]), .C(CNT_adj_2256[5]), 
         .D(SH3), .Z(n11990)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4988_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4988_3_lut_4_lut_else_4_lut (.A(CNT_adj_2256[5]), .B(CNT1_adj_1986), 
         .C(ZH_FF_adj_1982), .Z(n11989)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4988_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4877_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[5]), .C(CNT[5]), 
         .D(SH3), .Z(n11846)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4877_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4931_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[4]), .C(CNT_adj_2256[4]), 
         .D(SH3), .Z(n11993)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4931_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4931_3_lut_4_lut_else_4_lut (.A(CNT_adj_2256[4]), .B(CNT1_adj_1989), 
         .C(ZH_FF_adj_1982), .Z(n11992)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4931_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4927_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[3]), .C(CNT_adj_2256[3]), 
         .D(SH3), .Z(n11996)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4927_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4927_3_lut_4_lut_else_4_lut (.A(CNT_adj_2256[3]), .B(CNT1_adj_1991), 
         .C(ZH_FF_adj_1982), .Z(n11995)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4927_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5198_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2253[6]), 
         .D(QS_IN_adj_2254[7]), .Z(n5703)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5198_3_lut_4_lut.init = 16'hf780;
    LUT4 i5196_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2257[0]), 
         .D(QS_IN_adj_2258[1]), .Z(n5701)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5196_3_lut_4_lut.init = 16'hf780;
    LUT4 i4915_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[2]), .C(CNT_adj_2256[2]), 
         .D(SH3), .Z(n11999)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4915_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4915_3_lut_4_lut_else_4_lut (.A(CNT_adj_2256[2]), .B(CNT1_adj_1997), 
         .C(ZH_FF_adj_1982), .Z(n11998)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4915_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5194_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2257[1]), 
         .D(QS_IN_adj_2258[2]), .Z(n5699)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5194_3_lut_4_lut.init = 16'hf780;
    LUT4 i5192_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2257[2]), 
         .D(QS_IN_adj_2258[3]), .Z(n5697)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5192_3_lut_4_lut.init = 16'hf780;
    LUT4 i4903_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[0]), .C(CNT_adj_2256[0]), 
         .D(SH3), .Z(n12002)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4903_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4903_3_lut_4_lut_else_4_lut (.A(CNT_adj_2256[0]), .B(CNT1_adj_2003), 
         .C(ZH_FF_adj_1982), .Z(n12001)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4903_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4913_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[1]), .C(CNT_adj_2256[1]), 
         .D(SH3), .Z(n12005)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4913_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4913_3_lut_4_lut_else_4_lut (.A(CNT_adj_2256[1]), .B(CNT1_adj_2005), 
         .C(ZH_FF_adj_1982), .Z(n12004)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[51:78])
    defparam i4913_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4770_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[5]), .C(CNT_adj_2259[5]), 
         .D(SH3), .Z(n12008)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i4770_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4770_3_lut_4_lut_else_4_lut (.A(CNT_adj_2259[5]), .B(CNT1_adj_2007), 
         .C(ZH_FF_adj_2008), .Z(n12007)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i4770_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5117_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[4]), .C(CNT_adj_2259[4]), 
         .D(SH3), .Z(n12011)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i5117_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5117_3_lut_4_lut_else_4_lut (.A(CNT_adj_2259[4]), .B(CNT1_adj_2010), 
         .C(ZH_FF_adj_2008), .Z(n12010)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i5117_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5115_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[3]), .C(CNT_adj_2259[3]), 
         .D(SH3), .Z(n12014)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i5115_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5115_3_lut_4_lut_else_4_lut (.A(CNT_adj_2259[3]), .B(CNT1_adj_2012), 
         .C(ZH_FF_adj_2008), .Z(n12013)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i5115_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5109_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[2]), .C(CNT_adj_2259[2]), 
         .D(SH3), .Z(n12017)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i5109_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5109_3_lut_4_lut_else_4_lut (.A(CNT_adj_2259[2]), .B(CNT1_adj_2014), 
         .C(ZH_FF_adj_2008), .Z(n12016)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i5109_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5101_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[1]), .C(CNT_adj_2259[1]), 
         .D(SH3), .Z(n12020)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i5101_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5101_3_lut_4_lut_else_4_lut (.A(CNT_adj_2259[1]), .B(CNT1_adj_2016), 
         .C(ZH_FF_adj_2008), .Z(n12019)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i5101_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4692_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[7]), .C(CNT_adj_2259[7]), 
         .D(SH3), .Z(n12023)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i4692_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4692_3_lut_4_lut_else_4_lut (.A(CNT_adj_2259[7]), .B(CNT1_adj_2018), 
         .C(ZH_FF_adj_2008), .Z(n12022)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i4692_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5093_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[0]), .C(CNT_adj_2259[0]), 
         .D(SH3), .Z(n12026)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i5093_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5093_3_lut_4_lut_else_4_lut (.A(CNT_adj_2259[0]), .B(CNT1_adj_2020), 
         .C(ZH_FF_adj_2008), .Z(n12025)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i5093_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4677_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[6]), .C(CNT_adj_2259[6]), 
         .D(SH3), .Z(n12029)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i4677_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4677_3_lut_4_lut_else_4_lut (.A(CNT_adj_2259[6]), .B(CNT1_adj_2022), 
         .C(ZH_FF_adj_2008), .Z(n12028)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[51:78])
    defparam i4677_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5077_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[7]), .C(CNT_adj_2260[7]), 
         .D(SH3), .Z(n12032)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i5077_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5077_3_lut_4_lut_else_4_lut (.A(CNT_adj_2260[7]), .B(CNT1_adj_2024), 
         .C(ZH_FF_adj_2025), .Z(n12031)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i5077_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4847_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[0]), .C(CNT_adj_2260[0]), 
         .D(SH3), .Z(n12035)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i4847_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4847_3_lut_4_lut_else_4_lut (.A(CNT_adj_2260[0]), .B(CNT1_adj_2027), 
         .C(ZH_FF_adj_2025), .Z(n12034)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i4847_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5001_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[1]), .C(CNT_adj_2260[1]), 
         .D(SH3), .Z(n12038)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i5001_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5001_3_lut_4_lut_else_4_lut (.A(CNT_adj_2260[1]), .B(CNT1_adj_2029), 
         .C(ZH_FF_adj_2025), .Z(n12037)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i5001_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5015_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[5]), .C(CNT_adj_2260[5]), 
         .D(SH3), .Z(n12041)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i5015_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5015_3_lut_4_lut_else_4_lut (.A(CNT_adj_2260[5]), .B(CNT1_adj_2031), 
         .C(ZH_FF_adj_2025), .Z(n12040)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i5015_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    FD1P3AX SH3_279 (.D(SH3_N_1374), .SP(Clk_enable_185), .CK(Clk), .Q(SH3));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam SH3_279.GSR = "DISABLED";
    LUT4 i5041_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[2]), .C(CNT_adj_2260[2]), 
         .D(SH3), .Z(n12044)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i5041_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i5041_3_lut_4_lut_else_4_lut (.A(CNT_adj_2260[2]), .B(CNT1_adj_2033), 
         .C(ZH_FF_adj_2025), .Z(n12043)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i5041_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4659_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[3]), .C(CNT_adj_2260[3]), 
         .D(SH3), .Z(n12047)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i4659_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    FD1P3AX SH5_280 (.D(SH5_N_1378), .SP(Clk_enable_185), .CK(Clk), .Q(SH5));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam SH5_280.GSR = "DISABLED";
    LUT4 i4659_3_lut_4_lut_else_4_lut (.A(CNT_adj_2260[3]), .B(CNT1_adj_2035), 
         .C(ZH_FF_adj_2025), .Z(n12046)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i4659_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4762_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[4]), .C(CNT_adj_2260[4]), 
         .D(SH3), .Z(n12050)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i4762_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4762_3_lut_4_lut_else_4_lut (.A(CNT_adj_2260[4]), .B(CNT1_adj_2037), 
         .C(ZH_FF_adj_2025), .Z(n12049)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i4762_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5043_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[6]), .C(CNT_adj_2260[6]), 
         .D(SH3), .Z(n12053)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i5043_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    FD1P3AX SH7_281 (.D(SH7_N_1383), .SP(Clk_enable_185), .CK(Clk), .Q(SH7));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam SH7_281.GSR = "DISABLED";
    LUT4 i5043_3_lut_4_lut_else_4_lut (.A(CNT_adj_2260[6]), .B(CNT1_adj_2039), 
         .C(ZH_FF_adj_2025), .Z(n12052)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[51:78])
    defparam i5043_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4889_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[7]), .C(CNT[7]), 
         .D(SH3), .Z(n12056)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4889_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4889_3_lut_4_lut_else_4_lut (.A(CNT[7]), .B(CNT1_adj_2041), .C(ZH_FF), 
         .Z(n12055)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4889_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i5190_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2257[3]), 
         .D(QS_IN_adj_2258[4]), .Z(n5695)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5190_3_lut_4_lut.init = 16'hf780;
    LUT4 i5188_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2257[4]), 
         .D(QS_IN_adj_2258[5]), .Z(n5693)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5188_3_lut_4_lut.init = 16'hf780;
    LUT4 i4885_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[6]), .C(CNT[6]), 
         .D(SH3), .Z(n12059)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4885_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4885_3_lut_4_lut_else_4_lut (.A(CNT[6]), .B(CNT1_adj_2047), .C(ZH_FF), 
         .Z(n12058)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4885_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4700_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[7]), .C(SDATA[7]), 
         .D(n5204), .Z(n5205)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1363[53:80])
    defparam i4700_3_lut_4_lut.init = 16'hf780;
    LUT4 i5186_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2257[5]), 
         .D(QS_IN_adj_2258[6]), .Z(n5691)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5186_3_lut_4_lut.init = 16'hf780;
    LUT4 i5184_3_lut_4_lut (.A(n12292), .B(EN[0]), .C(QP_adj_2257[6]), 
         .D(QS_IN_adj_2258[7]), .Z(n5689)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[30:44])
    defparam i5184_3_lut_4_lut.init = 16'hf780;
    LUT4 i4705_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[7]), .C(SDATA[6]), 
         .D(n5209), .Z(n5210)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1363[53:80])
    defparam i4705_3_lut_4_lut.init = 16'hf780;
    LUT4 i4711_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[7]), .C(SDATA[5]), 
         .D(n5215), .Z(n5216)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1363[53:80])
    defparam i4711_3_lut_4_lut.init = 16'hf780;
    LUT4 i4723_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[7]), .C(SDATA[4]), 
         .D(n5227), .Z(n5228)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1363[53:80])
    defparam i4723_3_lut_4_lut.init = 16'hf780;
    LUT4 i4727_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[7]), .C(SDATA[3]), 
         .D(n5231), .Z(n5232)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1363[53:80])
    defparam i4727_3_lut_4_lut.init = 16'hf780;
    LUT4 i4731_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[7]), .C(SDATA[2]), 
         .D(n5235), .Z(n5236)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1363[53:80])
    defparam i4731_3_lut_4_lut.init = 16'hf780;
    LUT4 i4735_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[7]), .C(SDATA[1]), 
         .D(n5239), .Z(n5240)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1363[53:80])
    defparam i4735_3_lut_4_lut.init = 16'hf780;
    LUT4 i4739_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[7]), .C(SDATA[7]), 
         .D(n5243), .Z(n5244)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[53:80])
    defparam i4739_3_lut_4_lut.init = 16'hf780;
    LUT4 i4746_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[7]), .C(SDATA[6]), 
         .D(n5250), .Z(n5251)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[53:80])
    defparam i4746_3_lut_4_lut.init = 16'hf780;
    LUT4 i4748_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[7]), .C(SDATA[5]), 
         .D(n5252), .Z(n5253)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[53:80])
    defparam i4748_3_lut_4_lut.init = 16'hf780;
    LUT4 i4756_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[7]), .C(SDATA[4]), 
         .D(n5260), .Z(n5261)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[53:80])
    defparam i4756_3_lut_4_lut.init = 16'hf780;
    FD1P3AX MIRR_LATCH_292 (.D(OB[6]), .SP(Clk_enable_208), .CK(Clk), 
            .Q(MIRR_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam MIRR_LATCH_292.GSR = "DISABLED";
    LUT4 i4760_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[7]), .C(SDATA[3]), 
         .D(n5264), .Z(n5265)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[53:80])
    defparam i4760_3_lut_4_lut.init = 16'hf780;
    LUT4 i4764_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[7]), .C(SDATA[2]), 
         .D(n5268), .Z(n5269)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[53:80])
    defparam i4764_3_lut_4_lut.init = 16'hf780;
    LUT4 i4772_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[7]), .C(SDATA[1]), 
         .D(n5276), .Z(n5277)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[53:80])
    defparam i4772_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_FIFO_I_0_i1_2_lut (.A(PD_FIFO), .B(PD_LATCH[0]), .Z(SDATA[0])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1345[21:51])
    defparam PD_FIFO_I_0_i1_2_lut.init = 16'h8888;
    LUT4 i4774_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[6]), .C(SDATA[7]), 
         .D(n5278), .Z(n5279)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1361[53:80])
    defparam i4774_3_lut_4_lut.init = 16'hf780;
    LUT4 i4778_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[6]), .C(SDATA[6]), 
         .D(n5282), .Z(n5283)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1361[53:80])
    defparam i4778_3_lut_4_lut.init = 16'hf780;
    LUT4 i4787_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[6]), .C(SDATA[5]), 
         .D(n5291), .Z(n5292)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1361[53:80])
    defparam i4787_3_lut_4_lut.init = 16'hf780;
    LUT4 i4795_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[6]), .C(SDATA[4]), 
         .D(n5299), .Z(n5300)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1361[53:80])
    defparam i4795_3_lut_4_lut.init = 16'hf780;
    LUT4 i10566_3_lut_4_lut (.A(n11799), .B(n11713), .C(ZCOL_4__N_1330[0]), 
         .D(n326[0]), .Z(ZCOL_4__N_1145[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1376[20] 1383[28])
    defparam i10566_3_lut_4_lut.init = 16'hf1e0;
    FD1P3AX ZPOS_i2 (.D(ZPOS[1]), .SP(Clk_enable_530), .CK(Clk), .Q(ZPOS[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ZPOS_i2.GSR = "DISABLED";
    LUT4 i10564_3_lut_4_lut (.A(n11799), .B(n11713), .C(ZCOL_4__N_1330[1]), 
         .D(n326[1]), .Z(ZCOL_4__N_1145[1])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1376[20] 1383[28])
    defparam i10564_3_lut_4_lut.init = 16'hf1e0;
    FD1P3AX ZPOS_i1 (.D(ZPOS[0]), .SP(Clk_enable_549), .CK(Clk), .Q(ZPOS[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ZPOS_i1.GSR = "DISABLED";
    LUT4 i4797_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[6]), .C(SDATA[3]), 
         .D(n5301), .Z(n5302)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1361[53:80])
    defparam i4797_3_lut_4_lut.init = 16'hf780;
    LUT4 i4803_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[6]), .C(SDATA[2]), 
         .D(n5307), .Z(n5308)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1361[53:80])
    defparam i4803_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR_IN7_i0_i2 (.D(OB[5]), .SP(ATR_IN7_2__N_1361), .CK(Clk), 
            .Q(ATR_IN7[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN7_i0_i2.GSR = "DISABLED";
    LUT4 i4811_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[6]), .C(SDATA[1]), 
         .D(n5315), .Z(n5316)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1361[53:80])
    defparam i4811_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR_IN7_i0_i1 (.D(OB[1]), .SP(ATR_IN7_2__N_1361), .CK(Clk), 
            .Q(ATR_IN7[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN7_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN6_i0_i2 (.D(OB[5]), .SP(ATR_IN6_2__N_1360), .CK(Clk), 
            .Q(ATR_IN6[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN6_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN6_i0_i1 (.D(OB[1]), .SP(ATR_IN6_2__N_1360), .CK(Clk), 
            .Q(ATR_IN6[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN6_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN5_i0_i2 (.D(OB[5]), .SP(ATR_IN5_2__N_1359), .CK(Clk), 
            .Q(ATR_IN5[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN5_i0_i2.GSR = "DISABLED";
    LUT4 i4813_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[6]), .C(SDATA[7]), 
         .D(n5317), .Z(n5318)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[53:80])
    defparam i4813_3_lut_4_lut.init = 16'hf780;
    LUT4 i4815_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[6]), .C(SDATA[6]), 
         .D(n5319), .Z(n5320)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[53:80])
    defparam i4815_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR_IN5_i0_i1 (.D(OB[1]), .SP(ATR_IN5_2__N_1359), .CK(Clk), 
            .Q(ATR_IN5[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN5_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN4_i0_i2 (.D(OB[5]), .SP(ATR_IN4_2__N_1358), .CK(Clk), 
            .Q(ATR_IN4[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN4_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN4_i0_i1 (.D(OB[1]), .SP(ATR_IN4_2__N_1358), .CK(Clk), 
            .Q(ATR_IN4[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN4_i0_i1.GSR = "DISABLED";
    LUT4 i10797_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n12292), .B(SH3), .C(SEL_LATCH[1]), 
         .D(ZH_FF), .Z(CNT_7__N_1385)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[52:62])
    defparam i10797_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    FD1P3AX ATR_IN3_i0_i2 (.D(OB[5]), .SP(ATR_IN3_2__N_1357), .CK(Clk), 
            .Q(ATR_IN3[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN3_i0_i2.GSR = "DISABLED";
    LUT4 i4865_3_lut_4_lut_else_4_lut (.A(CNT[3]), .B(CNT1_adj_2053), .C(ZH_FF), 
         .Z(n11851)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4865_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    FD1P3AX ATR_IN3_i0_i1 (.D(OB[1]), .SP(ATR_IN3_2__N_1357), .CK(Clk), 
            .Q(ATR_IN3[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN3_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN2_i0_i2 (.D(OB[5]), .SP(ATR_IN2_2__N_1356), .CK(Clk), 
            .Q(ATR_IN2[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN2_i0_i2.GSR = "DISABLED";
    LUT4 i4817_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[6]), .C(SDATA[5]), 
         .D(n5321), .Z(n5322)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[53:80])
    defparam i4817_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR_IN2_i0_i1 (.D(OB[1]), .SP(ATR_IN2_2__N_1356), .CK(Clk), 
            .Q(ATR_IN2[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN2_i0_i1.GSR = "DISABLED";
    LUT4 i4819_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[6]), .C(SDATA[4]), 
         .D(n5323), .Z(n5324)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[53:80])
    defparam i4819_3_lut_4_lut.init = 16'hf780;
    LUT4 i4823_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[6]), .C(SDATA[3]), 
         .D(n5327), .Z(n5328)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[53:80])
    defparam i4823_3_lut_4_lut.init = 16'hf780;
    LUT4 i4831_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[6]), .C(SDATA[2]), 
         .D(n5335), .Z(n5336)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[53:80])
    defparam i4831_3_lut_4_lut.init = 16'hf780;
    LUT4 i4835_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[6]), .C(SDATA[1]), 
         .D(n5339), .Z(n5340)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[53:80])
    defparam i4835_3_lut_4_lut.init = 16'hf780;
    LUT4 i4839_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[5]), .C(SDATA[7]), 
         .D(n5343), .Z(n5344)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1359[53:80])
    defparam i4839_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR_IN1_i0_i2 (.D(OB[5]), .SP(ATR_IN1_2__N_1355), .CK(Clk), 
            .Q(ATR_IN1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN1_i0_i2.GSR = "DISABLED";
    LUT4 i4841_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[5]), .C(SDATA[6]), 
         .D(n5345), .Z(n5346)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1359[53:80])
    defparam i4841_3_lut_4_lut.init = 16'hf780;
    LUT4 i4845_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[5]), .C(SDATA[5]), 
         .D(n5349), .Z(n5350)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1359[53:80])
    defparam i4845_3_lut_4_lut.init = 16'hf780;
    LUT4 i4877_3_lut_4_lut_else_4_lut (.A(CNT[5]), .B(CNT1_adj_2054), .C(ZH_FF), 
         .Z(n11845)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4877_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    FD1P3AX ATR_IN1_i0_i1 (.D(OB[1]), .SP(ATR_IN1_2__N_1355), .CK(Clk), 
            .Q(ATR_IN1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR_IN1_i0_i1.GSR = "DISABLED";
    LUT4 PD_7__I_0_i4_3_lut (.A(PD_out_3), .B(PD_out_4), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1332[24:96])
    defparam PD_7__I_0_i4_3_lut.init = 16'hcaca;
    LUT4 i4849_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[5]), .C(SDATA[4]), 
         .D(n5353), .Z(n5354)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1359[53:80])
    defparam i4849_3_lut_4_lut.init = 16'hf780;
    LUT4 i4855_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[5]), .C(SDATA[3]), 
         .D(n5359), .Z(n5360)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1359[53:80])
    defparam i4855_3_lut_4_lut.init = 16'hf780;
    LUT4 i4859_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[5]), .C(SDATA[2]), 
         .D(n5363), .Z(n5364)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1359[53:80])
    defparam i4859_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR7_i0_i2 (.D(ATR_IN7[2]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR7[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR7_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR7_i0_i1 (.D(ATR_IN7[1]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR7[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR7_i0_i1.GSR = "DISABLED";
    LUT4 i4863_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[5]), .C(SDATA[1]), 
         .D(n5367), .Z(n5368)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1359[53:80])
    defparam i4863_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR6_i0_i2 (.D(ATR_IN6[2]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR6[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR6_i0_i2.GSR = "DISABLED";
    LUT4 i4867_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[5]), .C(SDATA[7]), 
         .D(n5371), .Z(n5372)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[53:80])
    defparam i4867_3_lut_4_lut.init = 16'hf780;
    LUT4 i4871_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[5]), .C(SDATA[6]), 
         .D(n5375), .Z(n5376)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[53:80])
    defparam i4871_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR6_i0_i1 (.D(ATR_IN6[1]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR6[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR6_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR5_i0_i2 (.D(ATR_IN5[2]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR5[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR5_i0_i2.GSR = "DISABLED";
    LUT4 i4875_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[5]), .C(SDATA[5]), 
         .D(n5379), .Z(n5380)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[53:80])
    defparam i4875_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR5_i0_i1 (.D(ATR_IN5[1]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR5[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR5_i0_i1.GSR = "DISABLED";
    LUT4 i4879_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[5]), .C(SDATA[4]), 
         .D(n5383), .Z(n5384)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[53:80])
    defparam i4879_3_lut_4_lut.init = 16'hf780;
    LUT4 i4883_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[5]), .C(SDATA[3]), 
         .D(n5387), .Z(n5388)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[53:80])
    defparam i4883_3_lut_4_lut.init = 16'hf780;
    LUT4 i4887_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[5]), .C(SDATA[2]), 
         .D(n5391), .Z(n5392)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[53:80])
    defparam i4887_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR4_i0_i2 (.D(ATR_IN4[2]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR4[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR4_i0_i2.GSR = "DISABLED";
    LUT4 i4897_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[5]), .C(SDATA[1]), 
         .D(n5401), .Z(n5402)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[53:80])
    defparam i4897_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR4_i0_i1 (.D(ATR_IN4[1]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR4[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR4_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR3_i0_i2 (.D(ATR_IN3[2]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR3[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR3_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR3_i0_i1 (.D(ATR_IN3[1]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR3[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR3_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR2_i0_i2 (.D(ATR_IN2[2]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR2[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR2_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR2_i0_i1 (.D(ATR_IN2[1]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR2[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR2_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR1_i0_i2 (.D(ATR_IN1[2]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR1_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR1_i0_i1 (.D(ATR_IN1[1]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR1_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR0_i0_i2 (.D(ATR_IN0[2]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(ATR0[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR0_i0_i2.GSR = "DISABLED";
    LUT4 mux_155_i2_3_lut_4_lut (.A(n7704), .B(n11718), .C(COL1[4]), .D(COL1[5]), 
         .Z(n332[1])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_155_i2_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_155_i1_3_lut_4_lut (.A(n7704), .B(n11718), .C(COL0[4]), .D(COL0[5]), 
         .Z(n332[0])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_155_i1_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_3_lut_rep_351 (.A(EN[3]), .B(COL0[3]), .C(COL1[3]), .Z(n11827)) /* synthesis lut_function=(A (B+(C))) */ ;
    defparam i1_3_lut_rep_351.init = 16'ha8a8;
    LUT4 i7460_2_lut_4_lut (.A(EN[3]), .B(COL0[3]), .C(COL1[3]), .D(n7900), 
         .Z(n7952)) /* synthesis lut_function=(A (B+(C+(D)))+!A (D)) */ ;
    defparam i7460_2_lut_4_lut.init = 16'hffa8;
    FD1P3AX ATR0_i0_i1 (.D(ATR_IN0[1]), .SP(Clk_enable_423), .CK(Clk), 
            .Q(ATR0[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam ATR0_i0_i1.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i7 (.D(MIRR_MUX[7]), .SP(Clk_enable_423), .CK(Clk), 
            .Q(PD_LATCH[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam PD_LATCH_i0_i7.GSR = "DISABLED";
    LUT4 mux_155_i3_3_lut_4_lut (.A(n7704), .B(n11718), .C(ATR4[0]), .D(ATR5[0]), 
         .Z(n332[2])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_155_i3_3_lut_4_lut.init = 16'hf780;
    FD1P3AX PD_LATCH_i0_i6 (.D(MIRR_MUX[6]), .SP(Clk_enable_423), .CK(Clk), 
            .Q(PD_LATCH[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam PD_LATCH_i0_i6.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i5 (.D(MIRR_MUX[5]), .SP(Clk_enable_423), .CK(Clk), 
            .Q(PD_LATCH[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam PD_LATCH_i0_i5.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i4 (.D(MIRR_MUX[4]), .SP(Clk_enable_423), .CK(Clk), 
            .Q(PD_LATCH[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam PD_LATCH_i0_i4.GSR = "DISABLED";
    LUT4 i4907_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[4]), .C(SDATA[7]), 
         .D(n5411), .Z(n5412)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1357[53:80])
    defparam i4907_3_lut_4_lut.init = 16'hf780;
    LUT4 i4917_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[4]), .C(SDATA[6]), 
         .D(n5421), .Z(n5422)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1357[53:80])
    defparam i4917_3_lut_4_lut.init = 16'hf780;
    FD1P3AX PD_LATCH_i0_i3 (.D(MIRR_MUX[3]), .SP(Clk_enable_423), .CK(Clk), 
            .Q(PD_LATCH[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam PD_LATCH_i0_i3.GSR = "DISABLED";
    LUT4 i4929_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[4]), .C(SDATA[5]), 
         .D(n5433), .Z(n5434)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1357[53:80])
    defparam i4929_3_lut_4_lut.init = 16'hf780;
    LUT4 i4943_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[4]), .C(SDATA[4]), 
         .D(n5447), .Z(n5448)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1357[53:80])
    defparam i4943_3_lut_4_lut.init = 16'hf780;
    LUT4 i4953_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[4]), .C(SDATA[3]), 
         .D(n5457), .Z(n5458)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1357[53:80])
    defparam i4953_3_lut_4_lut.init = 16'hf780;
    FD1P3AX PD_LATCH_i0_i2 (.D(MIRR_MUX[2]), .SP(Clk_enable_423), .CK(Clk), 
            .Q(PD_LATCH[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam PD_LATCH_i0_i2.GSR = "DISABLED";
    LUT4 i4957_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[4]), .C(SDATA[2]), 
         .D(n5461), .Z(n5462)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1357[53:80])
    defparam i4957_3_lut_4_lut.init = 16'hf780;
    LUT4 i4961_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[4]), .C(SDATA[1]), 
         .D(n5465), .Z(n5466)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1357[53:80])
    defparam i4961_3_lut_4_lut.init = 16'hf780;
    FD1P3AX PD_LATCH_i0_i1 (.D(MIRR_MUX[1]), .SP(Clk_enable_423), .CK(Clk), 
            .Q(PD_LATCH[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam PD_LATCH_i0_i1.GSR = "DISABLED";
    LUT4 i4964_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[4]), .C(SDATA[7]), 
         .D(n5468), .Z(n5469)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[53:80])
    defparam i4964_3_lut_4_lut.init = 16'hf780;
    LUT4 i4968_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[4]), .C(SDATA[6]), 
         .D(n5472), .Z(n5473)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[53:80])
    defparam i4968_3_lut_4_lut.init = 16'hf780;
    LUT4 i4973_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[4]), .C(SDATA[5]), 
         .D(n5477), .Z(n5478)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[53:80])
    defparam i4973_3_lut_4_lut.init = 16'hf780;
    LUT4 i4977_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[4]), .C(SDATA[4]), 
         .D(n5481), .Z(n5482)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[53:80])
    defparam i4977_3_lut_4_lut.init = 16'hf780;
    LUT4 i4980_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[4]), .C(SDATA[3]), 
         .D(n5484), .Z(n5485)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[53:80])
    defparam i4980_3_lut_4_lut.init = 16'hf780;
    LUT4 i4982_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[4]), .C(SDATA[2]), 
         .D(n5486), .Z(n5487)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[53:80])
    defparam i4982_3_lut_4_lut.init = 16'hf780;
    LUT4 i4993_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[4]), .C(SDATA[1]), 
         .D(n5497), .Z(n5498)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[53:80])
    defparam i4993_3_lut_4_lut.init = 16'hf780;
    LUT4 i4997_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[3]), .C(SDATA[7]), 
         .D(n5501), .Z(n5502)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1355[53:80])
    defparam i4997_3_lut_4_lut.init = 16'hf780;
    LUT4 i10819_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n12292), .B(SH3), .C(SEL_LATCH[5]), 
         .D(ZH_FF_adj_2025), .Z(CNT_7__N_1385_adj_2055)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[52:62])
    defparam i10819_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    LUT4 i10830_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n12292), .B(SH3), .C(SEL_LATCH[7]), 
         .D(ZH_FF_adj_2008), .Z(CNT_7__N_1385_adj_2056)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[52:62])
    defparam i10830_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    LUT4 i10791_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n12292), .B(SH3), .C(SEL_LATCH[0]), 
         .D(ZH_FF_adj_1982), .Z(CNT_7__N_1385_adj_2057)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[52:62])
    defparam i10791_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    LUT4 i5003_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[3]), .C(SDATA[6]), 
         .D(n5507), .Z(n5508)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1355[53:80])
    defparam i5003_3_lut_4_lut.init = 16'hf780;
    LUT4 i10825_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n12292), .B(SH3), .C(SEL_LATCH[6]), 
         .D(ZH_FF_adj_1965), .Z(CNT_7__N_1385_adj_2058)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[52:62])
    defparam i10825_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    LUT4 i5005_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[3]), .C(SDATA[5]), 
         .D(n5509), .Z(n5510)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1355[53:80])
    defparam i5005_3_lut_4_lut.init = 16'hf780;
    LUT4 i5007_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[3]), .C(SDATA[4]), 
         .D(n5511), .Z(n5512)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1355[53:80])
    defparam i5007_3_lut_4_lut.init = 16'hf780;
    LUT4 i5009_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[3]), .C(SDATA[3]), 
         .D(n5513), .Z(n5514)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1355[53:80])
    defparam i5009_3_lut_4_lut.init = 16'hf780;
    LUT4 i5011_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[3]), .C(SDATA[2]), 
         .D(n5515), .Z(n5516)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1355[53:80])
    defparam i5011_3_lut_4_lut.init = 16'hf780;
    LUT4 i5017_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[3]), .C(SDATA[1]), 
         .D(n5521), .Z(n5522)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1355[53:80])
    defparam i5017_3_lut_4_lut.init = 16'hf780;
    LUT4 PCLK_I_0_315_2_lut_rep_297 (.A(n12292), .B(EN[4]), .Z(n11773)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam PCLK_I_0_315_2_lut_rep_297.init = 16'h8888;
    LUT4 i4992_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2261[0]), 
         .D(QS_IN_adj_2262[1]), .Z(n5497)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4992_3_lut_4_lut.init = 16'hf780;
    LUT4 i5019_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[3]), .C(SDATA[7]), 
         .D(n5523), .Z(n5524)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[53:80])
    defparam i5019_3_lut_4_lut.init = 16'hf780;
    LUT4 i5021_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[3]), .C(SDATA[6]), 
         .D(n5525), .Z(n5526)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[53:80])
    defparam i5021_3_lut_4_lut.init = 16'hf780;
    LUT4 i5119_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[3]), .C(SDATA[5]), 
         .D(n5623), .Z(n5624)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[53:80])
    defparam i5119_3_lut_4_lut.init = 16'hf780;
    LUT4 i5121_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[3]), .C(SDATA[4]), 
         .D(n5625), .Z(n5626)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[53:80])
    defparam i5121_3_lut_4_lut.init = 16'hf780;
    LUT4 i5123_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[3]), .C(SDATA[3]), 
         .D(n5627), .Z(n5628)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[53:80])
    defparam i5123_3_lut_4_lut.init = 16'hf780;
    LUT4 i4865_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[3]), .C(CNT[3]), 
         .D(SH3), .Z(n11852)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4865_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4981_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2261[1]), 
         .D(QS_IN_adj_2262[2]), .Z(n5486)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4981_3_lut_4_lut.init = 16'hf780;
    LUT4 i5125_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[3]), .C(SDATA[2]), 
         .D(n5629), .Z(n5630)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[53:80])
    defparam i5125_3_lut_4_lut.init = 16'hf780;
    LUT4 i4979_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2261[2]), 
         .D(QS_IN_adj_2262[3]), .Z(n5484)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4979_3_lut_4_lut.init = 16'hf780;
    LUT4 i7421_3_lut_rep_361 (.A(COL0[0]), .B(EN[0]), .C(COL1[0]), .Z(n11837)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam i7421_3_lut_rep_361.init = 16'hc8c8;
    LUT4 i7173_2_lut_rep_317_4_lut (.A(COL0[0]), .B(EN[0]), .C(COL1[0]), 
         .D(CLIPOR), .Z(n11793)) /* synthesis lut_function=(!(A (B+!(D))+!A (B (C+!(D))+!B !(D)))) */ ;
    defparam i7173_2_lut_rep_317_4_lut.init = 16'h3700;
    LUT4 i5127_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[3]), .C(SDATA[1]), 
         .D(n5631), .Z(n5632)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[53:80])
    defparam i5127_3_lut_4_lut.init = 16'hf780;
    LUT4 i5129_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[2]), .C(SDATA[7]), 
         .D(n5633), .Z(n5634)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1353[53:80])
    defparam i5129_3_lut_4_lut.init = 16'hf780;
    LUT4 i7466_2_lut_rep_323_4_lut (.A(COL0[0]), .B(EN[0]), .C(COL1[0]), 
         .D(CLIPOR), .Z(n11799)) /* synthesis lut_function=(A (B (D))+!A (B (C (D)))) */ ;
    defparam i7466_2_lut_rep_323_4_lut.init = 16'hc800;
    LUT4 PD_7__I_0_i1_3_lut (.A(PD_out_0), .B(PD_out_7), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1332[24:96])
    defparam PD_7__I_0_i1_3_lut.init = 16'hcaca;
    LUT4 i5131_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[2]), .C(SDATA[6]), 
         .D(n5635), .Z(n5636)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1353[53:80])
    defparam i5131_3_lut_4_lut.init = 16'hf780;
    LUT4 i5133_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[2]), .C(SDATA[5]), 
         .D(n5637), .Z(n5638)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1353[53:80])
    defparam i5133_3_lut_4_lut.init = 16'hf780;
    LUT4 i5135_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[2]), .C(SDATA[4]), 
         .D(n5639), .Z(n5640)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1353[53:80])
    defparam i5135_3_lut_4_lut.init = 16'hf780;
    LUT4 i5137_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[2]), .C(SDATA[3]), 
         .D(n5641), .Z(n5642)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1353[53:80])
    defparam i5137_3_lut_4_lut.init = 16'hf780;
    LUT4 i5139_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[2]), .C(SDATA[2]), 
         .D(n5643), .Z(n5644)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1353[53:80])
    defparam i5139_3_lut_4_lut.init = 16'hf780;
    LUT4 i5141_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[2]), .C(SDATA[1]), 
         .D(n5645), .Z(n5646)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1353[53:80])
    defparam i5141_3_lut_4_lut.init = 16'hf780;
    LUT4 i5143_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[2]), .C(SDATA[7]), 
         .D(n5647), .Z(n5648)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[53:80])
    defparam i5143_3_lut_4_lut.init = 16'hf780;
    LUT4 i5145_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[2]), .C(SDATA[6]), 
         .D(n5649), .Z(n5650)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[53:80])
    defparam i5145_3_lut_4_lut.init = 16'hf780;
    LUT4 i5147_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[2]), .C(SDATA[5]), 
         .D(n5651), .Z(n5652)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[53:80])
    defparam i5147_3_lut_4_lut.init = 16'hf780;
    LUT4 i4976_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2261[3]), 
         .D(QS_IN_adj_2262[4]), .Z(n5481)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4976_3_lut_4_lut.init = 16'hf780;
    LUT4 i4972_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2261[4]), 
         .D(QS_IN_adj_2262[5]), .Z(n5477)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4972_3_lut_4_lut.init = 16'hf780;
    LUT4 i4967_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2261[5]), 
         .D(QS_IN_adj_2262[6]), .Z(n5472)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4967_3_lut_4_lut.init = 16'hf780;
    LUT4 i4963_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2261[6]), 
         .D(QS_IN_adj_2262[7]), .Z(n5468)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4963_3_lut_4_lut.init = 16'hf780;
    LUT4 i5149_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[2]), .C(SDATA[4]), 
         .D(n5653), .Z(n5654)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[53:80])
    defparam i5149_3_lut_4_lut.init = 16'hf780;
    LUT4 i5151_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[2]), .C(SDATA[3]), 
         .D(n5655), .Z(n5656)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[53:80])
    defparam i5151_3_lut_4_lut.init = 16'hf780;
    LUT4 i4960_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2263[0]), 
         .D(QS_IN_adj_2264[1]), .Z(n5465)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4960_3_lut_4_lut.init = 16'hf780;
    LUT4 i4956_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2263[1]), 
         .D(QS_IN_adj_2264[2]), .Z(n5461)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4956_3_lut_4_lut.init = 16'hf780;
    LUT4 i5153_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[2]), .C(SDATA[2]), 
         .D(n5657), .Z(n5658)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[53:80])
    defparam i5153_3_lut_4_lut.init = 16'hf780;
    LUT4 i5155_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[2]), .C(SDATA[1]), 
         .D(n5659), .Z(n5660)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[53:80])
    defparam i5155_3_lut_4_lut.init = 16'hf780;
    LUT4 i5157_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[1]), .C(SDATA[7]), 
         .D(n5661), .Z(n5662)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1351[53:80])
    defparam i5157_3_lut_4_lut.init = 16'hf780;
    LUT4 i5159_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[1]), .C(SDATA[6]), 
         .D(n5663), .Z(n5664)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1351[53:80])
    defparam i5159_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_155_i4_3_lut_4_lut (.A(n7704), .B(n11718), .C(ATR4[1]), .D(ATR5[1]), 
         .Z(n332[3])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_155_i4_3_lut_4_lut.init = 16'hf780;
    LUT4 i5161_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[1]), .C(SDATA[5]), 
         .D(n5665), .Z(n5666)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1351[53:80])
    defparam i5161_3_lut_4_lut.init = 16'hf780;
    LUT4 i5163_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[1]), .C(SDATA[4]), 
         .D(n5667), .Z(n5668)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1351[53:80])
    defparam i5163_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_155_i5_3_lut_4_lut (.A(n7704), .B(n11718), .C(ATR4[2]), .D(ATR5[2]), 
         .Z(n332[4])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_155_i5_3_lut_4_lut.init = 16'hf780;
    LUT4 i5165_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[1]), .C(SDATA[3]), 
         .D(n5669), .Z(n5670)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1351[53:80])
    defparam i5165_3_lut_4_lut.init = 16'hf780;
    LUT4 i5167_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[1]), .C(SDATA[2]), 
         .D(n5671), .Z(n5672)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1351[53:80])
    defparam i5167_3_lut_4_lut.init = 16'hf780;
    LUT4 i5169_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[1]), .C(SDATA[1]), 
         .D(n5673), .Z(n5674)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1351[53:80])
    defparam i5169_3_lut_4_lut.init = 16'hf780;
    LUT4 i5171_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[1]), .C(SDATA[7]), 
         .D(n5675), .Z(n5676)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[53:80])
    defparam i5171_3_lut_4_lut.init = 16'hf780;
    LUT4 i5173_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[1]), .C(SDATA[6]), 
         .D(n5677), .Z(n5678)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[53:80])
    defparam i5173_3_lut_4_lut.init = 16'hf780;
    LUT4 i5175_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[1]), .C(SDATA[5]), 
         .D(n5679), .Z(n5680)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[53:80])
    defparam i5175_3_lut_4_lut.init = 16'hf780;
    LUT4 i5177_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[1]), .C(SDATA[4]), 
         .D(n5681), .Z(n5682)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[53:80])
    defparam i5177_3_lut_4_lut.init = 16'hf780;
    LUT4 i5179_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[1]), .C(SDATA[3]), 
         .D(n5683), .Z(n5684)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[53:80])
    defparam i5179_3_lut_4_lut.init = 16'hf780;
    LUT4 i5181_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[1]), .C(SDATA[2]), 
         .D(n5685), .Z(n5686)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[53:80])
    defparam i5181_3_lut_4_lut.init = 16'hf780;
    LUT4 i5183_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[1]), .C(SDATA[1]), 
         .D(n5687), .Z(n5688)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[53:80])
    defparam i5183_3_lut_4_lut.init = 16'hf780;
    LUT4 i5185_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[0]), .C(SDATA[7]), 
         .D(n5689), .Z(n5690)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[53:80])
    defparam i5185_3_lut_4_lut.init = 16'hf780;
    LUT4 i5187_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[0]), .C(SDATA[6]), 
         .D(n5691), .Z(n5692)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[53:80])
    defparam i5187_3_lut_4_lut.init = 16'hf780;
    LUT4 i5189_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[0]), .C(SDATA[5]), 
         .D(n5693), .Z(n5694)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[53:80])
    defparam i5189_3_lut_4_lut.init = 16'hf780;
    LUT4 i5191_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[0]), .C(SDATA[4]), 
         .D(n5695), .Z(n5696)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[53:80])
    defparam i5191_3_lut_4_lut.init = 16'hf780;
    LUT4 i5193_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[0]), .C(SDATA[3]), 
         .D(n5697), .Z(n5698)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[53:80])
    defparam i5193_3_lut_4_lut.init = 16'hf780;
    LUT4 i5195_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[0]), .C(SDATA[2]), 
         .D(n5699), .Z(n5700)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[53:80])
    defparam i5195_3_lut_4_lut.init = 16'hf780;
    LUT4 i5197_3_lut_4_lut (.A(n11777), .B(SEL_LATCH[0]), .C(SDATA[1]), 
         .D(n5701), .Z(n5702)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[53:80])
    defparam i5197_3_lut_4_lut.init = 16'hf780;
    LUT4 i5199_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[0]), .C(SDATA[7]), 
         .D(n5703), .Z(n5704)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[53:80])
    defparam i5199_3_lut_4_lut.init = 16'hf780;
    LUT4 i5201_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[0]), .C(SDATA[6]), 
         .D(n5705), .Z(n5706)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[53:80])
    defparam i5201_3_lut_4_lut.init = 16'hf780;
    LUT4 i5203_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[0]), .C(SDATA[5]), 
         .D(n5707), .Z(n5708)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[53:80])
    defparam i5203_3_lut_4_lut.init = 16'hf780;
    LUT4 i5205_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[0]), .C(SDATA[4]), 
         .D(n5709), .Z(n5710)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[53:80])
    defparam i5205_3_lut_4_lut.init = 16'hf780;
    LUT4 i5207_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[0]), .C(SDATA[3]), 
         .D(n5711), .Z(n5712)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[53:80])
    defparam i5207_3_lut_4_lut.init = 16'hf780;
    LUT4 i5209_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[0]), .C(SDATA[2]), 
         .D(n5713), .Z(n5714)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[53:80])
    defparam i5209_3_lut_4_lut.init = 16'hf780;
    LUT4 i5211_3_lut_4_lut (.A(n11778), .B(SEL_LATCH[0]), .C(SDATA[1]), 
         .D(n5715), .Z(n5716)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[53:80])
    defparam i5211_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_FIFO_I_0_i2_2_lut (.A(PD_FIFO), .B(PD_LATCH[1]), .Z(SDATA[1])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1345[21:51])
    defparam PD_FIFO_I_0_i2_2_lut.init = 16'h8888;
    LUT4 PD_FIFO_I_0_i3_2_lut (.A(PD_FIFO), .B(PD_LATCH[2]), .Z(SDATA[2])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1345[21:51])
    defparam PD_FIFO_I_0_i3_2_lut.init = 16'h8888;
    LUT4 PD_FIFO_I_0_i4_2_lut (.A(PD_FIFO), .B(PD_LATCH[3]), .Z(SDATA[3])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1345[21:51])
    defparam PD_FIFO_I_0_i4_2_lut.init = 16'h8888;
    LUT4 PD_FIFO_I_0_i5_2_lut (.A(PD_FIFO), .B(PD_LATCH[4]), .Z(SDATA[4])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1345[21:51])
    defparam PD_FIFO_I_0_i5_2_lut.init = 16'h8888;
    LUT4 PD_FIFO_I_0_i6_2_lut (.A(PD_FIFO), .B(PD_LATCH[5]), .Z(SDATA[5])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1345[21:51])
    defparam PD_FIFO_I_0_i6_2_lut.init = 16'h8888;
    LUT4 i4873_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[4]), .C(CNT[4]), 
         .D(SH3), .Z(n11849)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4873_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4873_3_lut_4_lut_else_4_lut (.A(CNT[4]), .B(CNT1_adj_2078), .C(ZH_FF), 
         .Z(n11848)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[51:78])
    defparam i4873_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 PD_FIFO_I_0_i7_2_lut (.A(PD_FIFO), .B(PD_LATCH[6]), .Z(SDATA[6])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1345[21:51])
    defparam PD_FIFO_I_0_i7_2_lut.init = 16'h8888;
    LUT4 i10887_4_lut (.A(n11759), .B(n11758), .C(n10759), .D(n10919), 
         .Z(n11353)) /* synthesis lut_function=(A+!(B (C+!(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1375[20] 1383[28])
    defparam i10887_4_lut.init = 16'hbfbb;
    LUT4 PD_FIFO_I_0_i8_2_lut (.A(PD_FIFO), .B(PD_LATCH[7]), .Z(SDATA[7])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1345[21:51])
    defparam PD_FIFO_I_0_i8_2_lut.init = 16'h8888;
    LUT4 i7400_3_lut (.A(EN[5]), .B(COL0[5]), .C(COL1[5]), .Z(n7886)) /* synthesis lut_function=(A (B+(C))) */ ;
    defparam i7400_3_lut.init = 16'ha8a8;
    LUT4 i7218_3_lut (.A(COL0[4]), .B(EN[4]), .C(COL1[4]), .Z(n7704)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam i7218_3_lut.init = 16'hc8c8;
    LUT4 i7413_3_lut (.A(COL0[1]), .B(EN[1]), .C(COL1[1]), .Z(n7900)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam i7413_3_lut.init = 16'hc8c8;
    LUT4 i1_4_lut (.A(n7900), .B(COL0[2]), .C(EN[2]), .D(COL1[2]), .Z(n4)) /* synthesis lut_function=(A+!(B (C)+!B (C (D)))) */ ;
    defparam i1_4_lut.init = 16'hafbf;
    LUT4 i10856_2_lut (.A(n12292), .B(\Hnn[5] ), .Z(n5801)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i10856_2_lut.init = 16'h1111;
    LUT4 i1_2_lut (.A(\Hnn[4] ), .B(\Hnn[3] ), .Z(n4239)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1403[27:43])
    defparam i1_2_lut.init = 16'h8888;
    LUT4 i1_2_lut_adj_430 (.A(\Hnn[4] ), .B(\Hnn[3] ), .Z(n4236)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1402[26:43])
    defparam i1_2_lut_adj_430.init = 16'h2222;
    LUT4 i1_2_lut_adj_431 (.A(\Hnn[3] ), .B(\Hnn[4] ), .Z(n4242)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1401[27:43])
    defparam i1_2_lut_adj_431.init = 16'h2222;
    LUT4 i10631_2_lut (.A(\Hnn[3] ), .B(\Hnn[4] ), .Z(n7663)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i10631_2_lut.init = 16'h1111;
    LUT4 i4952_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2263[2]), 
         .D(QS_IN_adj_2264[3]), .Z(n5457)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4952_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_156_i1_3_lut (.A(n332[0]), .B(COL0[3]), .C(n10759), .Z(n338[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1379[20] 1383[28])
    defparam mux_156_i1_3_lut.init = 16'hcaca;
    LUT4 i4942_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2263[3]), 
         .D(QS_IN_adj_2264[4]), .Z(n5447)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4942_3_lut_4_lut.init = 16'hf780;
    PFUMX i10932 (.BLUT(n11845), .ALUT(n11846), .C0(n12292), .Z(n11847));
    LUT4 i4928_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2263[4]), 
         .D(QS_IN_adj_2264[5]), .Z(n5433)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4928_3_lut_4_lut.init = 16'hf780;
    LUT4 i4916_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2263[5]), 
         .D(QS_IN_adj_2264[6]), .Z(n5421)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4916_3_lut_4_lut.init = 16'hf780;
    LUT4 i10613_2_lut_rep_223_3_lut_4_lut_4_lut (.A(n7900), .B(n11793), 
         .C(n11799), .D(n4), .Z(n11699)) /* synthesis lut_function=(A (B+(C))+!A (B (C+!(D))+!B (C))) */ ;
    defparam i10613_2_lut_rep_223_3_lut_4_lut_4_lut.init = 16'hf8fc;
    LUT4 mux_157_i1_3_lut_4_lut (.A(n7900), .B(n11793), .C(COL0[1]), .D(COL0[2]), 
         .Z(n344[0])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_157_i1_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_157_i2_3_lut_4_lut (.A(n7900), .B(n11793), .C(COL1[1]), .D(COL1[2]), 
         .Z(n344[1])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_157_i2_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_157_i3_3_lut_4_lut (.A(n7900), .B(n11793), .C(ATR1[0]), .D(ATR2[0]), 
         .Z(n344[2])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_157_i3_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_157_i4_3_lut_4_lut (.A(n7900), .B(n11793), .C(ATR1[1]), .D(ATR2[1]), 
         .Z(n344[3])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_157_i4_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_157_i5_3_lut_4_lut (.A(n7900), .B(n11793), .C(ATR1[2]), .D(ATR2[2]), 
         .Z(n344[4])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_157_i5_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_3_lut_4_lut (.A(n11793), .B(n4), .C(n11827), .D(n7900), 
         .Z(n10759)) /* synthesis lut_function=(!((((D)+!C)+!B)+!A)) */ ;
    defparam i1_3_lut_4_lut.init = 16'h0080;
    LUT4 mux_154_i1_4_lut (.A(COL0[6]), .B(COL0[7]), .C(SPR_6__N_1267), 
         .D(SPR_7__N_1254), .Z(n326[0])) /* synthesis lut_function=(!(A (B (C (D))+!B (C))+!A (((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1381[20] 1383[28])
    defparam mux_154_i1_4_lut.init = 16'h0aca;
    L6MUX21 ZCOL_4__I_0_i3 (.D0(n338[2]), .D1(ZCOL_4__N_1145[2]), .SD(n10978), 
            .Z(ZCOL[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;
    LUT4 i1_4_lut_adj_432 (.A(COL0[6]), .B(n10787), .C(EN[6]), .D(COL1[6]), 
         .Z(SPR_6__N_1267)) /* synthesis lut_function=(A (B+!(C))+!A (B+!(C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1372[18:114])
    defparam i1_4_lut_adj_432.init = 16'hcfdf;
    L6MUX21 ZCOL_4__I_0_i4 (.D0(n338[3]), .D1(ZCOL_4__N_1145[3]), .SD(n10978), 
            .Z(ZCOL[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;
    L6MUX21 ZCOL_4__I_0_i5 (.D0(n338[4]), .D1(ZCOL_4__N_1145[4]), .SD(n10978), 
            .Z(ZCOL[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;
    PFUMX ZCOL_4__I_0_i1 (.BLUT(n338[0]), .ALUT(ZCOL_4__N_1145[0]), .C0(n10978), 
          .Z(ZCOL[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;
    PFUMX ZCOL_4__I_0_i2 (.BLUT(n338[1]), .ALUT(ZCOL_4__N_1145[1]), .C0(n10978), 
          .Z(ZCOL[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;
    LUT4 i1_4_lut_adj_433 (.A(SPR_6__N_1267), .B(n10787), .C(EN[7]), .D(SPR_7__N_1266), 
         .Z(SPR_7__N_1254)) /* synthesis lut_function=((B+!(C (D)))+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1372[18:114])
    defparam i1_4_lut_adj_433.init = 16'hdfff;
    PFUMX ZCOL_4__I_358_i3 (.BLUT(n326[2]), .ALUT(ZCOL_4__N_1330[2]), .C0(n11699), 
          .Z(ZCOL_4__N_1145[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;
    PFUMX ZCOL_4__I_358_i4 (.BLUT(n326[3]), .ALUT(ZCOL_4__N_1330[3]), .C0(n11699), 
          .Z(ZCOL_4__N_1145[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;
    LUT4 COL0_7__I_0_2_lut (.A(COL0[7]), .B(COL1[7]), .Z(SPR_7__N_1266)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1373[37:58])
    defparam COL0_7__I_0_2_lut.init = 16'heeee;
    PFUMX ZCOL_4__I_358_i5 (.BLUT(n326[4]), .ALUT(ZCOL_4__N_1330[4]), .C0(n11699), 
          .Z(ZCOL_4__N_1145[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;
    PFUMX mux_156_i3 (.BLUT(n332[2]), .ALUT(ATR3[0]), .C0(n10759), .Z(n338[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;
    PFUMX mux_156_i4 (.BLUT(n332[3]), .ALUT(ATR3[1]), .C0(n10759), .Z(n338[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;
    PFUMX mux_156_i5 (.BLUT(n332[4]), .ALUT(ATR3[2]), .C0(n10759), .Z(n338[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;
    LUT4 mux_156_i2_3_lut (.A(n332[1]), .B(COL1[3]), .C(n10759), .Z(n338[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1379[20] 1383[28])
    defparam mux_156_i2_3_lut.init = 16'hcaca;
    LUT4 PCLK_I_0_309_2_lut_rep_293 (.A(n12292), .B(EN[7]), .Z(n11769)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam PCLK_I_0_309_2_lut_rep_293.init = 16'h8888;
    LUT4 i4771_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2265[0]), 
         .D(QS_IN_adj_2266[1]), .Z(n5276)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4771_3_lut_4_lut.init = 16'hf780;
    LUT4 i4763_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2265[1]), 
         .D(QS_IN_adj_2266[2]), .Z(n5268)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4763_3_lut_4_lut.init = 16'hf780;
    LUT4 i4759_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2265[2]), 
         .D(QS_IN_adj_2266[3]), .Z(n5264)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4759_3_lut_4_lut.init = 16'hf780;
    LUT4 i4755_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2265[3]), 
         .D(QS_IN_adj_2266[4]), .Z(n5260)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4755_3_lut_4_lut.init = 16'hf780;
    LUT4 i4747_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2265[4]), 
         .D(QS_IN_adj_2266[5]), .Z(n5252)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4747_3_lut_4_lut.init = 16'hf780;
    LUT4 i4745_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2265[5]), 
         .D(QS_IN_adj_2266[6]), .Z(n5250)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4745_3_lut_4_lut.init = 16'hf780;
    LUT4 i4738_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2265[6]), 
         .D(QS_IN_adj_2266[7]), .Z(n5243)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4738_3_lut_4_lut.init = 16'hf780;
    LUT4 i4734_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2267[0]), 
         .D(QS_IN_adj_2268[1]), .Z(n5239)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4734_3_lut_4_lut.init = 16'hf780;
    LUT4 i4730_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2267[1]), 
         .D(QS_IN_adj_2268[2]), .Z(n5235)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4730_3_lut_4_lut.init = 16'hf780;
    LUT4 i4726_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2267[2]), 
         .D(QS_IN_adj_2268[3]), .Z(n5231)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4726_3_lut_4_lut.init = 16'hf780;
    LUT4 i4722_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2267[3]), 
         .D(QS_IN_adj_2268[4]), .Z(n5227)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4722_3_lut_4_lut.init = 16'hf780;
    LUT4 i4710_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2267[4]), 
         .D(QS_IN_adj_2268[5]), .Z(n5215)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4710_3_lut_4_lut.init = 16'hf780;
    LUT4 i4704_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2267[5]), 
         .D(QS_IN_adj_2268[6]), .Z(n5209)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4704_3_lut_4_lut.init = 16'hf780;
    LUT4 i4699_3_lut_4_lut (.A(n12292), .B(EN[7]), .C(QP_adj_2267[6]), 
         .D(QS_IN_adj_2268[7]), .Z(n5204)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[30:44])
    defparam i4699_3_lut_4_lut.init = 16'hf780;
    LUT4 PCLK_I_0_311_2_lut_rep_294 (.A(n12292), .B(EN[6]), .Z(n11770)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam PCLK_I_0_311_2_lut_rep_294.init = 16'h8888;
    LUT4 mux_154_i2_4_lut (.A(COL1[6]), .B(COL1[7]), .C(SPR_6__N_1267), 
         .D(SPR_7__N_1254), .Z(n326[1])) /* synthesis lut_function=(!(A (B (C (D))+!B (C))+!A (((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1381[20] 1383[28])
    defparam mux_154_i2_4_lut.init = 16'h0aca;
    LUT4 i4834_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2269[0]), 
         .D(QS_IN_adj_2270[1]), .Z(n5339)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4834_3_lut_4_lut.init = 16'hf780;
    LUT4 i4830_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2269[1]), 
         .D(QS_IN_adj_2270[2]), .Z(n5335)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4830_3_lut_4_lut.init = 16'hf780;
    LUT4 i4822_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2269[2]), 
         .D(QS_IN_adj_2270[3]), .Z(n5327)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4822_3_lut_4_lut.init = 16'hf780;
    LUT4 i4818_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2269[3]), 
         .D(QS_IN_adj_2270[4]), .Z(n5323)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4818_3_lut_4_lut.init = 16'hf780;
    LUT4 i4816_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2269[4]), 
         .D(QS_IN_adj_2270[5]), .Z(n5321)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4816_3_lut_4_lut.init = 16'hf780;
    LUT4 i4814_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2269[5]), 
         .D(QS_IN_adj_2270[6]), .Z(n5319)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4814_3_lut_4_lut.init = 16'hf780;
    LUT4 i4812_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2269[6]), 
         .D(QS_IN_adj_2270[7]), .Z(n5317)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4812_3_lut_4_lut.init = 16'hf780;
    LUT4 i4810_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2271[0]), 
         .D(QS_IN_adj_2272[1]), .Z(n5315)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4810_3_lut_4_lut.init = 16'hf780;
    LUT4 i4802_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2271[1]), 
         .D(QS_IN_adj_2272[2]), .Z(n5307)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4802_3_lut_4_lut.init = 16'hf780;
    LUT4 i4796_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2271[2]), 
         .D(QS_IN_adj_2272[3]), .Z(n5301)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4796_3_lut_4_lut.init = 16'hf780;
    LUT4 i4794_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2271[3]), 
         .D(QS_IN_adj_2272[4]), .Z(n5299)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4794_3_lut_4_lut.init = 16'hf780;
    LUT4 i4786_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2271[4]), 
         .D(QS_IN_adj_2272[5]), .Z(n5291)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4786_3_lut_4_lut.init = 16'hf780;
    LUT4 i4777_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2271[5]), 
         .D(QS_IN_adj_2272[6]), .Z(n5282)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4777_3_lut_4_lut.init = 16'hf780;
    LUT4 i4773_3_lut_4_lut (.A(n12292), .B(EN[6]), .C(QP_adj_2271[6]), 
         .D(QS_IN_adj_2272[7]), .Z(n5278)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[30:44])
    defparam i4773_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_154_i3_4_lut (.A(ATR6[0]), .B(ATR7[0]), .C(SPR_6__N_1267), 
         .D(SPR_7__N_1254), .Z(n326[2])) /* synthesis lut_function=(!(A (B (C (D))+!B (C))+!A (((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1381[20] 1383[28])
    defparam mux_154_i3_4_lut.init = 16'h0aca;
    LUT4 PCLK_I_0_313_2_lut_rep_295 (.A(n12292), .B(EN[5]), .Z(n11771)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam PCLK_I_0_313_2_lut_rep_295.init = 16'h8888;
    LUT4 i4896_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP_adj_2273[0]), 
         .D(QS_IN_adj_2274[1]), .Z(n5401)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4896_3_lut_4_lut.init = 16'hf780;
    LUT4 i4886_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP_adj_2273[1]), 
         .D(QS_IN_adj_2274[2]), .Z(n5391)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4886_3_lut_4_lut.init = 16'hf780;
    LUT4 i4882_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP_adj_2273[2]), 
         .D(QS_IN_adj_2274[3]), .Z(n5387)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4882_3_lut_4_lut.init = 16'hf780;
    LUT4 i4878_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP_adj_2273[3]), 
         .D(QS_IN_adj_2274[4]), .Z(n5383)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4878_3_lut_4_lut.init = 16'hf780;
    LUT4 i4874_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP_adj_2273[4]), 
         .D(QS_IN_adj_2274[5]), .Z(n5379)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4874_3_lut_4_lut.init = 16'hf780;
    LUT4 i4870_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP_adj_2273[5]), 
         .D(QS_IN_adj_2274[6]), .Z(n5375)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4870_3_lut_4_lut.init = 16'hf780;
    LUT4 i4866_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP_adj_2273[6]), 
         .D(QS_IN_adj_2274[7]), .Z(n5371)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4866_3_lut_4_lut.init = 16'hf780;
    LUT4 i4862_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP[0]), .D(QS_IN[1]), 
         .Z(n5367)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4862_3_lut_4_lut.init = 16'hf780;
    LUT4 i4858_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP[1]), .D(QS_IN[2]), 
         .Z(n5363)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4858_3_lut_4_lut.init = 16'hf780;
    LUT4 i4854_3_lut_4_lut (.A(n12292), .B(EN[5]), .C(QP[2]), .D(QS_IN[3]), 
         .Z(n5359)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[30:44])
    defparam i4854_3_lut_4_lut.init = 16'hf780;
    PFUMX i11074 (.BLUT(n12058), .ALUT(n12059), .C0(n12292), .Z(n12060));
    LUT4 i4906_3_lut_4_lut (.A(n12292), .B(EN[4]), .C(QP_adj_2263[6]), 
         .D(QS_IN_adj_2264[7]), .Z(n5411)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[30:44])
    defparam i4906_3_lut_4_lut.init = 16'hf780;
    PFUMX i11072 (.BLUT(n12055), .ALUT(n12056), .C0(n12292), .Z(n12057));
    PFUMX i11070 (.BLUT(n12052), .ALUT(n12053), .C0(n12292), .Z(n12054));
    PFUMX i11068 (.BLUT(n12049), .ALUT(n12050), .C0(n12292), .Z(n12051));
    PFUMX i11066 (.BLUT(n12046), .ALUT(n12047), .C0(n12292), .Z(n12048));
    PFUMX i11064 (.BLUT(n12043), .ALUT(n12044), .C0(n12292), .Z(n12045));
    LUT4 PCLK_I_0_317_2_lut_rep_298 (.A(n12292), .B(EN[3]), .Z(n11774)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam PCLK_I_0_317_2_lut_rep_298.init = 16'h8888;
    PFUMX i11062 (.BLUT(n12040), .ALUT(n12041), .C0(n12292), .Z(n12042));
    LUT4 i5126_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2275[0]), 
         .D(QS_IN_adj_2276[1]), .Z(n5631)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i5126_3_lut_4_lut.init = 16'hf780;
    FD1P3IX SEL_LATCH_i0_i7 (.D(n4239), .SP(Clk_enable_526), .CD(n5801), 
            .CK(Clk), .Q(SEL_LATCH[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam SEL_LATCH_i0_i7.GSR = "DISABLED";
    FD1P3IX SEL_LATCH_i0_i6 (.D(n4236), .SP(Clk_enable_526), .CD(n5801), 
            .CK(Clk), .Q(SEL_LATCH[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam SEL_LATCH_i0_i6.GSR = "DISABLED";
    PFUMX i11060 (.BLUT(n12037), .ALUT(n12038), .C0(n12292), .Z(n12039));
    FD1P3IX SEL_LATCH_i0_i5 (.D(n4242), .SP(Clk_enable_526), .CD(n5801), 
            .CK(Clk), .Q(SEL_LATCH[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam SEL_LATCH_i0_i5.GSR = "DISABLED";
    LUT4 i5124_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2275[1]), 
         .D(QS_IN_adj_2276[2]), .Z(n5629)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i5124_3_lut_4_lut.init = 16'hf780;
    FD1P3IX SEL_LATCH_i0_i4 (.D(n7663), .SP(Clk_enable_526), .CD(n5801), 
            .CK(Clk), .Q(SEL_LATCH[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam SEL_LATCH_i0_i4.GSR = "DISABLED";
    FD1P3IX SEL_LATCH_i0_i3 (.D(n4239), .SP(Clk_enable_526), .CD(n5788), 
            .CK(Clk), .Q(SEL_LATCH[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam SEL_LATCH_i0_i3.GSR = "DISABLED";
    FD1P3IX SEL_LATCH_i0_i2 (.D(n4236), .SP(Clk_enable_526), .CD(n5788), 
            .CK(Clk), .Q(SEL_LATCH[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam SEL_LATCH_i0_i2.GSR = "DISABLED";
    FD1P3IX SEL_LATCH_i0_i1 (.D(n4242), .SP(Clk_enable_526), .CD(n5788), 
            .CK(Clk), .Q(SEL_LATCH[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam SEL_LATCH_i0_i1.GSR = "DISABLED";
    PFUMX i11058 (.BLUT(n12034), .ALUT(n12035), .C0(n12292), .Z(n12036));
    LUT4 i5122_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2275[2]), 
         .D(QS_IN_adj_2276[3]), .Z(n5627)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i5122_3_lut_4_lut.init = 16'hf780;
    PFUMX i11056 (.BLUT(n12031), .ALUT(n12032), .C0(n12292), .Z(n12033));
    LUT4 i5120_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2275[3]), 
         .D(QS_IN_adj_2276[4]), .Z(n5625)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i5120_3_lut_4_lut.init = 16'hf780;
    LUT4 i5118_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2275[4]), 
         .D(QS_IN_adj_2276[5]), .Z(n5623)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i5118_3_lut_4_lut.init = 16'hf780;
    LUT4 i5020_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2275[5]), 
         .D(QS_IN_adj_2276[6]), .Z(n5525)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i5020_3_lut_4_lut.init = 16'hf780;
    LUT4 i5018_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2275[6]), 
         .D(QS_IN_adj_2276[7]), .Z(n5523)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i5018_3_lut_4_lut.init = 16'hf780;
    LUT4 i5016_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2277[0]), 
         .D(QS_IN_adj_2278[1]), .Z(n5521)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i5016_3_lut_4_lut.init = 16'hf780;
    FD1P3IX SEL_LATCH_i0_i0 (.D(n7663), .SP(Clk_enable_530), .CD(n5788), 
            .CK(Clk), .Q(SEL_LATCH[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=409, LSE_RLINE=424 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1386[8] 1424[26])
    defparam SEL_LATCH_i0_i0.GSR = "DISABLED";
    LUT4 i5010_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2277[1]), 
         .D(QS_IN_adj_2278[2]), .Z(n5515)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i5010_3_lut_4_lut.init = 16'hf780;
    PFUMX i11054 (.BLUT(n12028), .ALUT(n12029), .C0(n12292), .Z(n12030));
    LUT4 i5008_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2277[2]), 
         .D(QS_IN_adj_2278[3]), .Z(n5513)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i5008_3_lut_4_lut.init = 16'hf780;
    LUT4 i5006_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2277[3]), 
         .D(QS_IN_adj_2278[4]), .Z(n5511)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i5006_3_lut_4_lut.init = 16'hf780;
    PFUMX i11052 (.BLUT(n12025), .ALUT(n12026), .C0(n12292), .Z(n12027));
    LUT4 i5004_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2277[4]), 
         .D(QS_IN_adj_2278[5]), .Z(n5509)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i5004_3_lut_4_lut.init = 16'hf780;
    LUT4 i5002_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2277[5]), 
         .D(QS_IN_adj_2278[6]), .Z(n5507)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i5002_3_lut_4_lut.init = 16'hf780;
    LUT4 i4996_3_lut_4_lut (.A(n12292), .B(EN[3]), .C(QP_adj_2277[6]), 
         .D(QS_IN_adj_2278[7]), .Z(n5501)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[30:44])
    defparam i4996_3_lut_4_lut.init = 16'hf780;
    PFUMX i11050 (.BLUT(n12022), .ALUT(n12023), .C0(n12292), .Z(n12024));
    LUT4 PCLK_I_0_319_2_lut_rep_299 (.A(n12292), .B(EN[2]), .Z(n11775)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam PCLK_I_0_319_2_lut_rep_299.init = 16'h8888;
    PFUMX i11048 (.BLUT(n12019), .ALUT(n12020), .C0(n12292), .Z(n12021));
    LUT4 i5154_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2279[0]), 
         .D(QS_IN_adj_2280[1]), .Z(n5659)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5154_3_lut_4_lut.init = 16'hf780;
    PFUMX i11046 (.BLUT(n12016), .ALUT(n12017), .C0(n12292), .Z(n12018));
    LUT4 i5152_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2279[1]), 
         .D(QS_IN_adj_2280[2]), .Z(n5657)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5152_3_lut_4_lut.init = 16'hf780;
    PFUMX i11044 (.BLUT(n12013), .ALUT(n12014), .C0(n12292), .Z(n12015));
    LUT4 i5150_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2279[2]), 
         .D(QS_IN_adj_2280[3]), .Z(n5655)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5150_3_lut_4_lut.init = 16'hf780;
    PFUMX i11042 (.BLUT(n12010), .ALUT(n12011), .C0(n12292), .Z(n12012));
    LUT4 i5148_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2279[3]), 
         .D(QS_IN_adj_2280[4]), .Z(n5653)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5148_3_lut_4_lut.init = 16'hf780;
    PFUMX i11040 (.BLUT(n12007), .ALUT(n12008), .C0(n12292), .Z(n12009));
    PFUMX i11038 (.BLUT(n12004), .ALUT(n12005), .C0(n12292), .Z(n12006));
    LUT4 i5146_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2279[4]), 
         .D(QS_IN_adj_2280[5]), .Z(n5651)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5146_3_lut_4_lut.init = 16'hf780;
    PFUMX i11036 (.BLUT(n12001), .ALUT(n12002), .C0(n12292), .Z(n12003));
    LUT4 i5144_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2279[5]), 
         .D(QS_IN_adj_2280[6]), .Z(n5649)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5144_3_lut_4_lut.init = 16'hf780;
    PFUMX i11034 (.BLUT(n11998), .ALUT(n11999), .C0(n12292), .Z(n12000));
    LUT4 i5142_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2279[6]), 
         .D(QS_IN_adj_2280[7]), .Z(n5647)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5142_3_lut_4_lut.init = 16'hf780;
    PFUMX i11032 (.BLUT(n11995), .ALUT(n11996), .C0(n12292), .Z(n11997));
    LUT4 i5140_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2281[0]), 
         .D(QS_IN_adj_2282[1]), .Z(n5645)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5140_3_lut_4_lut.init = 16'hf780;
    PFUMX i11030 (.BLUT(n11992), .ALUT(n11993), .C0(n12292), .Z(n11994));
    LUT4 i5138_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2281[1]), 
         .D(QS_IN_adj_2282[2]), .Z(n5643)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5138_3_lut_4_lut.init = 16'hf780;
    LUT4 i10814_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n12292), .B(SH3), .C(SEL_LATCH[4]), 
         .D(ZH_FF_adj_1912), .Z(CNT_7__N_1385_adj_2211)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[52:62])
    defparam i10814_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    PFUMX i11028 (.BLUT(n11989), .ALUT(n11990), .C0(n12292), .Z(n11991));
    LUT4 i5136_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2281[2]), 
         .D(QS_IN_adj_2282[3]), .Z(n5641)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5136_3_lut_4_lut.init = 16'hf780;
    PFUMX i11026 (.BLUT(n11986), .ALUT(n11987), .C0(n12292), .Z(n11988));
    PFUMX i11024 (.BLUT(n11983), .ALUT(n11984), .C0(n12292), .Z(n11985));
    LUT4 i5134_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2281[3]), 
         .D(QS_IN_adj_2282[4]), .Z(n5639)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5134_3_lut_4_lut.init = 16'hf780;
    PFUMX i11022 (.BLUT(n11980), .ALUT(n11981), .C0(n12292), .Z(n11982));
    PFUMX i11020 (.BLUT(n11977), .ALUT(n11978), .C0(n12292), .Z(n11979));
    LUT4 PD_7__I_0_i8_3_lut (.A(PD_out_7), .B(PD_out_0), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1332[24:96])
    defparam PD_7__I_0_i8_3_lut.init = 16'hcaca;
    PFUMX i11018 (.BLUT(n11974), .ALUT(n11975), .C0(n12292), .Z(n11976));
    LUT4 i5132_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2281[4]), 
         .D(QS_IN_adj_2282[5]), .Z(n5637)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5132_3_lut_4_lut.init = 16'hf780;
    PFUMX i11016 (.BLUT(n11971), .ALUT(n11972), .C0(n12292), .Z(n11973));
    LUT4 i5130_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2281[5]), 
         .D(QS_IN_adj_2282[6]), .Z(n5635)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5130_3_lut_4_lut.init = 16'hf780;
    PFUMX i11014 (.BLUT(n11968), .ALUT(n11969), .C0(n12292), .Z(n11970));
    LUT4 i5128_3_lut_4_lut (.A(n12292), .B(EN[2]), .C(QP_adj_2281[6]), 
         .D(QS_IN_adj_2282[7]), .Z(n5633)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[30:44])
    defparam i5128_3_lut_4_lut.init = 16'hf780;
    PFUMX i11012 (.BLUT(n11965), .ALUT(n11966), .C0(n12292), .Z(n11967));
    LUT4 PCLK_I_0_321_2_lut_rep_300 (.A(n12292), .B(EN[1]), .Z(n11776)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam PCLK_I_0_321_2_lut_rep_300.init = 16'h8888;
    PFUMX i11010 (.BLUT(n11962), .ALUT(n11963), .C0(n12292), .Z(n11964));
    LUT4 i5182_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2283[0]), 
         .D(QS_IN_adj_2284[1]), .Z(n5687)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5182_3_lut_4_lut.init = 16'hf780;
    PFUMX i11008 (.BLUT(n11959), .ALUT(n11960), .C0(n12292), .Z(n11961));
    PFUMX i11006 (.BLUT(n11956), .ALUT(n11957), .C0(n12292), .Z(n11958));
    LUT4 i5180_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2283[1]), 
         .D(QS_IN_adj_2284[2]), .Z(n5685)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5180_3_lut_4_lut.init = 16'hf780;
    PFUMX i11004 (.BLUT(n11953), .ALUT(n11954), .C0(n12292), .Z(n11955));
    LUT4 i5178_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2283[2]), 
         .D(QS_IN_adj_2284[3]), .Z(n5683)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5178_3_lut_4_lut.init = 16'hf780;
    PFUMX i11002 (.BLUT(n11950), .ALUT(n11951), .C0(n12292), .Z(n11952));
    LUT4 i5176_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2283[3]), 
         .D(QS_IN_adj_2284[4]), .Z(n5681)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5176_3_lut_4_lut.init = 16'hf780;
    PFUMX i11000 (.BLUT(n11947), .ALUT(n11948), .C0(n12292), .Z(n11949));
    LUT4 i5174_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2283[4]), 
         .D(QS_IN_adj_2284[5]), .Z(n5679)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5174_3_lut_4_lut.init = 16'hf780;
    PFUMX i10998 (.BLUT(n11944), .ALUT(n11945), .C0(n12292), .Z(n11946));
    LUT4 i5172_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2283[5]), 
         .D(QS_IN_adj_2284[6]), .Z(n5677)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5172_3_lut_4_lut.init = 16'hf780;
    PFUMX i10996 (.BLUT(n11941), .ALUT(n11942), .C0(n12292), .Z(n11943));
    LUT4 i5170_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2283[6]), 
         .D(QS_IN_adj_2284[7]), .Z(n5675)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5170_3_lut_4_lut.init = 16'hf780;
    PFUMX i10994 (.BLUT(n11938), .ALUT(n11939), .C0(n12292), .Z(n11940));
    LUT4 i5168_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2285[0]), 
         .D(QS_IN_adj_2286[1]), .Z(n5673)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5168_3_lut_4_lut.init = 16'hf780;
    PFUMX i10992 (.BLUT(n11935), .ALUT(n11936), .C0(n12292), .Z(n11937));
    LUT4 i5166_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2285[1]), 
         .D(QS_IN_adj_2286[2]), .Z(n5671)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5166_3_lut_4_lut.init = 16'hf780;
    PFUMX i10990 (.BLUT(n11932), .ALUT(n11933), .C0(n12292), .Z(n11934));
    LUT4 i5164_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2285[2]), 
         .D(QS_IN_adj_2286[3]), .Z(n5669)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5164_3_lut_4_lut.init = 16'hf780;
    PFUMX i10988 (.BLUT(n11929), .ALUT(n11930), .C0(n12292), .Z(n11931));
    LUT4 i5162_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2285[3]), 
         .D(QS_IN_adj_2286[4]), .Z(n5667)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5162_3_lut_4_lut.init = 16'hf780;
    PFUMX i10986 (.BLUT(n11926), .ALUT(n11927), .C0(n12292), .Z(n11928));
    LUT4 i5160_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2285[4]), 
         .D(QS_IN_adj_2286[5]), .Z(n5665)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5160_3_lut_4_lut.init = 16'hf780;
    PFUMX i10984 (.BLUT(n11923), .ALUT(n11924), .C0(n12292), .Z(n11925));
    LUT4 i5158_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2285[5]), 
         .D(QS_IN_adj_2286[6]), .Z(n5663)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5158_3_lut_4_lut.init = 16'hf780;
    PFUMX i10982 (.BLUT(n11920), .ALUT(n11921), .C0(n12292), .Z(n11922));
    LUT4 i5156_3_lut_4_lut (.A(n12292), .B(EN[1]), .C(QP_adj_2285[6]), 
         .D(QS_IN_adj_2286[7]), .Z(n5661)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[30:44])
    defparam i5156_3_lut_4_lut.init = 16'hf780;
    PFUMX i10980 (.BLUT(n11917), .ALUT(n11918), .C0(n12292), .Z(n11919));
    PFUMX i10978 (.BLUT(n11914), .ALUT(n11915), .C0(n12292), .Z(n11916));
    PFUMX i10976 (.BLUT(n11911), .ALUT(n11912), .C0(n12292), .Z(n11913));
    LUT4 PCLK_I_0_355_2_lut_rep_301 (.A(n12292), .B(SH7), .Z(n11777)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[54:64])
    defparam PCLK_I_0_355_2_lut_rep_301.init = 16'h8888;
    LUT4 COL1_7__I_313_2_lut_rep_246_3_lut (.A(n12292), .B(SH7), .C(SEL_LATCH[7]), 
         .Z(n11722)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[54:64])
    defparam COL1_7__I_313_2_lut_rep_246_3_lut.init = 16'h8080;
    PFUMX i10970 (.BLUT(n11902), .ALUT(n11903), .C0(n12292), .Z(n11904));
    LUT4 PD_7__I_0_i7_3_lut (.A(PD_out_6), .B(PD_out_1), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1332[24:96])
    defparam PD_7__I_0_i7_3_lut.init = 16'hcaca;
    PFUMX i10968 (.BLUT(n11899), .ALUT(n11900), .C0(n12292), .Z(n11901));
    PFUMX i10966 (.BLUT(n11896), .ALUT(n11897), .C0(n12292), .Z(n11898));
    LUT4 COL1_7__N_1246_I_0_324_2_lut_rep_249_3_lut (.A(n12292), .B(SH7), 
         .C(SEL_LATCH[6]), .Z(n11725)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[54:64])
    defparam COL1_7__N_1246_I_0_324_2_lut_rep_249_3_lut.init = 16'h8080;
    PFUMX i10964 (.BLUT(n11893), .ALUT(n11894), .C0(n12292), .Z(n11895));
    LUT4 COL1_7__N_1246_I_0_325_2_lut_rep_251_3_lut (.A(n12292), .B(SH7), 
         .C(SEL_LATCH[5]), .Z(n11727)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[54:64])
    defparam COL1_7__N_1246_I_0_325_2_lut_rep_251_3_lut.init = 16'h8080;
    LUT4 COL1_7__N_1246_I_0_326_2_lut_rep_254_3_lut (.A(n12292), .B(SH7), 
         .C(SEL_LATCH[4]), .Z(n11730)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[54:64])
    defparam COL1_7__N_1246_I_0_326_2_lut_rep_254_3_lut.init = 16'h8080;
    PFUMX i10962 (.BLUT(n11890), .ALUT(n11891), .C0(n12292), .Z(n11892));
    LUT4 COL1_7__N_1246_I_0_327_2_lut_rep_256_3_lut (.A(n12292), .B(SH7), 
         .C(SEL_LATCH[3]), .Z(n11732)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[54:64])
    defparam COL1_7__N_1246_I_0_327_2_lut_rep_256_3_lut.init = 16'h8080;
    LUT4 COL1_7__N_1246_I_0_328_2_lut_rep_258_3_lut (.A(n12292), .B(SH7), 
         .C(SEL_LATCH[2]), .Z(n11734)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[54:64])
    defparam COL1_7__N_1246_I_0_328_2_lut_rep_258_3_lut.init = 16'h8080;
    PFUMX i10960 (.BLUT(n11887), .ALUT(n11888), .C0(n12292), .Z(n11889));
    LUT4 COL1_7__N_1246_I_0_329_2_lut_rep_260_3_lut (.A(n12292), .B(SH7), 
         .C(SEL_LATCH[1]), .Z(n11736)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[54:64])
    defparam COL1_7__N_1246_I_0_329_2_lut_rep_260_3_lut.init = 16'h8080;
    PFUMX i10958 (.BLUT(n11884), .ALUT(n11885), .C0(n12292), .Z(n11886));
    LUT4 PD_7__I_0_i6_3_lut (.A(PD_out_5), .B(PD_out_2), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1332[24:96])
    defparam PD_7__I_0_i6_3_lut.init = 16'hcaca;
    PFUMX i10956 (.BLUT(n11881), .ALUT(n11882), .C0(n12292), .Z(n11883));
    LUT4 COL0_7__I_312_2_lut_rep_247_3_lut (.A(n12292), .B(SH5), .C(SEL_LATCH[7]), 
         .Z(n11723)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[54:64])
    defparam COL0_7__I_312_2_lut_rep_247_3_lut.init = 16'h8080;
    LUT4 COL1_7__N_1246_I_0_2_lut_rep_262_3_lut (.A(n12292), .B(SH7), .C(SEL_LATCH[0]), 
         .Z(n11738)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[54:64])
    defparam COL1_7__N_1246_I_0_2_lut_rep_262_3_lut.init = 16'h8080;
    LUT4 PCLK_I_0_310_2_lut_rep_302 (.A(n12292), .B(SH5), .Z(n11778)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[54:64])
    defparam PCLK_I_0_310_2_lut_rep_302.init = 16'h8888;
    LUT4 PD_7__I_0_i3_3_lut (.A(PD_out_2), .B(PD_out_5), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1332[24:96])
    defparam PD_7__I_0_i3_3_lut.init = 16'hcaca;
    PFUMX i10946 (.BLUT(n11866), .ALUT(n11867), .C0(n12292), .Z(n11868));
    PFUMX i10944 (.BLUT(n11863), .ALUT(n11864), .C0(n12292), .Z(n11865));
    PFUMX i10940 (.BLUT(n11857), .ALUT(n11858), .C0(n12292), .Z(n11859));
    LUT4 PD_7__I_0_i2_3_lut (.A(PD_out_1), .B(PD_out_6), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1332[24:96])
    defparam PD_7__I_0_i2_3_lut.init = 16'hcaca;
    FIFO_HPOSCNT EN_7__I_0_330 (.CNT({CNT_adj_2259}), .ZH_FF(ZH_FF_adj_2008), 
            .Clk(Clk), .Clk_enable_272(Clk_enable_272), .n12276(n12276), 
            .\EN[7] (EN[7]), .Clk_enable_423(Clk_enable_423), .nVIS(nVIS), 
            .n12292(n12292), .n4024(n4024), .n12030(n12030), .CNT1(CNT1_adj_2022), 
            .CNT_7__N_1385(CNT_7__N_1385_adj_2056), .CNT1_adj_173(CNT1_adj_2007), 
            .n12009(n12009), .n12012(n12012), .CNT1_adj_174(CNT1_adj_2010), 
            .CNT1_adj_175(CNT1_adj_2012), .n12015(n12015), .CNT1_adj_176(CNT1_adj_2014), 
            .n12018(n12018), .CNT1_adj_177(CNT1_adj_2016), .n12021(n12021), 
            .CNT1_adj_178(CNT1_adj_2020), .n12027(n12027), .CNT1_adj_179(CNT1_adj_2018), 
            .n12024(n12024)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1342[14:103])
    FIFO_HPOSCNT_U96 EN_6__I_0_333 (.ZH_FF(ZH_FF_adj_1965), .Clk(Clk), .Clk_enable_270(Clk_enable_270), 
            .n12276(n12276), .\EN[6] (EN[6]), .Clk_enable_423(Clk_enable_423), 
            .nVIS(nVIS), .n12292(n12292), .n4045(n4045), .CNT({CNT_adj_2255}), 
            .CNT1(CNT1_adj_1971), .CNT_7__N_1385(CNT_7__N_1385_adj_2058), 
            .n11970(n11970), .n11982(n11982), .CNT1_adj_156(CNT1_adj_1979), 
            .CNT1_adj_157(CNT1_adj_1975), .n11976(n11976), .CNT1_adj_158(CNT1_adj_1973), 
            .n11973(n11973), .CNT1_adj_159(CNT1_adj_1967), .n11964(n11964), 
            .CNT1_adj_160(CNT1_adj_1969), .n11967(n11967), .CNT1_adj_161(CNT1_adj_1977), 
            .n11979(n11979), .n11961(n11961), .CNT1_adj_162(CNT1_adj_1964)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1341[14:103])
    FIFO_HPOSCNT_U97 EN_5__I_0_336 (.nVIS(nVIS), .ZH_FF(ZH_FF_adj_2025), 
            .Clk(Clk), .Clk_enable_268(Clk_enable_268), .n12276(n12276), 
            .\EN[5] (EN[5]), .Clk_enable_423(Clk_enable_423), .n12292(n12292), 
            .n4065(n4065), .CNT({CNT_adj_2260}), .CNT1(CNT1_adj_2039), 
            .CNT_7__N_1385(CNT_7__N_1385_adj_2055), .n12054(n12054), .CNT1_adj_139(CNT1_adj_2031), 
            .n12042(n12042), .CNT1_adj_140(CNT1_adj_2037), .n12051(n12051), 
            .n12048(n12048), .CNT1_adj_141(CNT1_adj_2035), .CNT1_adj_142(CNT1_adj_2033), 
            .n12045(n12045), .n12039(n12039), .CNT1_adj_143(CNT1_adj_2029), 
            .n12036(n12036), .CNT1_adj_144(CNT1_adj_2027), .CNT1_adj_145(CNT1_adj_2024), 
            .n12033(n12033)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1340[14:103])
    FIFO_HPOSCNT_U98 EN_4__I_0_339 (.nVIS(nVIS), .ZH_FF(ZH_FF_adj_1912), 
            .Clk(Clk), .Clk_enable_265(Clk_enable_265), .n12276(n12276), 
            .\EN[4] (EN[4]), .Clk_enable_423(Clk_enable_423), .n12292(n12292), 
            .n4075(n4075), .CNT({CNT_adj_2250}), .CNT1(CNT1_adj_1913), 
            .CNT_7__N_1385(CNT_7__N_1385_adj_2211), .n11886(n11886), .CNT1_adj_122(CNT1_adj_1914), 
            .n11889(n11889), .CNT1_adj_123(CNT1_adj_1915), .n11892(n11892), 
            .CNT1_adj_124(CNT1_adj_1916), .n11895(n11895), .CNT1_adj_125(CNT1_adj_1918), 
            .n11898(n11898), .CNT1_adj_126(CNT1_adj_1922), .n11904(n11904), 
            .CNT1_adj_127(CNT1_adj_1920), .n11901(n11901), .CNT1_adj_128(CNT1_adj_1911), 
            .n11883(n11883)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1339[14:103])
    FIFO_HPOSCNT_U99 EN_3__I_0_342 (.nVIS(nVIS), .ZH_FF(ZH_FF_adj_1942), 
            .Clk(Clk), .Clk_enable_260(Clk_enable_260), .n12276(n12276), 
            .\EN[3] (EN[3]), .Clk_enable_423(Clk_enable_423), .n12292(n12292), 
            .n4076(n4076), .CNT({CNT_adj_2252}), .\SEL_LATCH[3] (SEL_LATCH[3]), 
            .SH3(SH3), .n11937(n11937), .CNT1(CNT1_adj_1941), .CNT1_adj_105(CNT1_adj_1950), 
            .n11940(n11940), .n11943(n11943), .CNT1_adj_106(CNT1_adj_1952), 
            .CNT1_adj_107(CNT1_adj_1962), .n11958(n11958), .n11949(n11949), 
            .CNT1_adj_108(CNT1_adj_1956), .CNT1_adj_109(CNT1_adj_1960), 
            .n11955(n11955), .n11946(n11946), .CNT1_adj_110(CNT1_adj_1954), 
            .n11952(n11952), .CNT1_adj_111(CNT1_adj_1958)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1338[14:103])
    FIFO_HPOSCNT_U100 EN_2__I_0_345 (.nVIS(nVIS), .ZH_FF(ZH_FF_adj_1925), 
            .Clk(Clk), .Clk_enable_258(Clk_enable_258), .n12276(n12276), 
            .\EN[2] (EN[2]), .Clk_enable_423(Clk_enable_423), .n12292(n12292), 
            .n4077(n4077), .CNT({CNT_adj_2251}), .\SEL_LATCH[2] (SEL_LATCH[2]), 
            .SH3(SH3), .CNT1(CNT1_adj_1927), .n11916(n11916), .CNT1_adj_88(CNT1_adj_1929), 
            .n11919(n11919), .CNT1_adj_89(CNT1_adj_1931), .n11922(n11922), 
            .CNT1_adj_90(CNT1_adj_1933), .n11925(n11925), .CNT1_adj_91(CNT1_adj_1935), 
            .n11928(n11928), .CNT1_adj_92(CNT1_adj_1939), .n11934(n11934), 
            .CNT1_adj_93(CNT1_adj_1937), .n11931(n11931), .CNT1_adj_94(CNT1_adj_1924), 
            .n11913(n11913)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1337[14:103])
    FIFO_HPOSCNT_U101 EN_1__I_0_348 (.nVIS(nVIS), .ZH_FF(ZH_FF), .Clk(Clk), 
            .Clk_enable_250(Clk_enable_250), .n12276(n12276), .\EN[1] (EN[1]), 
            .Clk_enable_530(Clk_enable_530), .n12292(n12292), .n4078(n4078), 
            .CNT({CNT}), .CNT1(CNT1_adj_2047), .CNT_7__N_1385(CNT_7__N_1385), 
            .n12060(n12060), .CNT1_adj_71(CNT1_adj_2054), .n11847(n11847), 
            .CNT1_adj_72(CNT1_adj_2078), .n11850(n11850), .CNT1_adj_73(CNT1_adj_2053), 
            .n11853(n11853), .CNT1_adj_74(CNT1), .n11859(n11859), .CNT1_adj_75(CNT1_adj_1910), 
            .n11868(n11868), .CNT1_adj_76(CNT1_adj_1909), .n11865(n11865), 
            .CNT1_adj_77(CNT1_adj_2041), .n12057(n12057)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1336[14:103])
    FIFO_HPOSCNT_U102 EN_0__I_0_351 (.nVIS(nVIS), .ZH_FF(ZH_FF_adj_1982), 
            .Clk(Clk), .n12276(n12276), .\EN[0] (EN[0]), .Clk_enable_530(Clk_enable_530), 
            .n12292(n12292), .CNT({CNT_adj_2256}), .\ZPOS[2] (ZPOS[2]), 
            .n4078(n4078), .Clk_enable_250(Clk_enable_250), .n4077(n4077), 
            .Clk_enable_258(Clk_enable_258), .n4076(n4076), .Clk_enable_260(Clk_enable_260), 
            .n4075(n4075), .Clk_enable_265(Clk_enable_265), .n4065(n4065), 
            .Clk_enable_268(Clk_enable_268), .n4045(n4045), .Clk_enable_270(Clk_enable_270), 
            .n4024(n4024), .Clk_enable_272(Clk_enable_272), .CNT1(CNT1_adj_1984), 
            .CNT_7__N_1385(CNT_7__N_1385_adj_2057), .n11988(n11988), .CNT1_adj_54(CNT1_adj_1986), 
            .n11991(n11991), .CNT1_adj_55(CNT1_adj_1989), .n11994(n11994), 
            .CNT1_adj_56(CNT1_adj_1991), .n11997(n11997), .CNT1_adj_57(CNT1_adj_1997), 
            .n12000(n12000), .CNT1_adj_58(CNT1_adj_2005), .n12006(n12006), 
            .CNT1_adj_59(CNT1_adj_2003), .n12003(n12003), .CNT1_adj_60(CNT1_adj_1981), 
            .n11985(n11985)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1335[14:103])
    SHIFTREG COL1_7__I_0 (.\QP[0] (QP_adj_2267[0]), .Clk(Clk), .Clk_enable_530(Clk_enable_530), 
            .\SDATA[0] (SDATA[0]), .n11722(n11722), .n11769(n11769), .\QP[1] (QP_adj_2267[1]), 
            .Clk_enable_526(Clk_enable_526), .\QS_IN[1] (QS_IN_adj_2268[1]), 
            .\QP[2] (QP_adj_2267[2]), .\QS_IN[2] (QS_IN_adj_2268[2]), .\QP[3] (QP_adj_2267[3]), 
            .\QS_IN[3] (QS_IN_adj_2268[3]), .\QP[4] (QP_adj_2267[4]), .\QS_IN[4] (QS_IN_adj_2268[4]), 
            .\QP[5] (QP_adj_2267[5]), .\QS_IN[5] (QS_IN_adj_2268[5]), .\QP[6] (QP_adj_2267[6]), 
            .\QS_IN[6] (QS_IN_adj_2268[6]), .\COL1[7] (COL1[7]), .\QS_IN[7] (QS_IN_adj_2268[7]), 
            .n5240(n5240), .n5236(n5236), .n5232(n5232), .n5228(n5228), 
            .n5216(n5216), .n5210(n5210), .n5205(n5205)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1363[10:105])
    SHIFTREG_U103 COL1_6__I_0 (.\QP[0] (QP_adj_2271[0]), .Clk(Clk), .Clk_enable_530(Clk_enable_530), 
            .\SDATA[0] (SDATA[0]), .n11725(n11725), .n11770(n11770), .\QP[1] (QP_adj_2271[1]), 
            .Clk_enable_526(Clk_enable_526), .\QS_IN[1] (QS_IN_adj_2272[1]), 
            .\QP[2] (QP_adj_2271[2]), .\QS_IN[2] (QS_IN_adj_2272[2]), .\QP[3] (QP_adj_2271[3]), 
            .\QS_IN[3] (QS_IN_adj_2272[3]), .\QP[4] (QP_adj_2271[4]), .\QS_IN[4] (QS_IN_adj_2272[4]), 
            .\QP[5] (QP_adj_2271[5]), .\QS_IN[5] (QS_IN_adj_2272[5]), .\QP[6] (QP_adj_2271[6]), 
            .\QS_IN[6] (QS_IN_adj_2272[6]), .\COL1[6] (COL1[6]), .\QS_IN[7] (QS_IN_adj_2272[7]), 
            .n5316(n5316), .n5308(n5308), .n5302(n5302), .n5300(n5300), 
            .n5292(n5292), .n5283(n5283), .n5279(n5279)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1361[10:105])
    SHIFTREG_U104 COL1_5__I_0 (.\QP[0] (QP[0]), .Clk(Clk), .Clk_enable_530(Clk_enable_530), 
            .\SDATA[0] (SDATA[0]), .n11727(n11727), .n11771(n11771), .\QP[1] (QP[1]), 
            .Clk_enable_526(Clk_enable_526), .\QS_IN[1] (QS_IN[1]), .\QP[2] (QP[2]), 
            .\QS_IN[2] (QS_IN[2]), .\QP[3] (QP[3]), .\QS_IN[3] (QS_IN[3]), 
            .\QP[4] (QP[4]), .\QS_IN[4] (QS_IN[4]), .\QP[5] (QP[5]), .\QS_IN[5] (QS_IN[5]), 
            .\QP[6] (QP[6]), .\QS_IN[6] (QS_IN[6]), .\COL1[5] (COL1[5]), 
            .\QS_IN[7] (QS_IN[7]), .n5368(n5368), .n5364(n5364), .n5360(n5360), 
            .n5354(n5354), .n5350(n5350), .n5346(n5346), .n5344(n5344)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1359[10:105])
    SHIFTREG_U105 COL1_4__I_0 (.\QP[0] (QP_adj_2263[0]), .Clk(Clk), .Clk_enable_530(Clk_enable_530), 
            .\SDATA[0] (SDATA[0]), .n11730(n11730), .n11773(n11773), .\QP[1] (QP_adj_2263[1]), 
            .Clk_enable_473(Clk_enable_473), .\QS_IN[1] (QS_IN_adj_2264[1]), 
            .\QP[2] (QP_adj_2263[2]), .\QS_IN[2] (QS_IN_adj_2264[2]), .\QP[3] (QP_adj_2263[3]), 
            .\QS_IN[3] (QS_IN_adj_2264[3]), .\QP[4] (QP_adj_2263[4]), .\QS_IN[4] (QS_IN_adj_2264[4]), 
            .\QP[5] (QP_adj_2263[5]), .\QS_IN[5] (QS_IN_adj_2264[5]), .\QP[6] (QP_adj_2263[6]), 
            .\QS_IN[6] (QS_IN_adj_2264[6]), .\COL1[4] (COL1[4]), .\QS_IN[7] (QS_IN_adj_2264[7]), 
            .n5466(n5466), .n5462(n5462), .n5458(n5458), .n5448(n5448), 
            .n5434(n5434), .n5422(n5422), .n5412(n5412)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1357[10:105])
    SHIFTREG_U106 COL1_3__I_0 (.\QP[0] (QP_adj_2277[0]), .Clk(Clk), .Clk_enable_530(Clk_enable_530), 
            .\SDATA[0] (SDATA[0]), .n11732(n11732), .n11774(n11774), .\QP[1] (QP_adj_2277[1]), 
            .Clk_enable_473(Clk_enable_473), .\QS_IN[1] (QS_IN_adj_2278[1]), 
            .\QP[2] (QP_adj_2277[2]), .\QS_IN[2] (QS_IN_adj_2278[2]), .\QP[3] (QP_adj_2277[3]), 
            .\QS_IN[3] (QS_IN_adj_2278[3]), .\QP[4] (QP_adj_2277[4]), .\QS_IN[4] (QS_IN_adj_2278[4]), 
            .\QP[5] (QP_adj_2277[5]), .\QS_IN[5] (QS_IN_adj_2278[5]), .\QP[6] (QP_adj_2277[6]), 
            .\QS_IN[6] (QS_IN_adj_2278[6]), .\COL1[3] (COL1[3]), .\QS_IN[7] (QS_IN_adj_2278[7]), 
            .n5522(n5522), .n5516(n5516), .n5514(n5514), .n5512(n5512), 
            .n5510(n5510), .n5508(n5508), .n5502(n5502)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1355[10:105])
    SHIFTREG_U107 COL1_2__I_0 (.\QP[0] (QP_adj_2281[0]), .Clk(Clk), .Clk_enable_530(Clk_enable_530), 
            .\SDATA[0] (SDATA[0]), .n11734(n11734), .n11775(n11775), .\QP[1] (QP_adj_2281[1]), 
            .Clk_enable_473(Clk_enable_473), .\QS_IN[1] (QS_IN_adj_2282[1]), 
            .\QP[2] (QP_adj_2281[2]), .\QS_IN[2] (QS_IN_adj_2282[2]), .\QP[3] (QP_adj_2281[3]), 
            .\QS_IN[3] (QS_IN_adj_2282[3]), .\QP[4] (QP_adj_2281[4]), .\QS_IN[4] (QS_IN_adj_2282[4]), 
            .\QP[5] (QP_adj_2281[5]), .\QS_IN[5] (QS_IN_adj_2282[5]), .\QP[6] (QP_adj_2281[6]), 
            .\QS_IN[6] (QS_IN_adj_2282[6]), .\COL1[2] (COL1[2]), .\QS_IN[7] (QS_IN_adj_2282[7]), 
            .n5646(n5646), .n5644(n5644), .n5642(n5642), .n5640(n5640), 
            .n5638(n5638), .n5636(n5636), .n5634(n5634)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1353[10:105])
    SHIFTREG_U108 COL1_1__I_0 (.\QP[0] (QP_adj_2285[0]), .Clk(Clk), .Clk_enable_530(Clk_enable_530), 
            .\SDATA[0] (SDATA[0]), .n11736(n11736), .n11776(n11776), .\QP[1] (QP_adj_2285[1]), 
            .Clk_enable_423(Clk_enable_423), .\QS_IN[1] (QS_IN_adj_2286[1]), 
            .\QP[2] (QP_adj_2285[2]), .\QS_IN[2] (QS_IN_adj_2286[2]), .\QP[3] (QP_adj_2285[3]), 
            .\QS_IN[3] (QS_IN_adj_2286[3]), .\QP[4] (QP_adj_2285[4]), .\QS_IN[4] (QS_IN_adj_2286[4]), 
            .\QP[5] (QP_adj_2285[5]), .Clk_enable_473(Clk_enable_473), .\QS_IN[5] (QS_IN_adj_2286[5]), 
            .\QP[6] (QP_adj_2285[6]), .\QS_IN[6] (QS_IN_adj_2286[6]), .\COL1[1] (COL1[1]), 
            .\QS_IN[7] (QS_IN_adj_2286[7]), .n5674(n5674), .n5672(n5672), 
            .n5670(n5670), .n5668(n5668), .n5666(n5666), .n5664(n5664), 
            .n5662(n5662)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1351[10:105])
    SHIFTREG_U109 COL1_0__I_0 (.\QP[0] (QP_adj_2257[0]), .Clk(Clk), .Clk_enable_185(Clk_enable_185), 
            .\SDATA[0] (SDATA[0]), .n11738(n11738), .n11779(n11779), .\QP[1] (QP_adj_2257[1]), 
            .Clk_enable_423(Clk_enable_423), .\QS_IN[1] (QS_IN_adj_2258[1]), 
            .\QP[2] (QP_adj_2257[2]), .\QS_IN[2] (QS_IN_adj_2258[2]), .\QP[3] (QP_adj_2257[3]), 
            .\QS_IN[3] (QS_IN_adj_2258[3]), .\QP[4] (QP_adj_2257[4]), .\QS_IN[4] (QS_IN_adj_2258[4]), 
            .\QP[5] (QP_adj_2257[5]), .\QS_IN[5] (QS_IN_adj_2258[5]), .\QP[6] (QP_adj_2257[6]), 
            .\QS_IN[6] (QS_IN_adj_2258[6]), .\COL1[0] (COL1[0]), .\QS_IN[7] (QS_IN_adj_2258[7]), 
            .n5702(n5702), .n5700(n5700), .n5698(n5698), .n5696(n5696), 
            .n5694(n5694), .n5692(n5692), .n5690(n5690)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1349[10:105])
    SHIFTREG_U110 COL0_7__I_0_331 (.\QP[0] (QP_adj_2265[0]), .Clk(Clk), 
            .Clk_enable_530(Clk_enable_530), .\SDATA[0] (SDATA[0]), .n11723(n11723), 
            .n11769(n11769), .\QP[1] (QP_adj_2265[1]), .Clk_enable_526(Clk_enable_526), 
            .\QS_IN[1] (QS_IN_adj_2266[1]), .\QP[2] (QP_adj_2265[2]), .\QS_IN[2] (QS_IN_adj_2266[2]), 
            .\QP[3] (QP_adj_2265[3]), .\QS_IN[3] (QS_IN_adj_2266[3]), .\QP[4] (QP_adj_2265[4]), 
            .\QS_IN[4] (QS_IN_adj_2266[4]), .\QP[5] (QP_adj_2265[5]), .\QS_IN[5] (QS_IN_adj_2266[5]), 
            .\QP[6] (QP_adj_2265[6]), .\QS_IN[6] (QS_IN_adj_2266[6]), .\COL0[7] (COL0[7]), 
            .\QS_IN[7] (QS_IN_adj_2266[7]), .n5277(n5277), .n5269(n5269), 
            .n5265(n5265), .n5261(n5261), .n5253(n5253), .n5251(n5251), 
            .n5244(n5244)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1362[10:105])
    SHIFTREG_U111 COL0_6__I_0_334 (.\QP[0] (QP_adj_2269[0]), .Clk(Clk), 
            .Clk_enable_530(Clk_enable_530), .\SDATA[0] (SDATA[0]), .n11726(n11726), 
            .n11770(n11770), .\QP[1] (QP_adj_2269[1]), .Clk_enable_526(Clk_enable_526), 
            .\QS_IN[1] (QS_IN_adj_2270[1]), .\QP[2] (QP_adj_2269[2]), .\QS_IN[2] (QS_IN_adj_2270[2]), 
            .\QP[3] (QP_adj_2269[3]), .\QS_IN[3] (QS_IN_adj_2270[3]), .\QP[4] (QP_adj_2269[4]), 
            .\QS_IN[4] (QS_IN_adj_2270[4]), .\QP[5] (QP_adj_2269[5]), .\QS_IN[5] (QS_IN_adj_2270[5]), 
            .\QP[6] (QP_adj_2269[6]), .\QS_IN[6] (QS_IN_adj_2270[6]), .\COL0[6] (COL0[6]), 
            .\QS_IN[7] (QS_IN_adj_2270[7]), .n5340(n5340), .n5336(n5336), 
            .n5328(n5328), .n5324(n5324), .n5322(n5322), .n5320(n5320), 
            .n5318(n5318)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1360[10:105])
    SHIFTREG_U112 COL0_5__I_0_337 (.\QP[0] (QP_adj_2273[0]), .Clk(Clk), 
            .Clk_enable_530(Clk_enable_530), .\SDATA[0] (SDATA[0]), .n11728(n11728), 
            .n11771(n11771), .\QP[1] (QP_adj_2273[1]), .Clk_enable_473(Clk_enable_473), 
            .\QS_IN[1] (QS_IN_adj_2274[1]), .\QP[2] (QP_adj_2273[2]), .\QS_IN[2] (QS_IN_adj_2274[2]), 
            .\QP[3] (QP_adj_2273[3]), .\QS_IN[3] (QS_IN_adj_2274[3]), .\QP[4] (QP_adj_2273[4]), 
            .\QS_IN[4] (QS_IN_adj_2274[4]), .\QP[5] (QP_adj_2273[5]), .\QS_IN[5] (QS_IN_adj_2274[5]), 
            .\QP[6] (QP_adj_2273[6]), .Clk_enable_526(Clk_enable_526), .\QS_IN[6] (QS_IN_adj_2274[6]), 
            .\COL0[5] (COL0[5]), .\QS_IN[7] (QS_IN_adj_2274[7]), .n5402(n5402), 
            .n5392(n5392), .n5388(n5388), .n5384(n5384), .n5380(n5380), 
            .n5376(n5376), .n5372(n5372)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1358[10:105])
    SHIFTREG_U113 COL0_4__I_0_340 (.\QP[0] (QP_adj_2261[0]), .Clk(Clk), 
            .Clk_enable_530(Clk_enable_530), .\SDATA[0] (SDATA[0]), .n11731(n11731), 
            .n11773(n11773), .\QP[1] (QP_adj_2261[1]), .Clk_enable_473(Clk_enable_473), 
            .\QS_IN[1] (QS_IN_adj_2262[1]), .\QP[2] (QP_adj_2261[2]), .\QS_IN[2] (QS_IN_adj_2262[2]), 
            .\QP[3] (QP_adj_2261[3]), .\QS_IN[3] (QS_IN_adj_2262[3]), .\QP[4] (QP_adj_2261[4]), 
            .\QS_IN[4] (QS_IN_adj_2262[4]), .\QP[5] (QP_adj_2261[5]), .\QS_IN[5] (QS_IN_adj_2262[5]), 
            .\QP[6] (QP_adj_2261[6]), .\QS_IN[6] (QS_IN_adj_2262[6]), .\COL0[4] (COL0[4]), 
            .\QS_IN[7] (QS_IN_adj_2262[7]), .n5498(n5498), .n5487(n5487), 
            .n5485(n5485), .n5482(n5482), .n5478(n5478), .n5473(n5473), 
            .n5469(n5469)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1356[10:105])
    SHIFTREG_U114 COL0_3__I_0_343 (.\QP[0] (QP_adj_2275[0]), .Clk(Clk), 
            .Clk_enable_530(Clk_enable_530), .\SDATA[0] (SDATA[0]), .n11733(n11733), 
            .n11774(n11774), .\QP[1] (QP_adj_2275[1]), .Clk_enable_473(Clk_enable_473), 
            .\QS_IN[1] (QS_IN_adj_2276[1]), .\QP[2] (QP_adj_2275[2]), .\QS_IN[2] (QS_IN_adj_2276[2]), 
            .\QP[3] (QP_adj_2275[3]), .\QS_IN[3] (QS_IN_adj_2276[3]), .\QP[4] (QP_adj_2275[4]), 
            .\QS_IN[4] (QS_IN_adj_2276[4]), .\QP[5] (QP_adj_2275[5]), .\QS_IN[5] (QS_IN_adj_2276[5]), 
            .\QP[6] (QP_adj_2275[6]), .\QS_IN[6] (QS_IN_adj_2276[6]), .\COL0[3] (COL0[3]), 
            .\QS_IN[7] (QS_IN_adj_2276[7]), .n5632(n5632), .n5630(n5630), 
            .n5628(n5628), .n5626(n5626), .n5624(n5624), .n5526(n5526), 
            .n5524(n5524)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1354[10:105])
    SHIFTREG_U115 COL0_2__I_0_346 (.\QP[0] (QP_adj_2279[0]), .Clk(Clk), 
            .Clk_enable_530(Clk_enable_530), .\SDATA[0] (SDATA[0]), .n11735(n11735), 
            .n11775(n11775), .\QP[1] (QP_adj_2279[1]), .Clk_enable_473(Clk_enable_473), 
            .\QS_IN[1] (QS_IN_adj_2280[1]), .\QP[2] (QP_adj_2279[2]), .\QS_IN[2] (QS_IN_adj_2280[2]), 
            .\QP[3] (QP_adj_2279[3]), .\QS_IN[3] (QS_IN_adj_2280[3]), .\QP[4] (QP_adj_2279[4]), 
            .\QS_IN[4] (QS_IN_adj_2280[4]), .\QP[5] (QP_adj_2279[5]), .\QS_IN[5] (QS_IN_adj_2280[5]), 
            .\QP[6] (QP_adj_2279[6]), .\QS_IN[6] (QS_IN_adj_2280[6]), .\COL0[2] (COL0[2]), 
            .\QS_IN[7] (QS_IN_adj_2280[7]), .n5660(n5660), .n5658(n5658), 
            .n5656(n5656), .n5654(n5654), .n5652(n5652), .n5650(n5650), 
            .n5648(n5648)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1352[10:105])
    SHIFTREG_U116 COL0_1__I_0_349 (.\QP[0] (QP_adj_2283[0]), .Clk(Clk), 
            .Clk_enable_185(Clk_enable_185), .\SDATA[0] (SDATA[0]), .n11737(n11737), 
            .n11776(n11776), .\QP[1] (QP_adj_2283[1]), .Clk_enable_423(Clk_enable_423), 
            .\QS_IN[1] (QS_IN_adj_2284[1]), .\QP[2] (QP_adj_2283[2]), .\QS_IN[2] (QS_IN_adj_2284[2]), 
            .\QP[3] (QP_adj_2283[3]), .\QS_IN[3] (QS_IN_adj_2284[3]), .\QP[4] (QP_adj_2283[4]), 
            .\QS_IN[4] (QS_IN_adj_2284[4]), .\QP[5] (QP_adj_2283[5]), .\QS_IN[5] (QS_IN_adj_2284[5]), 
            .\QP[6] (QP_adj_2283[6]), .\QS_IN[6] (QS_IN_adj_2284[6]), .\COL0[1] (COL0[1]), 
            .\QS_IN[7] (QS_IN_adj_2284[7]), .n5688(n5688), .n5686(n5686), 
            .n5684(n5684), .n5682(n5682), .n5680(n5680), .n5678(n5678), 
            .n5676(n5676)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1350[10:105])
    SHIFTREG_U117 COL0_0__I_0_352 (.\QP[0] (QP_adj_2253[0]), .Clk(Clk), 
            .Clk_enable_185(Clk_enable_185), .\SDATA[0] (SDATA[0]), .n11739(n11739), 
            .n11779(n11779), .\QP[1] (QP_adj_2253[1]), .Clk_enable_423(Clk_enable_423), 
            .\QS_IN[1] (QS_IN_adj_2254[1]), .\QP[2] (QP_adj_2253[2]), .\QS_IN[2] (QS_IN_adj_2254[2]), 
            .\QP[3] (QP_adj_2253[3]), .\QS_IN[3] (QS_IN_adj_2254[3]), .\QP[4] (QP_adj_2253[4]), 
            .\QS_IN[4] (QS_IN_adj_2254[4]), .\QP[5] (QP_adj_2253[5]), .\QS_IN[5] (QS_IN_adj_2254[5]), 
            .\QP[6] (QP_adj_2253[6]), .\QS_IN[6] (QS_IN_adj_2254[6]), .\COL0[0] (COL0[0]), 
            .\QS_IN[7] (QS_IN_adj_2254[7]), .n5716(n5716), .n5714(n5714), 
            .n5712(n5712), .n5710(n5710), .n5708(n5708), .n5706(n5706), 
            .n5704(n5704)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1348[10:105])
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT
//

module FIFO_HPOSCNT (CNT, ZH_FF, Clk, Clk_enable_272, n12276, \EN[7] , 
            Clk_enable_423, nVIS, n12292, n4024, n12030, CNT1, CNT_7__N_1385, 
            CNT1_adj_173, n12009, n12012, CNT1_adj_174, CNT1_adj_175, 
            n12015, CNT1_adj_176, n12018, CNT1_adj_177, n12021, CNT1_adj_178, 
            n12027, CNT1_adj_179, n12024) /* synthesis syn_module_defined=1 */ ;
    output [7:0]CNT;
    output ZH_FF;
    input Clk;
    input Clk_enable_272;
    input n12276;
    output \EN[7] ;
    input Clk_enable_423;
    input nVIS;
    input n12292;
    output n4024;
    input n12030;
    output CNT1;
    input CNT_7__N_1385;
    output CNT1_adj_173;
    input n12009;
    input n12012;
    output CNT1_adj_174;
    output CNT1_adj_175;
    input n12015;
    output CNT1_adj_176;
    input n12018;
    output CNT1_adj_177;
    input n12021;
    output CNT1_adj_178;
    input n12027;
    output CNT1_adj_179;
    input n12024;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire n14, n10, ZH_FF_N_1394, EN_N_1388;
    wire [0:0]CNT1_N_558;
    wire [0:0]CNT1_N_558_adj_1904;
    
    wire n11707;
    wire [0:0]CNT1_N_558_adj_1905;
    wire [0:0]CNT1_N_558_adj_1906;
    
    wire n11745;
    wire [0:0]CNT1_N_558_adj_1907;
    
    wire n11784, n11808;
    wire [0:0]CNT1_N_558_adj_1908;
    
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i2_2_lut.init = 16'heeee;
    FD1P3IX ZH_FF_36 (.D(n12276), .SP(Clk_enable_272), .CD(ZH_FF_N_1394), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    FD1P3AX EN_37 (.D(EN_N_1388), .SP(Clk_enable_423), .CK(Clk), .Q(\EN[7] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 i10833_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1388)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1456[27:44])
    defparam i10833_2_lut.init = 16'h1111;
    LUT4 PCLK_I_0_40_2_lut (.A(n12292), .B(n4024), .Z(ZH_FF_N_1394)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1454[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n4024)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    COUNTER FIFOCNT_6 (.\CNT[6] (CNT[6]), .Clk(Clk), .n12030(n12030), 
            .CNT1(CNT1), .CNT_7__N_1385(CNT_7__N_1385), .CNT1_N_558({CNT1_N_558})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U0 FIFOCNT_5 (.CNT1(CNT1_adj_173), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1904}), .\CNT[5] (CNT[5]), .n12009(n12009), 
            .n11707(n11707), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_558_adj_172({CNT1_N_558_adj_1905})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U1 FIFOCNT_4 (.\CNT[4] (CNT[4]), .Clk(Clk), .n12012(n12012), 
            .CNT1(CNT1_adj_174), .CNT_7__N_1385(CNT_7__N_1385), .CNT1_N_558({CNT1_N_558_adj_1906}), 
            .n11745(n11745), .\CNT[6] (CNT[6]), .\CNT[5] (CNT[5]), .CNT1_N_558_adj_170({CNT1_N_558})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U2 FIFOCNT_3 (.CNT1(CNT1_adj_175), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1907}), .\CNT[3] (CNT[3]), .n12015(n12015), 
            .n11784(n11784), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_558_adj_168({CNT1_N_558_adj_1904})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U3 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n11808(n11808), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .n11707(n11707), .CNT1_N_558({CNT1_N_558_adj_1906}), 
            .CNT1(CNT1_adj_176), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558_adj_166({CNT1_N_558_adj_1908}), .n12018(n12018)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U4 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .n11808(n11808), 
            .\CNT[2] (CNT[2]), .n11784(n11784), .CNT1_N_558({CNT1_N_558_adj_1908}), 
            .\CNT[3] (CNT[3]), .n11745(n11745), .CNT1_N_558_adj_164({CNT1_N_558_adj_1907}), 
            .CNT1(CNT1_adj_177), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .n12021(n12021)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U5 FIFOCNT_0 (.CNT1(CNT1_adj_178), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .\CNT[0] (CNT[0]), .n12027(n12027)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U6 CNT_7__I_0_39 (.CNT1(CNT1_adj_179), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1905}), .\CNT[7] (CNT[7]), .n12024(n12024)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    
endmodule
//
// Verilog Description of module COUNTER
//

module COUNTER (\CNT[6] , Clk, n12030, CNT1, CNT_7__N_1385, CNT1_N_558) /* synthesis syn_module_defined=1 */ ;
    output \CNT[6] ;
    input Clk;
    input n12030;
    output CNT1;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1S3AX CNT_14 (.D(n12030), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U0
//

module COUNTER_U0 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[5] , 
            n12009, n11707, \CNT[6] , \CNT[7] , CNT1_N_558_adj_172) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[5] ;
    input n12009;
    input n11707;
    input \CNT[6] ;
    input \CNT[7] ;
    output [0:0]CNT1_N_558_adj_172;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12009), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n11707), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_558_adj_172[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    
endmodule
//
// Verilog Description of module COUNTER_U1
//

module COUNTER_U1 (\CNT[4] , Clk, n12012, CNT1, CNT_7__N_1385, CNT1_N_558, 
            n11745, \CNT[6] , \CNT[5] , CNT1_N_558_adj_170) /* synthesis syn_module_defined=1 */ ;
    output \CNT[4] ;
    input Clk;
    input n12012;
    output CNT1;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    input n11745;
    input \CNT[6] ;
    input \CNT[5] ;
    output [0:0]CNT1_N_558_adj_170;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1S3AX CNT_14 (.D(n12012), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n11745), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_558_adj_170[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U2
//

module COUNTER_U2 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[3] , 
            n12015, n11784, \CNT[5] , \CNT[4] , CNT1_N_558_adj_168) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[3] ;
    input n12015;
    input n11784;
    input \CNT[5] ;
    input \CNT[4] ;
    output [0:0]CNT1_N_558_adj_168;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12015), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n11784), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_558_adj_168[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U3
//

module COUNTER_U3 (\CNT[2] , n11808, \CNT[4] , \CNT[3] , n11707, CNT1_N_558, 
            CNT1, Clk, CNT_7__N_1385, CNT1_N_558_adj_166, n12018) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n11808;
    input \CNT[4] ;
    input \CNT[3] ;
    output n11707;
    output [0:0]CNT1_N_558;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558_adj_166;
    input n12018;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    LUT4 i7510_2_lut_rep_231_3_lut_4_lut (.A(\CNT[2] ), .B(n11808), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n11707)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7510_2_lut_rep_231_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n11808), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_166[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12018), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U4
//

module COUNTER_U4 (\CNT[1] , \CNT[0] , n11808, \CNT[2] , n11784, CNT1_N_558, 
            \CNT[3] , n11745, CNT1_N_558_adj_164, CNT1, Clk, CNT_7__N_1385, 
            n12021) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    output n11808;
    input \CNT[2] ;
    output n11784;
    output [0:0]CNT1_N_558;
    input \CNT[3] ;
    output n11745;
    output [0:0]CNT1_N_558_adj_164;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input n12021;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558_adj_1883;
    
    LUT4 i7324_2_lut_rep_332 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n11808)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i7324_2_lut_rep_332.init = 16'heeee;
    LUT4 i7439_2_lut_rep_308_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n11784)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7439_2_lut_rep_308_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i7482_2_lut_rep_269_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n11745)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7482_2_lut_rep_269_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_558_adj_164[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_1883[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12021), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_558_adj_1883[0])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U5
//

module COUNTER_U5 (CNT1, Clk, CNT_7__N_1385, \CNT[0] , n12027) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    output \CNT[0] ;
    input n12027;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT_N_555;
    
    FD1P3AX CNT1_15 (.D(CNT_N_555), .SP(CNT_7__N_1385), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12027), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_555)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U6
//

module COUNTER_U6 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[7] , 
            n12024) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[7] ;
    input n12024;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12024), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U96
//

module FIFO_HPOSCNT_U96 (ZH_FF, Clk, Clk_enable_270, n12276, \EN[6] , 
            Clk_enable_423, nVIS, n12292, n4045, CNT, CNT1, CNT_7__N_1385, 
            n11970, n11982, CNT1_adj_156, CNT1_adj_157, n11976, CNT1_adj_158, 
            n11973, CNT1_adj_159, n11964, CNT1_adj_160, n11967, CNT1_adj_161, 
            n11979, n11961, CNT1_adj_162) /* synthesis syn_module_defined=1 */ ;
    output ZH_FF;
    input Clk;
    input Clk_enable_270;
    input n12276;
    output \EN[6] ;
    input Clk_enable_423;
    input nVIS;
    input n12292;
    output n4045;
    output [7:0]CNT;
    output CNT1;
    input CNT_7__N_1385;
    input n11970;
    input n11982;
    output CNT1_adj_156;
    output CNT1_adj_157;
    input n11976;
    output CNT1_adj_158;
    input n11973;
    output CNT1_adj_159;
    input n11964;
    output CNT1_adj_160;
    input n11967;
    output CNT1_adj_161;
    input n11979;
    input n11961;
    output CNT1_adj_162;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire ZH_FF_N_1394, EN_N_1388, n14, n10;
    wire [0:0]CNT1_N_558;
    wire [0:0]CNT1_N_558_adj_1875;
    
    wire n11742;
    wire [0:0]CNT1_N_558_adj_1876;
    wire [0:0]CNT1_N_558_adj_1877;
    
    wire n11763;
    wire [0:0]CNT1_N_558_adj_1878;
    
    wire n11795, n11828;
    wire [0:0]CNT1_N_558_adj_1879;
    
    FD1P3IX ZH_FF_36 (.D(n12276), .SP(Clk_enable_270), .CD(ZH_FF_N_1394), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    FD1P3AX EN_37 (.D(EN_N_1388), .SP(Clk_enable_423), .CK(Clk), .Q(\EN[6] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 i10828_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1388)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1456[27:44])
    defparam i10828_2_lut.init = 16'h1111;
    LUT4 PCLK_I_0_40_2_lut (.A(n12292), .B(n4045), .Z(ZH_FF_N_1394)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1454[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n4045)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i2_2_lut.init = 16'heeee;
    COUNTER_U7 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558}), .\CNT[6] (CNT[6]), .n11970(n11970)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U8 FIFOCNT_5 (.\CNT[5] (CNT[5]), .Clk(Clk), .n11982(n11982), 
            .CNT1(CNT1_adj_156), .CNT_7__N_1385(CNT_7__N_1385), .CNT1_N_558({CNT1_N_558_adj_1875}), 
            .n11742(n11742), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_558_adj_155({CNT1_N_558_adj_1876})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U9 FIFOCNT_4 (.CNT1(CNT1_adj_157), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1877}), .\CNT[4] (CNT[4]), .n11976(n11976), 
            .n11763(n11763), .\CNT[6] (CNT[6]), .\CNT[5] (CNT[5]), .CNT1_N_558_adj_153({CNT1_N_558})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U10 FIFOCNT_3 (.CNT1(CNT1_adj_158), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1878}), .\CNT[3] (CNT[3]), .n11973(n11973), 
            .n11795(n11795), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_558_adj_151({CNT1_N_558_adj_1875})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U11 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n11828(n11828), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .CNT1_N_558({CNT1_N_558_adj_1877}), .n11742(n11742), 
            .CNT1(CNT1_adj_159), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558_adj_149({CNT1_N_558_adj_1879}), .n11964(n11964)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U12 FIFOCNT_1 (.CNT1(CNT1_adj_160), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .n11967(n11967), .n11828(n11828), 
            .\CNT[2] (CNT[2]), .n11795(n11795), .CNT1_N_558({CNT1_N_558_adj_1879}), 
            .\CNT[3] (CNT[3]), .n11763(n11763), .CNT1_N_558_adj_147({CNT1_N_558_adj_1878})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U13 FIFOCNT_0 (.CNT1(CNT1_adj_161), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .\CNT[0] (CNT[0]), .n11979(n11979)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U14 CNT_7__I_0_39 (.\CNT[7] (CNT[7]), .Clk(Clk), .n11961(n11961), 
            .CNT1(CNT1_adj_162), .CNT_7__N_1385(CNT_7__N_1385), .CNT1_N_558({CNT1_N_558_adj_1876})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U7
//

module COUNTER_U7 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[6] , 
            n11970) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[6] ;
    input n11970;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11970), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U8
//

module COUNTER_U8 (\CNT[5] , Clk, n11982, CNT1, CNT_7__N_1385, CNT1_N_558, 
            n11742, \CNT[6] , \CNT[7] , CNT1_N_558_adj_155) /* synthesis syn_module_defined=1 */ ;
    output \CNT[5] ;
    input Clk;
    input n11982;
    output CNT1;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    input n11742;
    input \CNT[6] ;
    input \CNT[7] ;
    output [0:0]CNT1_N_558_adj_155;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1S3AX CNT_14 (.D(n11982), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n11742), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_558_adj_155[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    
endmodule
//
// Verilog Description of module COUNTER_U9
//

module COUNTER_U9 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[4] , 
            n11976, n11763, \CNT[6] , \CNT[5] , CNT1_N_558_adj_153) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[4] ;
    input n11976;
    input n11763;
    input \CNT[6] ;
    input \CNT[5] ;
    output [0:0]CNT1_N_558_adj_153;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11976), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n11763), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_558_adj_153[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U10
//

module COUNTER_U10 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[3] , 
            n11973, n11795, \CNT[5] , \CNT[4] , CNT1_N_558_adj_151) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[3] ;
    input n11973;
    input n11795;
    input \CNT[5] ;
    input \CNT[4] ;
    output [0:0]CNT1_N_558_adj_151;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11973), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n11795), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_558_adj_151[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U11
//

module COUNTER_U11 (\CNT[2] , n11828, \CNT[4] , \CNT[3] , CNT1_N_558, 
            n11742, CNT1, Clk, CNT_7__N_1385, CNT1_N_558_adj_149, 
            n11964) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n11828;
    input \CNT[4] ;
    input \CNT[3] ;
    output [0:0]CNT1_N_558;
    output n11742;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558_adj_149;
    input n11964;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n11828), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    LUT4 i7508_2_lut_rep_266_3_lut_4_lut (.A(\CNT[2] ), .B(n11828), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n11742)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7508_2_lut_rep_266_3_lut_4_lut.init = 16'hfffe;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_149[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11964), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U12
//

module COUNTER_U12 (CNT1, Clk, CNT_7__N_1385, \CNT[1] , \CNT[0] , 
            n11967, n11828, \CNT[2] , n11795, CNT1_N_558, \CNT[3] , 
            n11763, CNT1_N_558_adj_147) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    output \CNT[1] ;
    input \CNT[0] ;
    input n11967;
    output n11828;
    input \CNT[2] ;
    output n11795;
    output [0:0]CNT1_N_558;
    input \CNT[3] ;
    output n11763;
    output [0:0]CNT1_N_558_adj_147;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558_c[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_558_c[0])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1S3AX CNT_14 (.D(n11967), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i7318_2_lut_rep_352 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n11828)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i7318_2_lut_rep_352.init = 16'heeee;
    LUT4 i7437_2_lut_rep_319_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n11795)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7437_2_lut_rep_319_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i7480_2_lut_rep_287_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n11763)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7480_2_lut_rep_287_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_558_adj_147[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U13
//

module COUNTER_U13 (CNT1, Clk, CNT_7__N_1385, \CNT[0] , n11979) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    output \CNT[0] ;
    input n11979;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT_N_555;
    
    FD1P3AX CNT1_15 (.D(CNT_N_555), .SP(CNT_7__N_1385), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11979), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_555)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U14
//

module COUNTER_U14 (\CNT[7] , Clk, n11961, CNT1, CNT_7__N_1385, CNT1_N_558) /* synthesis syn_module_defined=1 */ ;
    output \CNT[7] ;
    input Clk;
    input n11961;
    output CNT1;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1S3AX CNT_14 (.D(n11961), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U97
//

module FIFO_HPOSCNT_U97 (nVIS, ZH_FF, Clk, Clk_enable_268, n12276, 
            \EN[5] , Clk_enable_423, n12292, n4065, CNT, CNT1, CNT_7__N_1385, 
            n12054, CNT1_adj_139, n12042, CNT1_adj_140, n12051, n12048, 
            CNT1_adj_141, CNT1_adj_142, n12045, n12039, CNT1_adj_143, 
            n12036, CNT1_adj_144, CNT1_adj_145, n12033) /* synthesis syn_module_defined=1 */ ;
    input nVIS;
    output ZH_FF;
    input Clk;
    input Clk_enable_268;
    input n12276;
    output \EN[5] ;
    input Clk_enable_423;
    input n12292;
    output n4065;
    output [7:0]CNT;
    output CNT1;
    input CNT_7__N_1385;
    input n12054;
    output CNT1_adj_139;
    input n12042;
    output CNT1_adj_140;
    input n12051;
    input n12048;
    output CNT1_adj_141;
    output CNT1_adj_142;
    input n12045;
    input n12039;
    output CNT1_adj_143;
    input n12036;
    output CNT1_adj_144;
    output CNT1_adj_145;
    input n12033;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire EN_N_1388, ZH_FF_N_1394, n14, n10;
    wire [0:0]CNT1_N_558;
    wire [0:0]CNT1_N_558_adj_1846;
    
    wire n11720;
    wire [0:0]CNT1_N_558_adj_1847;
    
    wire n11766;
    wire [0:0]CNT1_N_558_adj_1848;
    wire [0:0]CNT1_N_558_adj_1849;
    
    wire n11785, n11812;
    wire [0:0]CNT1_N_558_adj_1850;
    
    LUT4 i10823_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1388)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1456[27:44])
    defparam i10823_2_lut.init = 16'h1111;
    FD1P3IX ZH_FF_36 (.D(n12276), .SP(Clk_enable_268), .CD(ZH_FF_N_1394), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    FD1P3AX EN_37 (.D(EN_N_1388), .SP(Clk_enable_423), .CK(Clk), .Q(\EN[5] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 PCLK_I_0_40_2_lut (.A(n12292), .B(n4065), .Z(ZH_FF_N_1394)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1454[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n4065)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i2_2_lut.init = 16'heeee;
    COUNTER_U15 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558}), .\CNT[6] (CNT[6]), .n12054(n12054)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U16 FIFOCNT_5 (.CNT1(CNT1_adj_139), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1846}), .\CNT[5] (CNT[5]), .n12042(n12042), 
            .n11720(n11720), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_558_adj_138({CNT1_N_558_adj_1847})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U17 FIFOCNT_4 (.\CNT[4] (CNT[4]), .n11766(n11766), .\CNT[6] (CNT[6]), 
            .\CNT[5] (CNT[5]), .CNT1_N_558({CNT1_N_558}), .CNT1(CNT1_adj_140), 
            .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), .CNT1_N_558_adj_136({CNT1_N_558_adj_1848}), 
            .n12051(n12051)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U18 FIFOCNT_3 (.\CNT[3] (CNT[3]), .Clk(Clk), .n12048(n12048), 
            .CNT1(CNT1_adj_141), .CNT_7__N_1385(CNT_7__N_1385), .CNT1_N_558({CNT1_N_558_adj_1849}), 
            .n11785(n11785), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_558_adj_134({CNT1_N_558_adj_1846})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U19 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n11812(n11812), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .n11720(n11720), .CNT1_N_558({CNT1_N_558_adj_1848}), 
            .CNT1(CNT1_adj_142), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558_adj_132({CNT1_N_558_adj_1850}), .n12045(n12045)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U20 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .n11812(n11812), 
            .\CNT[2] (CNT[2]), .n11785(n11785), .\CNT[3] (CNT[3]), .CNT1_N_558({CNT1_N_558_adj_1849}), 
            .CNT1_N_558_adj_130({CNT1_N_558_adj_1850}), .n11766(n11766), 
            .Clk(Clk), .n12039(n12039), .CNT1(CNT1_adj_143), .CNT_7__N_1385(CNT_7__N_1385)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U21 FIFOCNT_0 (.\CNT[0] (CNT[0]), .Clk(Clk), .n12036(n12036), 
            .CNT1(CNT1_adj_144), .CNT_7__N_1385(CNT_7__N_1385)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U22 CNT_7__I_0_39 (.CNT1(CNT1_adj_145), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1847}), .\CNT[7] (CNT[7]), .n12033(n12033)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U15
//

module COUNTER_U15 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[6] , 
            n12054) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[6] ;
    input n12054;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12054), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U16
//

module COUNTER_U16 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[5] , 
            n12042, n11720, \CNT[6] , \CNT[7] , CNT1_N_558_adj_138) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[5] ;
    input n12042;
    input n11720;
    input \CNT[6] ;
    input \CNT[7] ;
    output [0:0]CNT1_N_558_adj_138;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12042), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n11720), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_558_adj_138[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    
endmodule
//
// Verilog Description of module COUNTER_U17
//

module COUNTER_U17 (\CNT[4] , n11766, \CNT[6] , \CNT[5] , CNT1_N_558, 
            CNT1, Clk, CNT_7__N_1385, CNT1_N_558_adj_136, n12051) /* synthesis syn_module_defined=1 */ ;
    output \CNT[4] ;
    input n11766;
    input \CNT[6] ;
    input \CNT[5] ;
    output [0:0]CNT1_N_558;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558_adj_136;
    input n12051;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n11766), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_136[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12051), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U18
//

module COUNTER_U18 (\CNT[3] , Clk, n12048, CNT1, CNT_7__N_1385, CNT1_N_558, 
            n11785, \CNT[5] , \CNT[4] , CNT1_N_558_adj_134) /* synthesis syn_module_defined=1 */ ;
    output \CNT[3] ;
    input Clk;
    input n12048;
    output CNT1;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    input n11785;
    input \CNT[5] ;
    input \CNT[4] ;
    output [0:0]CNT1_N_558_adj_134;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1S3AX CNT_14 (.D(n12048), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n11785), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_558_adj_134[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U19
//

module COUNTER_U19 (\CNT[2] , n11812, \CNT[4] , \CNT[3] , n11720, 
            CNT1_N_558, CNT1, Clk, CNT_7__N_1385, CNT1_N_558_adj_132, 
            n12045) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n11812;
    input \CNT[4] ;
    input \CNT[3] ;
    output n11720;
    output [0:0]CNT1_N_558;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558_adj_132;
    input n12045;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    LUT4 i7506_2_lut_rep_244_3_lut_4_lut (.A(\CNT[2] ), .B(n11812), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n11720)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7506_2_lut_rep_244_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n11812), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_132[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12045), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U20
//

module COUNTER_U20 (\CNT[1] , \CNT[0] , n11812, \CNT[2] , n11785, 
            \CNT[3] , CNT1_N_558, CNT1_N_558_adj_130, n11766, Clk, 
            n12039, CNT1, CNT_7__N_1385) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    output n11812;
    input \CNT[2] ;
    output n11785;
    input \CNT[3] ;
    output [0:0]CNT1_N_558;
    output [0:0]CNT1_N_558_adj_130;
    output n11766;
    input Clk;
    input n12039;
    output CNT1;
    input CNT_7__N_1385;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558_adj_1825;
    
    LUT4 i7310_2_lut_rep_336 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n11812)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i7310_2_lut_rep_336.init = 16'heeee;
    LUT4 i7435_2_lut_rep_309_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n11785)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7435_2_lut_rep_309_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_558_adj_130[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i7478_2_lut_rep_290_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n11766)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7478_2_lut_rep_290_3_lut_4_lut.init = 16'hfffe;
    FD1S3AX CNT_14 (.D(n12039), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_558_adj_1825[0])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_1825[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U21
//

module COUNTER_U21 (\CNT[0] , Clk, n12036, CNT1, CNT_7__N_1385) /* synthesis syn_module_defined=1 */ ;
    output \CNT[0] ;
    input Clk;
    input n12036;
    output CNT1;
    input CNT_7__N_1385;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558;
    
    LUT4 i2247_1_lut (.A(\CNT[0] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1663[26:36])
    defparam i2247_1_lut.init = 16'h5555;
    FD1S3AX CNT_14 (.D(n12036), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U22
//

module COUNTER_U22 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[7] , 
            n12033) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[7] ;
    input n12033;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12033), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U98
//

module FIFO_HPOSCNT_U98 (nVIS, ZH_FF, Clk, Clk_enable_265, n12276, 
            \EN[4] , Clk_enable_423, n12292, n4075, CNT, CNT1, CNT_7__N_1385, 
            n11886, CNT1_adj_122, n11889, CNT1_adj_123, n11892, CNT1_adj_124, 
            n11895, CNT1_adj_125, n11898, CNT1_adj_126, n11904, CNT1_adj_127, 
            n11901, CNT1_adj_128, n11883) /* synthesis syn_module_defined=1 */ ;
    input nVIS;
    output ZH_FF;
    input Clk;
    input Clk_enable_265;
    input n12276;
    output \EN[4] ;
    input Clk_enable_423;
    input n12292;
    output n4075;
    output [7:0]CNT;
    output CNT1;
    input CNT_7__N_1385;
    input n11886;
    output CNT1_adj_122;
    input n11889;
    output CNT1_adj_123;
    input n11892;
    output CNT1_adj_124;
    input n11895;
    output CNT1_adj_125;
    input n11898;
    output CNT1_adj_126;
    input n11904;
    output CNT1_adj_127;
    input n11901;
    output CNT1_adj_128;
    input n11883;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire EN_N_1388, ZH_FF_N_1394, n14, n10;
    wire [0:0]CNT1_N_558;
    
    wire n11706;
    wire [0:0]CNT1_N_558_adj_1817;
    wire [0:0]CNT1_N_558_adj_1818;
    
    wire n11744;
    wire [0:0]CNT1_N_558_adj_1819;
    wire [0:0]CNT1_N_558_adj_1820;
    
    wire n11804, n11843;
    wire [0:0]CNT1_N_558_adj_1821;
    
    LUT4 i10817_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1388)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1456[27:44])
    defparam i10817_2_lut.init = 16'h1111;
    FD1P3IX ZH_FF_36 (.D(n12276), .SP(Clk_enable_265), .CD(ZH_FF_N_1394), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    FD1P3AX EN_37 (.D(EN_N_1388), .SP(Clk_enable_423), .CK(Clk), .Q(\EN[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 PCLK_I_0_40_2_lut (.A(n12292), .B(n4075), .Z(ZH_FF_N_1394)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1454[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n4075)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i2_2_lut.init = 16'heeee;
    COUNTER_U23 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558}), .\CNT[6] (CNT[6]), .n11886(n11886)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U24 FIFOCNT_5 (.\CNT[5] (CNT[5]), .n11706(n11706), .\CNT[6] (CNT[6]), 
            .\CNT[7] (CNT[7]), .CNT1_N_558({CNT1_N_558_adj_1817}), .CNT1(CNT1_adj_122), 
            .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), .CNT1_N_558_adj_121({CNT1_N_558_adj_1818}), 
            .n11889(n11889)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U25 FIFOCNT_4 (.\CNT[4] (CNT[4]), .n11744(n11744), .\CNT[6] (CNT[6]), 
            .\CNT[5] (CNT[5]), .CNT1_N_558({CNT1_N_558}), .CNT1(CNT1_adj_123), 
            .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), .CNT1_N_558_adj_119({CNT1_N_558_adj_1819}), 
            .n11892(n11892)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U26 FIFOCNT_3 (.CNT1(CNT1_adj_124), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1820}), .\CNT[3] (CNT[3]), .n11895(n11895), 
            .n11804(n11804), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_558_adj_117({CNT1_N_558_adj_1818})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U27 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n11843(n11843), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .n11706(n11706), .CNT1_N_558({CNT1_N_558_adj_1819}), 
            .CNT1(CNT1_adj_125), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558_adj_115({CNT1_N_558_adj_1821}), .n11898(n11898)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U28 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .CNT1(CNT1_adj_126), 
            .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), .n11904(n11904), 
            .n11843(n11843), .\CNT[2] (CNT[2]), .n11804(n11804), .CNT1_N_558({CNT1_N_558_adj_1821}), 
            .\CNT[3] (CNT[3]), .n11744(n11744), .CNT1_N_558_adj_113({CNT1_N_558_adj_1820})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U29 FIFOCNT_0 (.CNT1(CNT1_adj_127), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .\CNT[0] (CNT[0]), .n11901(n11901)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U30 CNT_7__I_0_39 (.CNT1(CNT1_adj_128), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1817}), .\CNT[7] (CNT[7]), .n11883(n11883)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U23
//

module COUNTER_U23 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[6] , 
            n11886) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[6] ;
    input n11886;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11886), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U24
//

module COUNTER_U24 (\CNT[5] , n11706, \CNT[6] , \CNT[7] , CNT1_N_558, 
            CNT1, Clk, CNT_7__N_1385, CNT1_N_558_adj_121, n11889) /* synthesis syn_module_defined=1 */ ;
    output \CNT[5] ;
    input n11706;
    input \CNT[6] ;
    input \CNT[7] ;
    output [0:0]CNT1_N_558;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558_adj_121;
    input n11889;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n11706), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_121[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11889), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U25
//

module COUNTER_U25 (\CNT[4] , n11744, \CNT[6] , \CNT[5] , CNT1_N_558, 
            CNT1, Clk, CNT_7__N_1385, CNT1_N_558_adj_119, n11892) /* synthesis syn_module_defined=1 */ ;
    output \CNT[4] ;
    input n11744;
    input \CNT[6] ;
    input \CNT[5] ;
    output [0:0]CNT1_N_558;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558_adj_119;
    input n11892;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n11744), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_119[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11892), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U26
//

module COUNTER_U26 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[3] , 
            n11895, n11804, \CNT[5] , \CNT[4] , CNT1_N_558_adj_117) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[3] ;
    input n11895;
    input n11804;
    input \CNT[5] ;
    input \CNT[4] ;
    output [0:0]CNT1_N_558_adj_117;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11895), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n11804), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_558_adj_117[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U27
//

module COUNTER_U27 (\CNT[2] , n11843, \CNT[4] , \CNT[3] , n11706, 
            CNT1_N_558, CNT1, Clk, CNT_7__N_1385, CNT1_N_558_adj_115, 
            n11898) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n11843;
    input \CNT[4] ;
    input \CNT[3] ;
    output n11706;
    output [0:0]CNT1_N_558;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558_adj_115;
    input n11898;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    LUT4 i7504_2_lut_rep_230_3_lut_4_lut (.A(\CNT[2] ), .B(n11843), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n11706)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7504_2_lut_rep_230_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n11843), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_115[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11898), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U28
//

module COUNTER_U28 (\CNT[1] , \CNT[0] , CNT1, Clk, CNT_7__N_1385, 
            n11904, n11843, \CNT[2] , n11804, CNT1_N_558, \CNT[3] , 
            n11744, CNT1_N_558_adj_113) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input n11904;
    output n11843;
    input \CNT[2] ;
    output n11804;
    output [0:0]CNT1_N_558;
    input \CNT[3] ;
    output n11744;
    output [0:0]CNT1_N_558_adj_113;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558_c;
    
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_558_c[0])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_c[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11904), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i7308_2_lut_rep_367 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n11843)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i7308_2_lut_rep_367.init = 16'heeee;
    LUT4 i7433_2_lut_rep_328_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n11804)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7433_2_lut_rep_328_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i7476_2_lut_rep_268_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n11744)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7476_2_lut_rep_268_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_558_adj_113[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U29
//

module COUNTER_U29 (CNT1, Clk, CNT_7__N_1385, \CNT[0] , n11901) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    output \CNT[0] ;
    input n11901;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11901), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i2190_1_lut (.A(\CNT[0] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1663[26:36])
    defparam i2190_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U30
//

module COUNTER_U30 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[7] , 
            n11883) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[7] ;
    input n11883;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11883), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U99
//

module FIFO_HPOSCNT_U99 (nVIS, ZH_FF, Clk, Clk_enable_260, n12276, 
            \EN[3] , Clk_enable_423, n12292, n4076, CNT, \SEL_LATCH[3] , 
            SH3, n11937, CNT1, CNT1_adj_105, n11940, n11943, CNT1_adj_106, 
            CNT1_adj_107, n11958, n11949, CNT1_adj_108, CNT1_adj_109, 
            n11955, n11946, CNT1_adj_110, n11952, CNT1_adj_111) /* synthesis syn_module_defined=1 */ ;
    input nVIS;
    output ZH_FF;
    input Clk;
    input Clk_enable_260;
    input n12276;
    output \EN[3] ;
    input Clk_enable_423;
    input n12292;
    output n4076;
    output [7:0]CNT;
    input \SEL_LATCH[3] ;
    input SH3;
    input n11937;
    output CNT1;
    output CNT1_adj_105;
    input n11940;
    input n11943;
    output CNT1_adj_106;
    output CNT1_adj_107;
    input n11958;
    input n11949;
    output CNT1_adj_108;
    output CNT1_adj_109;
    input n11955;
    input n11946;
    output CNT1_adj_110;
    input n11952;
    output CNT1_adj_111;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire EN_N_1388, ZH_FF_N_1394, n14, n10, CNT_7__N_1385;
    wire [0:0]CNT1_N_558;
    wire [0:0]CNT1_N_558_adj_1788;
    
    wire n11740;
    wire [0:0]CNT1_N_558_adj_1789;
    wire [0:0]CNT1_N_558_adj_1790;
    
    wire n11780;
    wire [0:0]CNT1_N_558_adj_1791;
    
    wire n11803, n11842;
    wire [0:0]CNT1_N_558_adj_1792;
    
    LUT4 i10812_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1388)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1456[27:44])
    defparam i10812_2_lut.init = 16'h1111;
    FD1P3IX ZH_FF_36 (.D(n12276), .SP(Clk_enable_260), .CD(ZH_FF_N_1394), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    FD1P3AX EN_37 (.D(EN_N_1388), .SP(Clk_enable_423), .CK(Clk), .Q(\EN[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 PCLK_I_0_40_2_lut (.A(n12292), .B(n4076), .Z(ZH_FF_N_1394)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1454[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n4076)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i10809_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n12292), .B(ZH_FF), .C(\SEL_LATCH[3] ), 
         .D(SH3), .Z(CNT_7__N_1385)) /* synthesis lut_function=(!(A (C (D))+!A (B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1447[16:33])
    defparam i10809_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h1bbb;
    COUNTER_U31 FIFOCNT_6 (.\CNT[6] (CNT[6]), .Clk(Clk), .n11937(n11937), 
            .CNT1(CNT1), .CNT_7__N_1385(CNT_7__N_1385), .CNT1_N_558({CNT1_N_558})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U32 FIFOCNT_5 (.CNT1(CNT1_adj_105), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1788}), .\CNT[5] (CNT[5]), .n11940(n11940), 
            .n11740(n11740), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_558_adj_104({CNT1_N_558_adj_1789})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U33 FIFOCNT_4 (.\CNT[4] (CNT[4]), .Clk(Clk), .n11943(n11943), 
            .CNT1(CNT1_adj_106), .CNT_7__N_1385(CNT_7__N_1385), .CNT1_N_558({CNT1_N_558_adj_1790}), 
            .n11780(n11780), .\CNT[6] (CNT[6]), .\CNT[5] (CNT[5]), .CNT1_N_558_adj_102({CNT1_N_558})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U34 FIFOCNT_3 (.CNT1(CNT1_adj_107), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1791}), .\CNT[3] (CNT[3]), .n11958(n11958), 
            .n11803(n11803), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_558_adj_100({CNT1_N_558_adj_1788})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U35 FIFOCNT_2 (.\CNT[2] (CNT[2]), .Clk(Clk), .n11949(n11949), 
            .n11842(n11842), .\CNT[4] (CNT[4]), .\CNT[3] (CNT[3]), .n11740(n11740), 
            .CNT1_N_558({CNT1_N_558_adj_1790}), .CNT1(CNT1_adj_108), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558_adj_98({CNT1_N_558_adj_1792})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U36 FIFOCNT_1 (.CNT1(CNT1_adj_109), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .n11955(n11955), .n11842(n11842), 
            .\CNT[2] (CNT[2]), .n11803(n11803), .CNT1_N_558({CNT1_N_558_adj_1792}), 
            .\CNT[3] (CNT[3]), .n11780(n11780), .CNT1_N_558_adj_96({CNT1_N_558_adj_1791})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U37 FIFOCNT_0 (.\CNT[0] (CNT[0]), .Clk(Clk), .n11946(n11946), 
            .CNT1(CNT1_adj_110), .CNT_7__N_1385(CNT_7__N_1385)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U38 CNT_7__I_0_39 (.\CNT[7] (CNT[7]), .Clk(Clk), .n11952(n11952), 
            .CNT1(CNT1_adj_111), .CNT_7__N_1385(CNT_7__N_1385), .CNT1_N_558({CNT1_N_558_adj_1789})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U31
//

module COUNTER_U31 (\CNT[6] , Clk, n11937, CNT1, CNT_7__N_1385, CNT1_N_558) /* synthesis syn_module_defined=1 */ ;
    output \CNT[6] ;
    input Clk;
    input n11937;
    output CNT1;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1S3AX CNT_14 (.D(n11937), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U32
//

module COUNTER_U32 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[5] , 
            n11940, n11740, \CNT[6] , \CNT[7] , CNT1_N_558_adj_104) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[5] ;
    input n11940;
    input n11740;
    input \CNT[6] ;
    input \CNT[7] ;
    output [0:0]CNT1_N_558_adj_104;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11940), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n11740), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_558_adj_104[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    
endmodule
//
// Verilog Description of module COUNTER_U33
//

module COUNTER_U33 (\CNT[4] , Clk, n11943, CNT1, CNT_7__N_1385, CNT1_N_558, 
            n11780, \CNT[6] , \CNT[5] , CNT1_N_558_adj_102) /* synthesis syn_module_defined=1 */ ;
    output \CNT[4] ;
    input Clk;
    input n11943;
    output CNT1;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    input n11780;
    input \CNT[6] ;
    input \CNT[5] ;
    output [0:0]CNT1_N_558_adj_102;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1S3AX CNT_14 (.D(n11943), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n11780), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_558_adj_102[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U34
//

module COUNTER_U34 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[3] , 
            n11958, n11803, \CNT[5] , \CNT[4] , CNT1_N_558_adj_100) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[3] ;
    input n11958;
    input n11803;
    input \CNT[5] ;
    input \CNT[4] ;
    output [0:0]CNT1_N_558_adj_100;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11958), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n11803), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_558_adj_100[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U35
//

module COUNTER_U35 (\CNT[2] , Clk, n11949, n11842, \CNT[4] , \CNT[3] , 
            n11740, CNT1_N_558, CNT1, CNT_7__N_1385, CNT1_N_558_adj_98) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input Clk;
    input n11949;
    input n11842;
    input \CNT[4] ;
    input \CNT[3] ;
    output n11740;
    output [0:0]CNT1_N_558;
    output CNT1;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558_adj_98;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1S3AX CNT_14 (.D(n11949), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i7502_2_lut_rep_264_3_lut_4_lut (.A(\CNT[2] ), .B(n11842), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n11740)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7502_2_lut_rep_264_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n11842), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_98[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U36
//

module COUNTER_U36 (CNT1, Clk, CNT_7__N_1385, \CNT[1] , \CNT[0] , 
            n11955, n11842, \CNT[2] , n11803, CNT1_N_558, \CNT[3] , 
            n11780, CNT1_N_558_adj_96) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    output \CNT[1] ;
    input \CNT[0] ;
    input n11955;
    output n11842;
    input \CNT[2] ;
    output n11803;
    output [0:0]CNT1_N_558;
    input \CNT[3] ;
    output n11780;
    output [0:0]CNT1_N_558_adj_96;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558_c[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_558_c[0])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1S3AX CNT_14 (.D(n11955), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i7304_2_lut_rep_366 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n11842)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i7304_2_lut_rep_366.init = 16'heeee;
    LUT4 i7431_2_lut_rep_327_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n11803)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7431_2_lut_rep_327_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i7474_2_lut_rep_304_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n11780)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7474_2_lut_rep_304_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_558_adj_96[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U37
//

module COUNTER_U37 (\CNT[0] , Clk, n11946, CNT1, CNT_7__N_1385) /* synthesis syn_module_defined=1 */ ;
    output \CNT[0] ;
    input Clk;
    input n11946;
    output CNT1;
    input CNT_7__N_1385;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558;
    
    FD1S3AX CNT_14 (.D(n11946), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i2133_1_lut (.A(\CNT[0] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1663[26:36])
    defparam i2133_1_lut.init = 16'h5555;
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U38
//

module COUNTER_U38 (\CNT[7] , Clk, n11952, CNT1, CNT_7__N_1385, CNT1_N_558) /* synthesis syn_module_defined=1 */ ;
    output \CNT[7] ;
    input Clk;
    input n11952;
    output CNT1;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1S3AX CNT_14 (.D(n11952), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U100
//

module FIFO_HPOSCNT_U100 (nVIS, ZH_FF, Clk, Clk_enable_258, n12276, 
            \EN[2] , Clk_enable_423, n12292, n4077, CNT, \SEL_LATCH[2] , 
            SH3, CNT1, n11916, CNT1_adj_88, n11919, CNT1_adj_89, 
            n11922, CNT1_adj_90, n11925, CNT1_adj_91, n11928, CNT1_adj_92, 
            n11934, CNT1_adj_93, n11931, CNT1_adj_94, n11913) /* synthesis syn_module_defined=1 */ ;
    input nVIS;
    output ZH_FF;
    input Clk;
    input Clk_enable_258;
    input n12276;
    output \EN[2] ;
    input Clk_enable_423;
    input n12292;
    output n4077;
    output [7:0]CNT;
    input \SEL_LATCH[2] ;
    input SH3;
    output CNT1;
    input n11916;
    output CNT1_adj_88;
    input n11919;
    output CNT1_adj_89;
    input n11922;
    output CNT1_adj_90;
    input n11925;
    output CNT1_adj_91;
    input n11928;
    output CNT1_adj_92;
    input n11934;
    output CNT1_adj_93;
    input n11931;
    output CNT1_adj_94;
    input n11913;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire EN_N_1388, ZH_FF_N_1394, n14, n10, CNT_7__N_1385;
    wire [0:0]CNT1_N_558;
    wire [0:0]CNT1_N_558_adj_1759;
    
    wire n11743;
    wire [0:0]CNT1_N_558_adj_1760;
    wire [0:0]CNT1_N_558_adj_1761;
    
    wire n11783;
    wire [0:0]CNT1_N_558_adj_1762;
    
    wire n11805, n11844;
    wire [0:0]CNT1_N_558_adj_1763;
    
    LUT4 i10807_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1388)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1456[27:44])
    defparam i10807_2_lut.init = 16'h1111;
    FD1P3IX ZH_FF_36 (.D(n12276), .SP(Clk_enable_258), .CD(ZH_FF_N_1394), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    FD1P3AX EN_37 (.D(EN_N_1388), .SP(Clk_enable_423), .CK(Clk), .Q(\EN[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 PCLK_I_0_40_2_lut (.A(n12292), .B(n4077), .Z(ZH_FF_N_1394)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1454[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n4077)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i10804_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n12292), .B(ZH_FF), .C(\SEL_LATCH[2] ), 
         .D(SH3), .Z(CNT_7__N_1385)) /* synthesis lut_function=(!(A (C (D))+!A (B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1447[16:33])
    defparam i10804_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h1bbb;
    COUNTER_U39 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558}), .\CNT[6] (CNT[6]), .n11916(n11916)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U40 FIFOCNT_5 (.CNT1(CNT1_adj_88), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1759}), .\CNT[5] (CNT[5]), .n11919(n11919), 
            .n11743(n11743), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_558_adj_87({CNT1_N_558_adj_1760})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U41 FIFOCNT_4 (.CNT1(CNT1_adj_89), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1761}), .\CNT[4] (CNT[4]), .n11922(n11922), 
            .n11783(n11783), .\CNT[6] (CNT[6]), .\CNT[5] (CNT[5]), .CNT1_N_558_adj_85({CNT1_N_558})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U42 FIFOCNT_3 (.CNT1(CNT1_adj_90), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1762}), .\CNT[3] (CNT[3]), .n11925(n11925), 
            .n11805(n11805), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_558_adj_83({CNT1_N_558_adj_1759})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U43 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n11844(n11844), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .n11743(n11743), .CNT1_N_558({CNT1_N_558_adj_1761}), 
            .CNT1(CNT1_adj_91), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558_adj_81({CNT1_N_558_adj_1763}), .n11928(n11928)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U44 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .CNT1(CNT1_adj_92), 
            .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), .n11934(n11934), 
            .n11844(n11844), .\CNT[2] (CNT[2]), .n11805(n11805), .CNT1_N_558({CNT1_N_558_adj_1763}), 
            .\CNT[3] (CNT[3]), .n11783(n11783), .CNT1_N_558_adj_79({CNT1_N_558_adj_1762})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U45 FIFOCNT_0 (.\CNT[0] (CNT[0]), .CNT1(CNT1_adj_93), .Clk(Clk), 
            .CNT_7__N_1385(CNT_7__N_1385), .n11931(n11931)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U46 CNT_7__I_0_39 (.CNT1(CNT1_adj_94), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1760}), .\CNT[7] (CNT[7]), .n11913(n11913)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U39
//

module COUNTER_U39 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[6] , 
            n11916) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[6] ;
    input n11916;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11916), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U40
//

module COUNTER_U40 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[5] , 
            n11919, n11743, \CNT[6] , \CNT[7] , CNT1_N_558_adj_87) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[5] ;
    input n11919;
    input n11743;
    input \CNT[6] ;
    input \CNT[7] ;
    output [0:0]CNT1_N_558_adj_87;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11919), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n11743), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_558_adj_87[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    
endmodule
//
// Verilog Description of module COUNTER_U41
//

module COUNTER_U41 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[4] , 
            n11922, n11783, \CNT[6] , \CNT[5] , CNT1_N_558_adj_85) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[4] ;
    input n11922;
    input n11783;
    input \CNT[6] ;
    input \CNT[5] ;
    output [0:0]CNT1_N_558_adj_85;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11922), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n11783), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_558_adj_85[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U42
//

module COUNTER_U42 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[3] , 
            n11925, n11805, \CNT[5] , \CNT[4] , CNT1_N_558_adj_83) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[3] ;
    input n11925;
    input n11805;
    input \CNT[5] ;
    input \CNT[4] ;
    output [0:0]CNT1_N_558_adj_83;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11925), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n11805), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_558_adj_83[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U43
//

module COUNTER_U43 (\CNT[2] , n11844, \CNT[4] , \CNT[3] , n11743, 
            CNT1_N_558, CNT1, Clk, CNT_7__N_1385, CNT1_N_558_adj_81, 
            n11928) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n11844;
    input \CNT[4] ;
    input \CNT[3] ;
    output n11743;
    output [0:0]CNT1_N_558;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558_adj_81;
    input n11928;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    LUT4 i7500_2_lut_rep_267_3_lut_4_lut (.A(\CNT[2] ), .B(n11844), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n11743)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7500_2_lut_rep_267_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n11844), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_81[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11928), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U44
//

module COUNTER_U44 (\CNT[1] , \CNT[0] , CNT1, Clk, CNT_7__N_1385, 
            n11934, n11844, \CNT[2] , n11805, CNT1_N_558, \CNT[3] , 
            n11783, CNT1_N_558_adj_79) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input n11934;
    output n11844;
    input \CNT[2] ;
    output n11805;
    output [0:0]CNT1_N_558;
    input \CNT[3] ;
    output n11783;
    output [0:0]CNT1_N_558_adj_79;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558_c;
    
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_558_c[0])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_c[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11934), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i7301_2_lut_rep_368 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n11844)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i7301_2_lut_rep_368.init = 16'heeee;
    LUT4 i7429_2_lut_rep_329_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n11805)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7429_2_lut_rep_329_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i7472_2_lut_rep_307_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n11783)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7472_2_lut_rep_307_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_558_adj_79[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U45
//

module COUNTER_U45 (\CNT[0] , CNT1, Clk, CNT_7__N_1385, n11931) /* synthesis syn_module_defined=1 */ ;
    output \CNT[0] ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input n11931;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558;
    
    LUT4 i2076_1_lut (.A(\CNT[0] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1663[26:36])
    defparam i2076_1_lut.init = 16'h5555;
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11931), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U46
//

module COUNTER_U46 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[7] , 
            n11913) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[7] ;
    input n11913;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11913), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U101
//

module FIFO_HPOSCNT_U101 (nVIS, ZH_FF, Clk, Clk_enable_250, n12276, 
            \EN[1] , Clk_enable_530, n12292, n4078, CNT, CNT1, CNT_7__N_1385, 
            n12060, CNT1_adj_71, n11847, CNT1_adj_72, n11850, CNT1_adj_73, 
            n11853, CNT1_adj_74, n11859, CNT1_adj_75, n11868, CNT1_adj_76, 
            n11865, CNT1_adj_77, n12057) /* synthesis syn_module_defined=1 */ ;
    input nVIS;
    output ZH_FF;
    input Clk;
    input Clk_enable_250;
    input n12276;
    output \EN[1] ;
    input Clk_enable_530;
    input n12292;
    output n4078;
    output [7:0]CNT;
    output CNT1;
    input CNT_7__N_1385;
    input n12060;
    output CNT1_adj_71;
    input n11847;
    output CNT1_adj_72;
    input n11850;
    output CNT1_adj_73;
    input n11853;
    output CNT1_adj_74;
    input n11859;
    output CNT1_adj_75;
    input n11868;
    output CNT1_adj_76;
    input n11865;
    output CNT1_adj_77;
    input n12057;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire EN_N_1388, ZH_FF_N_1394, n14, n10;
    wire [0:0]CNT1_N_558;
    
    wire n11712;
    wire [0:0]CNT1_N_558_adj_1730;
    wire [0:0]CNT1_N_558_adj_1731;
    wire [0:0]CNT1_N_558_adj_1732;
    
    wire n11752;
    wire [0:0]CNT1_N_558_adj_1733;
    
    wire n11788, n11818;
    wire [0:0]CNT1_N_558_adj_1734;
    
    LUT4 i10802_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1388)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1456[27:44])
    defparam i10802_2_lut.init = 16'h1111;
    FD1P3IX ZH_FF_36 (.D(n12276), .SP(Clk_enable_250), .CD(ZH_FF_N_1394), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    FD1P3AX EN_37 (.D(EN_N_1388), .SP(Clk_enable_530), .CK(Clk), .Q(\EN[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 PCLK_I_0_40_2_lut (.A(n12292), .B(n4078), .Z(ZH_FF_N_1394)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1454[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n4078)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i2_2_lut.init = 16'heeee;
    COUNTER_U47 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558}), .\CNT[6] (CNT[6]), .n12060(n12060)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U48 FIFOCNT_5 (.\CNT[5] (CNT[5]), .n11712(n11712), .\CNT[6] (CNT[6]), 
            .\CNT[7] (CNT[7]), .CNT1_N_558({CNT1_N_558_adj_1730}), .CNT1(CNT1_adj_71), 
            .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), .CNT1_N_558_adj_70({CNT1_N_558_adj_1731}), 
            .n11847(n11847)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U49 FIFOCNT_4 (.CNT1(CNT1_adj_72), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1732}), .\CNT[4] (CNT[4]), .n11850(n11850), 
            .n11752(n11752), .\CNT[6] (CNT[6]), .\CNT[5] (CNT[5]), .CNT1_N_558_adj_68({CNT1_N_558})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U50 FIFOCNT_3 (.CNT1(CNT1_adj_73), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1733}), .\CNT[3] (CNT[3]), .n11853(n11853), 
            .n11788(n11788), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_558_adj_66({CNT1_N_558_adj_1731})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U51 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n11818(n11818), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .n11712(n11712), .CNT1_N_558({CNT1_N_558_adj_1732}), 
            .CNT1(CNT1_adj_74), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558_adj_64({CNT1_N_558_adj_1734}), .n11859(n11859)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U52 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .n11818(n11818), 
            .\CNT[2] (CNT[2]), .n11788(n11788), .CNT1_N_558({CNT1_N_558_adj_1734}), 
            .\CNT[3] (CNT[3]), .n11752(n11752), .CNT1_N_558_adj_62({CNT1_N_558_adj_1733}), 
            .CNT1(CNT1_adj_75), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .n11868(n11868)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U53 FIFOCNT_0 (.CNT1(CNT1_adj_76), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .\CNT[0] (CNT[0]), .n11865(n11865)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U54 CNT_7__I_0_39 (.CNT1(CNT1_adj_77), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1730}), .\CNT[7] (CNT[7]), .n12057(n12057)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U47
//

module COUNTER_U47 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[6] , 
            n12060) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[6] ;
    input n12060;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12060), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U48
//

module COUNTER_U48 (\CNT[5] , n11712, \CNT[6] , \CNT[7] , CNT1_N_558, 
            CNT1, Clk, CNT_7__N_1385, CNT1_N_558_adj_70, n11847) /* synthesis syn_module_defined=1 */ ;
    output \CNT[5] ;
    input n11712;
    input \CNT[6] ;
    input \CNT[7] ;
    output [0:0]CNT1_N_558;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558_adj_70;
    input n11847;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n11712), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_70[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11847), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U49
//

module COUNTER_U49 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[4] , 
            n11850, n11752, \CNT[6] , \CNT[5] , CNT1_N_558_adj_68) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[4] ;
    input n11850;
    input n11752;
    input \CNT[6] ;
    input \CNT[5] ;
    output [0:0]CNT1_N_558_adj_68;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11850), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n11752), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_558_adj_68[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U50
//

module COUNTER_U50 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[3] , 
            n11853, n11788, \CNT[5] , \CNT[4] , CNT1_N_558_adj_66) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[3] ;
    input n11853;
    input n11788;
    input \CNT[5] ;
    input \CNT[4] ;
    output [0:0]CNT1_N_558_adj_66;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11853), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n11788), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_558_adj_66[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U51
//

module COUNTER_U51 (\CNT[2] , n11818, \CNT[4] , \CNT[3] , n11712, 
            CNT1_N_558, CNT1, Clk, CNT_7__N_1385, CNT1_N_558_adj_64, 
            n11859) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n11818;
    input \CNT[4] ;
    input \CNT[3] ;
    output n11712;
    output [0:0]CNT1_N_558;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558_adj_64;
    input n11859;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    LUT4 i7498_2_lut_rep_236_3_lut_4_lut (.A(\CNT[2] ), .B(n11818), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n11712)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7498_2_lut_rep_236_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n11818), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_64[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11859), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U52
//

module COUNTER_U52 (\CNT[1] , \CNT[0] , n11818, \CNT[2] , n11788, 
            CNT1_N_558, \CNT[3] , n11752, CNT1_N_558_adj_62, CNT1, 
            Clk, CNT_7__N_1385, n11868) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    output n11818;
    input \CNT[2] ;
    output n11788;
    output [0:0]CNT1_N_558;
    input \CNT[3] ;
    output n11752;
    output [0:0]CNT1_N_558_adj_62;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input n11868;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558_adj_1709;
    
    LUT4 i7299_2_lut_rep_342 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n11818)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i7299_2_lut_rep_342.init = 16'heeee;
    LUT4 i7427_2_lut_rep_312_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n11788)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7427_2_lut_rep_312_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i7470_2_lut_rep_276_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n11752)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7470_2_lut_rep_276_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_558_adj_62[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_558_adj_1709[0])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_1709[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11868), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U53
//

module COUNTER_U53 (CNT1, Clk, CNT_7__N_1385, \CNT[0] , n11865) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    output \CNT[0] ;
    input n11865;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11865), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i2019_1_lut (.A(\CNT[0] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1663[26:36])
    defparam i2019_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U54
//

module COUNTER_U54 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[7] , 
            n12057) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[7] ;
    input n12057;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12057), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U102
//

module FIFO_HPOSCNT_U102 (nVIS, ZH_FF, Clk, n12276, \EN[0] , Clk_enable_530, 
            n12292, CNT, \ZPOS[2] , n4078, Clk_enable_250, n4077, 
            Clk_enable_258, n4076, Clk_enable_260, n4075, Clk_enable_265, 
            n4065, Clk_enable_268, n4045, Clk_enable_270, n4024, Clk_enable_272, 
            CNT1, CNT_7__N_1385, n11988, CNT1_adj_54, n11991, CNT1_adj_55, 
            n11994, CNT1_adj_56, n11997, CNT1_adj_57, n12000, CNT1_adj_58, 
            n12006, CNT1_adj_59, n12003, CNT1_adj_60, n11985) /* synthesis syn_module_defined=1 */ ;
    input nVIS;
    output ZH_FF;
    input Clk;
    input n12276;
    output \EN[0] ;
    input Clk_enable_530;
    input n12292;
    output [7:0]CNT;
    input \ZPOS[2] ;
    input n4078;
    output Clk_enable_250;
    input n4077;
    output Clk_enable_258;
    input n4076;
    output Clk_enable_260;
    input n4075;
    output Clk_enable_265;
    input n4065;
    output Clk_enable_268;
    input n4045;
    output Clk_enable_270;
    input n4024;
    output Clk_enable_272;
    output CNT1;
    input CNT_7__N_1385;
    input n11988;
    output CNT1_adj_54;
    input n11991;
    output CNT1_adj_55;
    input n11994;
    output CNT1_adj_56;
    input n11997;
    output CNT1_adj_57;
    input n12000;
    output CNT1_adj_58;
    input n12006;
    output CNT1_adj_59;
    input n12003;
    output CNT1_adj_60;
    input n11985;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire EN_N_1388, Clk_enable_249, ZH_FF_N_1394, n4079, n14, n10;
    wire [0:0]CNT1_N_558;
    wire [0:0]CNT1_N_558_adj_1701;
    
    wire n11719;
    wire [0:0]CNT1_N_558_adj_1702;
    
    wire n11764;
    wire [0:0]CNT1_N_558_adj_1703;
    wire [0:0]CNT1_N_558_adj_1704;
    
    wire n11796, n11831;
    wire [0:0]CNT1_N_558_adj_1705;
    
    LUT4 i10795_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1388)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1456[27:44])
    defparam i10795_2_lut.init = 16'h1111;
    FD1P3IX ZH_FF_36 (.D(n12276), .SP(Clk_enable_249), .CD(ZH_FF_N_1394), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    FD1P3AX EN_37 (.D(EN_N_1388), .SP(Clk_enable_530), .CK(Clk), .Q(\EN[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1453[8] 1457[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 PCLK_I_0_40_2_lut (.A(n12292), .B(n4079), .Z(ZH_FF_N_1394)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1454[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n4079)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1455[32:46])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i7275_2_lut_3_lut (.A(n12292), .B(\ZPOS[2] ), .C(n4079), .Z(Clk_enable_249)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i7275_2_lut_3_lut.init = 16'h8080;
    LUT4 i7277_2_lut_3_lut (.A(n12292), .B(\ZPOS[2] ), .C(n4078), .Z(Clk_enable_250)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i7277_2_lut_3_lut.init = 16'h8080;
    LUT4 i7279_2_lut_3_lut (.A(n12292), .B(\ZPOS[2] ), .C(n4077), .Z(Clk_enable_258)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i7279_2_lut_3_lut.init = 16'h8080;
    LUT4 i7281_2_lut_3_lut (.A(n12292), .B(\ZPOS[2] ), .C(n4076), .Z(Clk_enable_260)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i7281_2_lut_3_lut.init = 16'h8080;
    LUT4 i7283_2_lut_3_lut (.A(n12292), .B(\ZPOS[2] ), .C(n4075), .Z(Clk_enable_265)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i7283_2_lut_3_lut.init = 16'h8080;
    LUT4 i7285_2_lut_3_lut (.A(n12292), .B(\ZPOS[2] ), .C(n4065), .Z(Clk_enable_268)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i7285_2_lut_3_lut.init = 16'h8080;
    LUT4 i7287_2_lut_3_lut (.A(n12292), .B(\ZPOS[2] ), .C(n4045), .Z(Clk_enable_270)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i7287_2_lut_3_lut.init = 16'h8080;
    LUT4 i7291_2_lut_3_lut (.A(n12292), .B(\ZPOS[2] ), .C(n4024), .Z(Clk_enable_272)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i7291_2_lut_3_lut.init = 16'h8080;
    COUNTER_U55 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558}), .\CNT[6] (CNT[6]), .n11988(n11988)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U56 FIFOCNT_5 (.CNT1(CNT1_adj_54), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1701}), .\CNT[5] (CNT[5]), .n11991(n11991), 
            .n11719(n11719), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_558_adj_53({CNT1_N_558_adj_1702})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U57 FIFOCNT_4 (.\CNT[4] (CNT[4]), .n11764(n11764), .\CNT[6] (CNT[6]), 
            .\CNT[5] (CNT[5]), .CNT1_N_558({CNT1_N_558}), .CNT1(CNT1_adj_55), 
            .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), .CNT1_N_558_adj_51({CNT1_N_558_adj_1703}), 
            .n11994(n11994)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U58 FIFOCNT_3 (.CNT1(CNT1_adj_56), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1704}), .\CNT[3] (CNT[3]), .n11997(n11997), 
            .n11796(n11796), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_558_adj_49({CNT1_N_558_adj_1701})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U59 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n11831(n11831), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .n11719(n11719), .CNT1_N_558({CNT1_N_558_adj_1703}), 
            .CNT1(CNT1_adj_57), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558_adj_47({CNT1_N_558_adj_1705}), .n12000(n12000)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U60 FIFOCNT_1 (.CNT1(CNT1_adj_58), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .\CNT[1] (CNT[1]), .n12006(n12006), .\CNT[0] (CNT[0]), .n11831(n11831), 
            .\CNT[2] (CNT[2]), .n11796(n11796), .CNT1_N_558({CNT1_N_558_adj_1705}), 
            .\CNT[3] (CNT[3]), .n11764(n11764), .CNT1_N_558_adj_45({CNT1_N_558_adj_1704})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U61 FIFOCNT_0 (.CNT1(CNT1_adj_59), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .\CNT[0] (CNT[0]), .n12003(n12003)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    COUNTER_U62 CNT_7__I_0_39 (.CNT1(CNT1_adj_60), .Clk(Clk), .CNT_7__N_1385(CNT_7__N_1385), 
            .CNT1_N_558({CNT1_N_558_adj_1702}), .\CNT[7] (CNT[7]), .n11985(n11985)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1451[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U55
//

module COUNTER_U55 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[6] , 
            n11988) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[6] ;
    input n11988;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11988), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U56
//

module COUNTER_U56 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[5] , 
            n11991, n11719, \CNT[6] , \CNT[7] , CNT1_N_558_adj_53) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[5] ;
    input n11991;
    input n11719;
    input \CNT[6] ;
    input \CNT[7] ;
    output [0:0]CNT1_N_558_adj_53;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11991), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n11719), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_558_adj_53[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    
endmodule
//
// Verilog Description of module COUNTER_U57
//

module COUNTER_U57 (\CNT[4] , n11764, \CNT[6] , \CNT[5] , CNT1_N_558, 
            CNT1, Clk, CNT_7__N_1385, CNT1_N_558_adj_51, n11994) /* synthesis syn_module_defined=1 */ ;
    output \CNT[4] ;
    input n11764;
    input \CNT[6] ;
    input \CNT[5] ;
    output [0:0]CNT1_N_558;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558_adj_51;
    input n11994;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n11764), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_51[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11994), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U58
//

module COUNTER_U58 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[3] , 
            n11997, n11796, \CNT[5] , \CNT[4] , CNT1_N_558_adj_49) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[3] ;
    input n11997;
    input n11796;
    input \CNT[5] ;
    input \CNT[4] ;
    output [0:0]CNT1_N_558_adj_49;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11997), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n11796), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_558_adj_49[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U59
//

module COUNTER_U59 (\CNT[2] , n11831, \CNT[4] , \CNT[3] , n11719, 
            CNT1_N_558, CNT1, Clk, CNT_7__N_1385, CNT1_N_558_adj_47, 
            n12000) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n11831;
    input \CNT[4] ;
    input \CNT[3] ;
    output n11719;
    output [0:0]CNT1_N_558;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558_adj_47;
    input n12000;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    LUT4 i7496_2_lut_rep_243_3_lut_4_lut (.A(\CNT[2] ), .B(n11831), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n11719)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7496_2_lut_rep_243_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n11831), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_47[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12000), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U60
//

module COUNTER_U60 (CNT1, Clk, CNT_7__N_1385, \CNT[1] , n12006, \CNT[0] , 
            n11831, \CNT[2] , n11796, CNT1_N_558, \CNT[3] , n11764, 
            CNT1_N_558_adj_45) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    output \CNT[1] ;
    input n12006;
    input \CNT[0] ;
    output n11831;
    input \CNT[2] ;
    output n11796;
    output [0:0]CNT1_N_558;
    input \CNT[3] ;
    output n11764;
    output [0:0]CNT1_N_558_adj_45;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558_c[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12006), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i7297_2_lut_rep_355 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n11831)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i7297_2_lut_rep_355.init = 16'heeee;
    LUT4 i7425_2_lut_rep_320_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n11796)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7425_2_lut_rep_320_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i7468_2_lut_rep_288_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n11764)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7468_2_lut_rep_288_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_558_adj_45[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_558_c[0])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U61
//

module COUNTER_U61 (CNT1, Clk, CNT_7__N_1385, \CNT[0] , n12003) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    output \CNT[0] ;
    input n12003;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n12003), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1962_1_lut (.A(\CNT[0] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1663[26:36])
    defparam i1962_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U62
//

module COUNTER_U62 (CNT1, Clk, CNT_7__N_1385, CNT1_N_558, \CNT[7] , 
            n11985) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1385;
    input [0:0]CNT1_N_558;
    output \CNT[7] ;
    input n11985;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(CNT_7__N_1385), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n11985), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG
//

module SHIFTREG (\QP[0] , Clk, Clk_enable_530, \SDATA[0] , n11722, 
            n11769, \QP[1] , Clk_enable_526, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL1[7] , \QS_IN[7] , 
            n5240, n5236, n5232, n5228, n5216, n5210, n5205) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_530;
    input \SDATA[0] ;
    input n11722;
    input n11769;
    output \QP[1] ;
    input Clk_enable_526;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[7] ;
    output \QS_IN[7] ;
    input n5240;
    input n5236;
    input n5232;
    input n5228;
    input n5216;
    input n5210;
    input n5205;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5550;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_530), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5550), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5045_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11722), .D(n11769), 
         .Z(n5550)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5045_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_526), .CK(Clk), .Q(\COL1[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5240), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5236), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5232), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5228), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5216), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5210), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5205), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U103
//

module SHIFTREG_U103 (\QP[0] , Clk, Clk_enable_530, \SDATA[0] , n11725, 
            n11770, \QP[1] , Clk_enable_526, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL1[6] , \QS_IN[7] , 
            n5316, n5308, n5302, n5300, n5292, n5283, n5279) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_530;
    input \SDATA[0] ;
    input n11725;
    input n11770;
    output \QP[1] ;
    input Clk_enable_526;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[6] ;
    output \QS_IN[7] ;
    input n5316;
    input n5308;
    input n5302;
    input n5300;
    input n5292;
    input n5283;
    input n5279;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5554;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_530), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5554), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5049_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11725), .D(n11770), 
         .Z(n5554)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5049_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_526), .CK(Clk), .Q(\COL1[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5316), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5308), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5302), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5300), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5292), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5283), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5279), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U104
//

module SHIFTREG_U104 (\QP[0] , Clk, Clk_enable_530, \SDATA[0] , n11727, 
            n11771, \QP[1] , Clk_enable_526, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL1[5] , \QS_IN[7] , 
            n5368, n5364, n5360, n5354, n5350, n5346, n5344) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_530;
    input \SDATA[0] ;
    input n11727;
    input n11771;
    output \QP[1] ;
    input Clk_enable_526;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[5] ;
    output \QS_IN[7] ;
    input n5368;
    input n5364;
    input n5360;
    input n5354;
    input n5350;
    input n5346;
    input n5344;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5558;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_530), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5558), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5053_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11727), .D(n11771), 
         .Z(n5558)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5053_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_526), .CK(Clk), .Q(\COL1[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5368), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5364), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5360), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5354), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5350), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5346), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5344), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U105
//

module SHIFTREG_U105 (\QP[0] , Clk, Clk_enable_530, \SDATA[0] , n11730, 
            n11773, \QP[1] , Clk_enable_473, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL1[4] , \QS_IN[7] , 
            n5466, n5462, n5458, n5448, n5434, n5422, n5412) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_530;
    input \SDATA[0] ;
    input n11730;
    input n11773;
    output \QP[1] ;
    input Clk_enable_473;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[4] ;
    output \QS_IN[7] ;
    input n5466;
    input n5462;
    input n5458;
    input n5448;
    input n5434;
    input n5422;
    input n5412;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5562;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_530), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5562), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5057_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11730), .D(n11773), 
         .Z(n5562)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5057_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_473), .CK(Clk), .Q(\COL1[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5466), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5462), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5458), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5448), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5434), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5422), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5412), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U106
//

module SHIFTREG_U106 (\QP[0] , Clk, Clk_enable_530, \SDATA[0] , n11732, 
            n11774, \QP[1] , Clk_enable_473, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL1[3] , \QS_IN[7] , 
            n5522, n5516, n5514, n5512, n5510, n5508, n5502) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_530;
    input \SDATA[0] ;
    input n11732;
    input n11774;
    output \QP[1] ;
    input Clk_enable_473;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[3] ;
    output \QS_IN[7] ;
    input n5522;
    input n5516;
    input n5514;
    input n5512;
    input n5510;
    input n5508;
    input n5502;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5566;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_530), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5566), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5061_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11732), .D(n11774), 
         .Z(n5566)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5061_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_473), .CK(Clk), .Q(\COL1[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5522), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5516), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5514), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5512), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5510), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5508), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5502), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U107
//

module SHIFTREG_U107 (\QP[0] , Clk, Clk_enable_530, \SDATA[0] , n11734, 
            n11775, \QP[1] , Clk_enable_473, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL1[2] , \QS_IN[7] , 
            n5646, n5644, n5642, n5640, n5638, n5636, n5634) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_530;
    input \SDATA[0] ;
    input n11734;
    input n11775;
    output \QP[1] ;
    input Clk_enable_473;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[2] ;
    output \QS_IN[7] ;
    input n5646;
    input n5644;
    input n5642;
    input n5640;
    input n5638;
    input n5636;
    input n5634;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5570;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_530), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5570), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5065_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11734), .D(n11775), 
         .Z(n5570)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5065_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_473), .CK(Clk), .Q(\COL1[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5646), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5644), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5642), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5640), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5638), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5636), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5634), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U108
//

module SHIFTREG_U108 (\QP[0] , Clk, Clk_enable_530, \SDATA[0] , n11736, 
            n11776, \QP[1] , Clk_enable_423, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , Clk_enable_473, \QS_IN[5] , \QP[6] , \QS_IN[6] , 
            \COL1[1] , \QS_IN[7] , n5674, n5672, n5670, n5668, n5666, 
            n5664, n5662) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_530;
    input \SDATA[0] ;
    input n11736;
    input n11776;
    output \QP[1] ;
    input Clk_enable_423;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    input Clk_enable_473;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[1] ;
    output \QS_IN[7] ;
    input n5674;
    input n5672;
    input n5670;
    input n5668;
    input n5666;
    input n5664;
    input n5662;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5574;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_530), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5574), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5069_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11736), .D(n11776), 
         .Z(n5574)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5069_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_473), .CK(Clk), .Q(\COL1[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5674), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5672), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5670), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5668), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5666), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5664), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5662), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U109
//

module SHIFTREG_U109 (\QP[0] , Clk, Clk_enable_185, \SDATA[0] , n11738, 
            n11779, \QP[1] , Clk_enable_423, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL1[0] , \QS_IN[7] , 
            n5702, n5700, n5698, n5696, n5694, n5692, n5690) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_185;
    input \SDATA[0] ;
    input n11738;
    input n11779;
    output \QP[1] ;
    input Clk_enable_423;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[0] ;
    output \QS_IN[7] ;
    input n5702;
    input n5700;
    input n5698;
    input n5696;
    input n5694;
    input n5692;
    input n5690;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5578;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_185), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5578), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5073_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11738), .D(n11779), 
         .Z(n5578)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5073_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_423), .CK(Clk), .Q(\COL1[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5702), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5700), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5698), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5696), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5694), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5692), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5690), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1349, LSE_RLINE=1349 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U110
//

module SHIFTREG_U110 (\QP[0] , Clk, Clk_enable_530, \SDATA[0] , n11723, 
            n11769, \QP[1] , Clk_enable_526, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL0[7] , \QS_IN[7] , 
            n5277, n5269, n5265, n5261, n5253, n5251, n5244) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_530;
    input \SDATA[0] ;
    input n11723;
    input n11769;
    output \QP[1] ;
    input Clk_enable_526;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[7] ;
    output \QS_IN[7] ;
    input n5277;
    input n5269;
    input n5265;
    input n5261;
    input n5253;
    input n5251;
    input n5244;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5552;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_530), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5552), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5047_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11723), .D(n11769), 
         .Z(n5552)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5047_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_526), .CK(Clk), .Q(\COL0[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5277), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5269), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5265), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5261), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5253), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5251), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5244), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U111
//

module SHIFTREG_U111 (\QP[0] , Clk, Clk_enable_530, \SDATA[0] , n11726, 
            n11770, \QP[1] , Clk_enable_526, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL0[6] , \QS_IN[7] , 
            n5340, n5336, n5328, n5324, n5322, n5320, n5318) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_530;
    input \SDATA[0] ;
    input n11726;
    input n11770;
    output \QP[1] ;
    input Clk_enable_526;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[6] ;
    output \QS_IN[7] ;
    input n5340;
    input n5336;
    input n5328;
    input n5324;
    input n5322;
    input n5320;
    input n5318;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5556;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_530), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5556), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5051_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11726), .D(n11770), 
         .Z(n5556)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5051_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_526), .CK(Clk), .Q(\COL0[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5340), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5336), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5328), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5324), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5322), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5320), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5318), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U112
//

module SHIFTREG_U112 (\QP[0] , Clk, Clk_enable_530, \SDATA[0] , n11728, 
            n11771, \QP[1] , Clk_enable_473, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , Clk_enable_526, \QS_IN[6] , 
            \COL0[5] , \QS_IN[7] , n5402, n5392, n5388, n5384, n5380, 
            n5376, n5372) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_530;
    input \SDATA[0] ;
    input n11728;
    input n11771;
    output \QP[1] ;
    input Clk_enable_473;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    input Clk_enable_526;
    output \QS_IN[6] ;
    output \COL0[5] ;
    output \QS_IN[7] ;
    input n5402;
    input n5392;
    input n5388;
    input n5384;
    input n5380;
    input n5376;
    input n5372;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5560;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_530), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5560), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5055_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11728), .D(n11771), 
         .Z(n5560)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5055_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_526), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_526), .CK(Clk), .Q(\COL0[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5402), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5392), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5388), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5384), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5380), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5376), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5372), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U113
//

module SHIFTREG_U113 (\QP[0] , Clk, Clk_enable_530, \SDATA[0] , n11731, 
            n11773, \QP[1] , Clk_enable_473, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL0[4] , \QS_IN[7] , 
            n5498, n5487, n5485, n5482, n5478, n5473, n5469) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_530;
    input \SDATA[0] ;
    input n11731;
    input n11773;
    output \QP[1] ;
    input Clk_enable_473;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[4] ;
    output \QS_IN[7] ;
    input n5498;
    input n5487;
    input n5485;
    input n5482;
    input n5478;
    input n5473;
    input n5469;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5564;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_530), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5564), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5059_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11731), .D(n11773), 
         .Z(n5564)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5059_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_473), .CK(Clk), .Q(\COL0[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5498), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5487), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5485), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5482), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5478), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5473), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5469), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U114
//

module SHIFTREG_U114 (\QP[0] , Clk, Clk_enable_530, \SDATA[0] , n11733, 
            n11774, \QP[1] , Clk_enable_473, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL0[3] , \QS_IN[7] , 
            n5632, n5630, n5628, n5626, n5624, n5526, n5524) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_530;
    input \SDATA[0] ;
    input n11733;
    input n11774;
    output \QP[1] ;
    input Clk_enable_473;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[3] ;
    output \QS_IN[7] ;
    input n5632;
    input n5630;
    input n5628;
    input n5626;
    input n5624;
    input n5526;
    input n5524;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5568;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_530), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5568), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5063_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11733), .D(n11774), 
         .Z(n5568)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5063_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_473), .CK(Clk), .Q(\COL0[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5632), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5630), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5628), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5626), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5624), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5526), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5524), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U115
//

module SHIFTREG_U115 (\QP[0] , Clk, Clk_enable_530, \SDATA[0] , n11735, 
            n11775, \QP[1] , Clk_enable_473, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL0[2] , \QS_IN[7] , 
            n5660, n5658, n5656, n5654, n5652, n5650, n5648) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_530;
    input \SDATA[0] ;
    input n11735;
    input n11775;
    output \QP[1] ;
    input Clk_enable_473;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[2] ;
    output \QS_IN[7] ;
    input n5660;
    input n5658;
    input n5656;
    input n5654;
    input n5652;
    input n5650;
    input n5648;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5572;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_530), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5572), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5067_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11735), .D(n11775), 
         .Z(n5572)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5067_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_473), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_473), .CK(Clk), .Q(\COL0[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5660), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5658), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5656), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5654), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5652), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5650), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5648), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U116
//

module SHIFTREG_U116 (\QP[0] , Clk, Clk_enable_185, \SDATA[0] , n11737, 
            n11776, \QP[1] , Clk_enable_423, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL0[1] , \QS_IN[7] , 
            n5688, n5686, n5684, n5682, n5680, n5678, n5676) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_185;
    input \SDATA[0] ;
    input n11737;
    input n11776;
    output \QP[1] ;
    input Clk_enable_423;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[1] ;
    output \QS_IN[7] ;
    input n5688;
    input n5686;
    input n5684;
    input n5682;
    input n5680;
    input n5678;
    input n5676;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5576;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_185), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5576), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5071_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11737), .D(n11776), 
         .Z(n5576)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5071_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_423), .CK(Clk), .Q(\COL0[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5688), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5686), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5684), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5682), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5680), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5678), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5676), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U117
//

module SHIFTREG_U117 (\QP[0] , Clk, Clk_enable_185, \SDATA[0] , n11739, 
            n11779, \QP[1] , Clk_enable_423, \QS_IN[1] , \QP[2] , 
            \QS_IN[2] , \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , 
            \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , \COL0[0] , \QS_IN[7] , 
            n5716, n5714, n5712, n5710, n5708, n5706, n5704) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_185;
    input \SDATA[0] ;
    input n11739;
    input n11779;
    output \QP[1] ;
    input Clk_enable_423;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[0] ;
    output \QS_IN[7] ;
    input n5716;
    input n5714;
    input n5712;
    input n5710;
    input n5708;
    input n5706;
    input n5704;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5580;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_185), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5580), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    LUT4 i5075_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n11739), .D(n11779), 
         .Z(n5580)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5075_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_423), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_423), .CK(Clk), .Q(\COL0[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5716), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5714), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5712), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5710), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5708), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5706), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5704), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1348, LSE_RLINE=1348 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module PUR
// module not written out since it is a black-box. 
//

//
// Verilog Description of module TIMING_GENERATOR
//

module TIMING_GENERATOR (SYNC_c, Hnn, Clk, Clk_enable_513, \Hn[0] , 
            Clk_enable_562, Vo, n11839, RC, RESCL, n12275, n11753, 
            E_EV, Clk_enable_564, \H[8] , n11800, I_OAM2, VBL_EN, 
            INT_c, THO, \PAMUX_7__N_852[1] , PAR_O, \PAMUX_7__N_852[2] , 
            \TVO[2] , \PAMUX_7__N_852[3] , \TVO[3] , \PAMUX_7__N_852[4] , 
            \TVO[0] , \TVO[4] , \PAMUX_7__N_852[5] , \PAMUX_7__N_852[0] , 
            n11840, BLNK_FF, TVO1, n10702, TVZB, TVZ, Clk_enable_83, 
            nRD_c, n11750, NTV_IN, NTVDO, n11724, n4185, n11694, 
            n11691, \W4Q[4] , \W4Q[2] , OAMQ_7__N_1034, nVIS, OAP_N_1084, 
            n12292, \Hn[2] , n5786, n11816, n10992, I1_32, n11729, 
            CNT1_N_558, FTA_OUT, NFO_OUT, n11811, Clk_enable_293, 
            Clk_enable_549, F_NT, RESCL_IN, HC, Clk_enable_185, S_EV, 
            n11749, n11797, n11701, CLIP_OUT, O_HPOS, BGCLIP, CLIP_B_N_240, 
            OVZ, SPR_OV, n11692, nEVAL, OMFG, n11755, nPICTURE, 
            OMSTEP_1__N_1046, Clk_enable_423, n11794, N_HB, \Hn[1] , 
            SH2_N_1365, SH5_N_1378, SH3_N_1374, SH7_N_1383, n10784, 
            \R2DB[0] , n4, n4641, R2, n10489, OMV_LATCH, n11830, 
            Clk_enable_526, n4_adj_43, DENDY_IN_c, nRES_c, \R2DB[2] , 
            Clk_enable_553, Clk_enable_530, Vo_7__N_205, Clk_enable_367, 
            H_8__N_226) /* synthesis syn_module_defined=1 */ ;
    output SYNC_c;
    output [5:0]Hnn;
    input Clk;
    input Clk_enable_513;
    output \Hn[0] ;
    input Clk_enable_562;
    output [7:0]Vo;
    input n11839;
    output RC;
    output RESCL;
    input n12275;
    input n11753;
    output E_EV;
    input Clk_enable_564;
    output \H[8] ;
    input n11800;
    output I_OAM2;
    input VBL_EN;
    output INT_c;
    input [4:0]THO;
    output \PAMUX_7__N_852[1] ;
    output PAR_O;
    output \PAMUX_7__N_852[2] ;
    input \TVO[2] ;
    output \PAMUX_7__N_852[3] ;
    input \TVO[3] ;
    output \PAMUX_7__N_852[4] ;
    input \TVO[0] ;
    input \TVO[4] ;
    output \PAMUX_7__N_852[5] ;
    output \PAMUX_7__N_852[0] ;
    input n11840;
    output BLNK_FF;
    input TVO1;
    input n10702;
    output TVZB;
    output TVZ;
    input Clk_enable_83;
    output nRD_c;
    output n11750;
    input NTV_IN;
    input NTVDO;
    output n11724;
    input n4185;
    output n11694;
    output n11691;
    input \W4Q[4] ;
    input \W4Q[2] ;
    output OAMQ_7__N_1034;
    output nVIS;
    output OAP_N_1084;
    input n12292;
    output \Hn[2] ;
    output n5786;
    input n11816;
    output n10992;
    input I1_32;
    output n11729;
    output [0:0]CNT1_N_558;
    output FTA_OUT;
    output NFO_OUT;
    output n11811;
    output Clk_enable_293;
    input Clk_enable_549;
    output F_NT;
    output RESCL_IN;
    output HC;
    input Clk_enable_185;
    output S_EV;
    input n11749;
    output n11797;
    output n11701;
    output CLIP_OUT;
    output O_HPOS;
    input BGCLIP;
    output CLIP_B_N_240;
    input OVZ;
    input SPR_OV;
    output n11692;
    output nEVAL;
    output OMFG;
    output n11755;
    output nPICTURE;
    output OMSTEP_1__N_1046;
    input Clk_enable_423;
    output n11794;
    output N_HB;
    output \Hn[1] ;
    output SH2_N_1365;
    output SH5_N_1378;
    output SH3_N_1374;
    output SH7_N_1383;
    input n10784;
    input \R2DB[0] ;
    input n4;
    output n4641;
    input R2;
    output n10489;
    input OMV_LATCH;
    input n11830;
    input Clk_enable_526;
    input n4_adj_43;
    input DENDY_IN_c;
    input nRES_c;
    output \R2DB[2] ;
    input Clk_enable_553;
    input Clk_enable_530;
    input Vo_7__N_205;
    input Clk_enable_367;
    input H_8__N_226;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire HSYNCo, VSYNC;
    wire [2:0]VSET;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(729[10:14])
    
    wire VSET_0__N_224;
    wire [8:0]H;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(735[11:12])
    
    wire FTB_IN_N_360, V_LINE0N_N_480, n25, n6, n12273, n11819, 
        n11058, n11807, H_LINE2_N_439, FTA_IN_N_369, nRES_N_8, NFO1_N_375;
    wire [1:0]ODDEVEN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(704[10:17])
    wire [8:0]V;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(735[14:15])
    
    wire FAT_IN_N_275, n11757, n11823, n7645, n11700, EEV_IN, n11815, 
        n10701, H_LINE6_N_453, n11820, n11715, IOAM2_IN, INT_FF, 
        FAT_IN, n11829, PARO_IN, VB_FF, CLIP2_N_336, PARO_IN_N_352, 
        n11710, n7, n11821, n11717, NVIS_IN_N_254, Clk_enable_76, 
        INT_FF_N_430, FNT_IN_N_357, n10790, n11810, VSYNCo_N_320, 
        n6_adj_1645, n10, FTB_OUT, FTB_IN_N_366, NVIS_IN_N_251, FTA_IN_N_372, 
        n11789, n14, VC_LATCH_N_211, CLIP1, CLIP2, CLIP_OUT_N_331, 
        FPORCH_FF_N_309, VSYNC_N_401, PICT1, BPORCH_FF, PICT2, PEN_FF, 
        FNT_IN, HC_N_231, HPOS_IN, H_LINE5_N_446, EVAL_IN, H_LINE7_N_461, 
        NVIS_IN, SEV_IN, FTB_IN, FTA_IN, NFO1, NFO2, CLIP1_N_339, 
        n11746, n10876, n28, n11824, nEVAL_N_244, n11790, n11822, 
        n4312, n11791, n11716, n6_adj_1646, V_8__N_508, ODDEVEN_0__N_214, 
        VSET_1__N_219, VSET_0__N_222, Clk_enable_565;
    wire [5:0]Hn;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(673[16:18])
    wire [5:0]Hnn_c;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(69[11:14])
    
    wire n13, n11627, n11628, n11714, FPORCH_FF, VSYNCo, n11, 
        n11703, Clk_enable_543, Clk_enable_544, n11629, Clk_enable_545, 
        n10882, n10826, Clk_enable_546, BPORCH_FF_N_413, N_HB_N_293, 
        n11240, Clk_enable_548, H_LINE23_N_471, n5, n8, n7714, n12, 
        Clk_enable_547, n6_adj_1648, HIN5;
    wire [0:0]CNT1_N_558_adj_1663;
    wire [0:0]CNT1_N_558_adj_1664;
    wire [0:0]CNT1_N_558_adj_1665;
    
    wire n11693, n11695;
    wire [0:0]CNT1_N_558_adj_1666;
    wire [0:0]CNT1_N_558_adj_1667;
    
    wire n11696;
    wire [0:0]CNT1_N_558_adj_1668;
    
    wire n11697, n11704;
    wire [0:0]CNT1_N_558_adj_1669;
    wire [0:0]CNT1_N_558_adj_1670;
    
    wire n11721;
    wire [0:0]CNT1_N_558_adj_1671;
    wire [0:0]CNT1_N_558_adj_1672;
    wire [0:0]CNT1_N_558_adj_1673;
    wire [0:0]CNT1_N_558_adj_1674;
    wire [0:0]CNT1_N_558_adj_1675;
    
    wire n11809;
    wire [0:0]CNT1_N_558_adj_1676;
    
    LUT4 HSYNCo_I_0_702_2_lut (.A(HSYNCo), .B(VSYNC), .Z(SYNC_c)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(783[15:28])
    defparam HSYNCo_I_0_702_2_lut.init = 16'heeee;
    FD1P3AX Hnn_i0_i0 (.D(\Hn[0] ), .SP(Clk_enable_513), .CK(Clk), .Q(Hnn[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam Hnn_i0_i0.GSR = "DISABLED";
    FD1P3AX VSET_i0 (.D(VSET_0__N_224), .SP(Clk_enable_562), .CK(Clk), 
            .Q(VSET[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam VSET_i0.GSR = "DISABLED";
    LUT4 i7179_2_lut (.A(H[2]), .B(H[1]), .Z(FTB_IN_N_360)) /* synthesis lut_function=(A (B)) */ ;
    defparam i7179_2_lut.init = 16'h8888;
    LUT4 i1_4_lut_4_lut (.A(V_LINE0N_N_480), .B(Vo[0]), .C(Vo[1]), .D(Vo[2]), 
         .Z(n25)) /* synthesis lut_function=(!(A+!(B (C (D))+!B !(C+!(D))))) */ ;
    defparam i1_4_lut_4_lut.init = 16'h4100;
    LUT4 Vo_0__bdd_4_lut (.A(Vo[0]), .B(V_LINE0N_N_480), .C(n6), .D(n11839), 
         .Z(n12273)) /* synthesis lut_function=(!(A ((D)+!C)+!A (B ((D)+!C)+!B !(C+(D))))) */ ;
    defparam Vo_0__bdd_4_lut.init = 16'h11f0;
    LUT4 i10593_3_lut_4_lut (.A(H[4]), .B(n11819), .C(n11058), .D(n11807), 
         .Z(H_LINE2_N_439)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(829[24:60])
    defparam i10593_3_lut_4_lut.init = 16'h0010;
    LUT4 i10651_2_lut (.A(H[2]), .B(H[1]), .Z(FTA_IN_N_369)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(839[23:40])
    defparam i10651_2_lut.init = 16'h2222;
    FD1P3JX RC_637 (.D(n12275), .SP(RESCL), .PD(nRES_N_8), .CK(Clk), 
            .Q(RC)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam RC_637.GSR = "DISABLED";
    LUT4 i10654_2_lut_4_lut (.A(n11753), .B(H[6]), .C(H[5]), .D(H[4]), 
         .Z(NFO1_N_375)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(749[22:43])
    defparam i10654_2_lut_4_lut.init = 16'h0004;
    FD1P3IX ODDEVEN_i0 (.D(ODDEVEN[1]), .SP(V[8]), .CD(nRES_N_8), .CK(Clk), 
            .Q(ODDEVEN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam ODDEVEN_i0.GSR = "DISABLED";
    LUT4 i10662_2_lut (.A(H[2]), .B(H[1]), .Z(FAT_IN_N_275)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(842[23:40])
    defparam i10662_2_lut.init = 16'h4444;
    LUT4 i10590_3_lut_rep_224_4_lut (.A(n11757), .B(n11823), .C(n7645), 
         .D(H[2]), .Z(n11700)) /* synthesis lut_function=(!(A+(B+!(C (D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(748[20:93])
    defparam i10590_3_lut_rep_224_4_lut.init = 16'h1000;
    FD1P3AX E_EV_645 (.D(EEV_IN), .SP(Clk_enable_564), .CK(Clk), .Q(E_EV));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam E_EV_645.GSR = "DISABLED";
    LUT4 i10598_2_lut_3_lut_4_lut_4_lut (.A(n11815), .B(n10701), .C(\H[8] ), 
         .D(n11800), .Z(H_LINE6_N_453)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(834[23:56])
    defparam i10598_2_lut_3_lut_4_lut_4_lut.init = 16'h0004;
    LUT4 i1_2_lut_rep_239_3_lut_4_lut (.A(H[6]), .B(n11820), .C(n11823), 
         .D(H[5]), .Z(n11715)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(749[22:43])
    defparam i1_2_lut_rep_239_3_lut_4_lut.init = 16'hfffe;
    FD1P3AX I_OAM2_646 (.D(IOAM2_IN), .SP(Clk_enable_564), .CK(Clk), .Q(I_OAM2));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam I_OAM2_646.GSR = "DISABLED";
    LUT4 VBL_EN_I_0_2_lut (.A(VBL_EN), .B(INT_FF), .Z(INT_c)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(787[14:29])
    defparam VBL_EN_I_0_2_lut.init = 16'h8888;
    LUT4 mux_67_i2_3_lut_4_lut (.A(FAT_IN), .B(n11829), .C(THO[1]), .D(THO[3]), 
         .Z(\PAMUX_7__N_852[1] )) /* synthesis lut_function=(A (B (C)+!B (D))+!A (C)) */ ;
    defparam mux_67_i2_3_lut_4_lut.init = 16'hf2d0;
    FD1P3AX PAR_O_647 (.D(PARO_IN), .SP(Clk_enable_564), .CK(Clk), .Q(PAR_O));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam PAR_O_647.GSR = "DISABLED";
    LUT4 mux_67_i3_3_lut_4_lut (.A(FAT_IN), .B(n11829), .C(THO[2]), .D(THO[4]), 
         .Z(\PAMUX_7__N_852[2] )) /* synthesis lut_function=(A (B (C)+!B (D))+!A (C)) */ ;
    defparam mux_67_i3_3_lut_4_lut.init = 16'hf2d0;
    LUT4 mux_67_i4_3_lut_4_lut (.A(FAT_IN), .B(n11829), .C(THO[3]), .D(\TVO[2] ), 
         .Z(\PAMUX_7__N_852[3] )) /* synthesis lut_function=(A (B (C)+!B (D))+!A (C)) */ ;
    defparam mux_67_i4_3_lut_4_lut.init = 16'hf2d0;
    LUT4 mux_67_i5_3_lut_4_lut (.A(FAT_IN), .B(n11829), .C(THO[4]), .D(\TVO[3] ), 
         .Z(\PAMUX_7__N_852[4] )) /* synthesis lut_function=(A (B (C)+!B (D))+!A (C)) */ ;
    defparam mux_67_i5_3_lut_4_lut.init = 16'hf2d0;
    LUT4 mux_67_i6_3_lut_4_lut (.A(FAT_IN), .B(n11829), .C(\TVO[0] ), 
         .D(\TVO[4] ), .Z(\PAMUX_7__N_852[5] )) /* synthesis lut_function=(A (B (C)+!B (D))+!A (C)) */ ;
    defparam mux_67_i6_3_lut_4_lut.init = 16'hf2d0;
    LUT4 mux_67_i1_3_lut_4_lut (.A(FAT_IN), .B(n11829), .C(THO[0]), .D(THO[2]), 
         .Z(\PAMUX_7__N_852[0] )) /* synthesis lut_function=(A (B (C)+!B (D))+!A (C)) */ ;
    defparam mux_67_i1_3_lut_4_lut.init = 16'hf2d0;
    LUT4 i10636_2_lut (.A(\H[8] ), .B(VB_FF), .Z(CLIP2_N_336)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(830[23:41])
    defparam i10636_2_lut.init = 16'h4444;
    LUT4 i2_3_lut_4_lut (.A(n11840), .B(BLNK_FF), .C(TVO1), .D(n10702), 
         .Z(TVZB)) /* synthesis lut_function=(A (B (C (D)))+!A (C (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam i2_3_lut_4_lut.init = 16'hd000;
    LUT4 i1_3_lut_4_lut (.A(n11840), .B(BLNK_FF), .C(TVO1), .D(n10702), 
         .Z(TVZ)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam i1_3_lut_4_lut.init = 16'h0200;
    LUT4 nRD_I_0_1_lut_3_lut_4_lut (.A(n11840), .B(BLNK_FF), .C(Hnn[0]), 
         .D(Clk_enable_83), .Z(nRD_c)) /* synthesis lut_function=(!(A (B (D)+!B (C+(D)))+!A (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam nRD_I_0_1_lut_3_lut_4_lut.init = 16'h00df;
    LUT4 i10643_2_lut_3_lut_3_lut_4_lut (.A(n11840), .B(BLNK_FF), .C(\H[8] ), 
         .D(n11815), .Z(PARO_IN_N_352)) /* synthesis lut_function=(!((B+((D)+!C))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam i10643_2_lut_3_lut_3_lut_4_lut.init = 16'h0020;
    LUT4 i10640_2_lut_rep_234_3_lut_3_lut_4_lut (.A(n11840), .B(BLNK_FF), 
         .C(\H[8] ), .D(n11815), .Z(n11710)) /* synthesis lut_function=(!((B+(C+(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam i10640_2_lut_rep_234_3_lut_3_lut_4_lut.init = 16'h0002;
    LUT4 i10674_4_lut_rep_241 (.A(n7), .B(n11821), .C(Vo[5]), .D(V[8]), 
         .Z(n11717)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(856[10:40])
    defparam i10674_4_lut_rep_241.init = 16'h0001;
    LUT4 PD_RB_I_0_3_lut_rep_274_4_lut (.A(n11840), .B(BLNK_FF), .C(Hnn[0]), 
         .D(Clk_enable_83), .Z(n11750)) /* synthesis lut_function=(A (B (D)+!B (C+(D)))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam PD_RB_I_0_3_lut_rep_274_4_lut.init = 16'hff20;
    LUT4 FV_IN_I_0_3_lut_rep_248_4_lut (.A(n11840), .B(BLNK_FF), .C(NTV_IN), 
         .D(NTVDO), .Z(n11724)) /* synthesis lut_function=(A ((C (D))+!B)+!A (C (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam FV_IN_I_0_3_lut_rep_248_4_lut.init = 16'hf222;
    LUT4 OMFG_N_1050_I_0_2_lut_rep_215_3_lut_4_lut (.A(n11840), .B(BLNK_FF), 
         .C(n4185), .D(n11694), .Z(n11691)) /* synthesis lut_function=((B+(C+(D)))+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam OMFG_N_1050_I_0_2_lut_rep_215_3_lut_4_lut.init = 16'hfffd;
    LUT4 i10645_2_lut_3_lut_4_lut (.A(n11840), .B(BLNK_FF), .C(VB_FF), 
         .D(\H[8] ), .Z(NVIS_IN_N_254)) /* synthesis lut_function=(!((B+((D)+!C))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam i10645_2_lut_3_lut_4_lut.init = 16'h0020;
    LUT4 i2_3_lut_4_lut_adj_409 (.A(n11840), .B(BLNK_FF), .C(\W4Q[4] ), 
         .D(\W4Q[2] ), .Z(OAMQ_7__N_1034)) /* synthesis lut_function=(!(A ((C+!(D))+!B)+!A (C+!(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam i2_3_lut_4_lut_adj_409.init = 16'h0d00;
    LUT4 OAP_I_298_3_lut_4_lut (.A(n11840), .B(BLNK_FF), .C(nVIS), .D(Hnn[0]), 
         .Z(OAP_N_1084)) /* synthesis lut_function=(!((B+!(C+(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam OAP_I_298_3_lut_4_lut.init = 16'h2220;
    LUT4 i5281_2_lut_3_lut_4_lut (.A(n11840), .B(BLNK_FF), .C(n12292), 
         .D(\Hn[2] ), .Z(n5786)) /* synthesis lut_function=(!((B+!(C (D)))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam i5281_2_lut_3_lut_4_lut.init = 16'h2000;
    LUT4 i10857_2_lut_3_lut_4_lut (.A(n11840), .B(BLNK_FF), .C(n11816), 
         .D(\Hn[2] ), .Z(n10992)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam i10857_2_lut_3_lut_4_lut.init = 16'hf2f0;
    LUT4 CNT_I_0_2_lut_rep_253_3_lut_4_lut (.A(n11840), .B(BLNK_FF), .C(THO[0]), 
         .D(I1_32), .Z(n11729)) /* synthesis lut_function=(!(A (B ((D)+!C)+!B !(C))+!A ((D)+!C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam CNT_I_0_2_lut_rep_253_3_lut_4_lut.init = 16'h20f0;
    LUT4 i1_2_lut_3_lut_4_lut (.A(n11840), .B(BLNK_FF), .C(THO[0]), .D(I1_32), 
         .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (B (C (D)+!C !(D))+!B !(C))+!A (C (D)+!C !(D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(785[15:30])
    defparam i1_2_lut_3_lut_4_lut.init = 16'hd20f;
    FD1P3AX INT_FF_638 (.D(INT_FF_N_430), .SP(Clk_enable_76), .CK(Clk), 
            .Q(INT_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam INT_FF_638.GSR = "DISABLED";
    LUT4 i1_2_lut_rep_331 (.A(H[2]), .B(H[1]), .Z(n11807)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(837[24:48])
    defparam i1_2_lut_rep_331.init = 16'heeee;
    LUT4 i10649_2_lut_2_lut_3_lut_4_lut (.A(H[2]), .B(H[1]), .C(BLNK_FF), 
         .D(n11840), .Z(FNT_IN_N_357)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(837[24:48])
    defparam i10649_2_lut_2_lut_3_lut_4_lut.init = 16'h0100;
    LUT4 i2_3_lut_4_lut_adj_410 (.A(H[2]), .B(H[1]), .C(H[0]), .D(H[3]), 
         .Z(n10790)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(837[24:48])
    defparam i2_3_lut_4_lut_adj_410.init = 16'hfffe;
    LUT4 i1_2_lut_rep_334 (.A(Vo[1]), .B(Vo[2]), .Z(n11810)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(763[22:59])
    defparam i1_2_lut_rep_334.init = 16'hbbbb;
    LUT4 i1_2_lut_3_lut (.A(Vo[1]), .B(Vo[2]), .C(n12273), .Z(VSYNCo_N_320)) /* synthesis lut_function=(!(A+!(B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(763[22:59])
    defparam i1_2_lut_3_lut.init = 16'h4040;
    LUT4 i2_3_lut_4_lut_adj_411 (.A(Vo[1]), .B(Vo[2]), .C(n11839), .D(Vo[4]), 
         .Z(n6_adj_1645)) /* synthesis lut_function=(!(A+(((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(763[22:59])
    defparam i2_3_lut_4_lut_adj_411.init = 16'h0040;
    LUT4 i2_3_lut_4_lut_adj_412 (.A(Vo[1]), .B(Vo[2]), .C(Vo[0]), .D(Vo[3]), 
         .Z(n10)) /* synthesis lut_function=(!(A+!(B (C (D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(763[22:59])
    defparam i2_3_lut_4_lut_adj_412.init = 16'h4000;
    FD1P3AX FTB_OUT_650 (.D(FTB_IN_N_366), .SP(Clk_enable_564), .CK(Clk), 
            .Q(FTB_OUT));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam FTB_OUT_650.GSR = "DISABLED";
    FD1P3AX nVIS_648 (.D(NVIS_IN_N_251), .SP(Clk_enable_564), .CK(Clk), 
            .Q(nVIS));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam nVIS_648.GSR = "DISABLED";
    FD1P3AX FTA_OUT_651 (.D(FTA_IN_N_372), .SP(Clk_enable_564), .CK(Clk), 
            .Q(FTA_OUT));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam FTA_OUT_651.GSR = "DISABLED";
    LUT4 i3_4_lut (.A(Vo[0]), .B(n11789), .C(Vo[3]), .D(n14), .Z(VC_LATCH_N_211)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;
    defparam i3_4_lut.init = 16'h0200;
    LUT4 FTB_OUT_I_0_715_2_lut_rep_335 (.A(FTB_OUT), .B(NFO_OUT), .Z(n11811)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(774[16:37])
    defparam FTB_OUT_I_0_715_2_lut_rep_335.init = 16'heeee;
    LUT4 i10619_2_lut (.A(CLIP1), .B(CLIP2), .Z(CLIP_OUT_N_331)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(805[23:42])
    defparam i10619_2_lut.init = 16'h4444;
    FD1P3AX NFO_OUT_652 (.D(n11829), .SP(Clk_enable_564), .CK(Clk), .Q(NFO_OUT));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam NFO_OUT_652.GSR = "DISABLED";
    LUT4 PD_SR_N_676_I_0_2_lut_rep_222_3_lut_3_lut_4_lut (.A(FTB_OUT), .B(NFO_OUT), 
         .C(Hnn[0]), .D(n12292), .Z(Clk_enable_293)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(774[16:37])
    defparam PD_SR_N_676_I_0_2_lut_rep_222_3_lut_3_lut_4_lut.init = 16'h0010;
    FD1P3AX HSYNC_654 (.D(FPORCH_FF_N_309), .SP(Clk_enable_564), .CK(Clk), 
            .Q(HSYNCo));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam HSYNC_654.GSR = "DISABLED";
    FD1P3AX VSYNC_655 (.D(VSYNC_N_401), .SP(Clk_enable_549), .CK(Clk), 
            .Q(VSYNC));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam VSYNC_655.GSR = "DISABLED";
    FD1P3AX PICT1_656 (.D(BPORCH_FF), .SP(Clk_enable_549), .CK(Clk), .Q(PICT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam PICT1_656.GSR = "DISABLED";
    FD1P3AX PICT2_657 (.D(PEN_FF), .SP(Clk_enable_549), .CK(Clk), .Q(PICT2));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam PICT2_657.GSR = "DISABLED";
    FD1P3AX F_NT_649 (.D(FNT_IN), .SP(Clk_enable_549), .CK(Clk), .Q(F_NT));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam F_NT_649.GSR = "DISABLED";
    FD1P3AX RESCL_658 (.D(RESCL_IN), .SP(Clk_enable_549), .CK(Clk), .Q(RESCL));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam RESCL_658.GSR = "DISABLED";
    FD1P3AX HC_660 (.D(HC_N_231), .SP(Clk_enable_185), .CK(Clk), .Q(HC));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam HC_660.GSR = "DISABLED";
    FD1P3AX CLIP2_665 (.D(CLIP2_N_336), .SP(Clk_enable_185), .CK(Clk), 
            .Q(CLIP2));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam CLIP2_665.GSR = "DISABLED";
    FD1P3AX HPOS_IN_666 (.D(H_LINE5_N_446), .SP(Clk_enable_185), .CK(Clk), 
            .Q(HPOS_IN));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam HPOS_IN_666.GSR = "DISABLED";
    FD1P3AX EVAL_IN_667 (.D(H_LINE6_N_453), .SP(Clk_enable_185), .CK(Clk), 
            .Q(EVAL_IN));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam EVAL_IN_667.GSR = "DISABLED";
    FD1P3AX EEV_IN_668 (.D(H_LINE7_N_461), .SP(Clk_enable_185), .CK(Clk), 
            .Q(EEV_IN));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam EEV_IN_668.GSR = "DISABLED";
    FD1P3AX IOAM2_IN_669 (.D(n11710), .SP(Clk_enable_185), .CK(Clk), .Q(IOAM2_IN));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam IOAM2_IN_669.GSR = "DISABLED";
    FD1P3AX PARO_IN_670 (.D(PARO_IN_N_352), .SP(Clk_enable_185), .CK(Clk), 
            .Q(PARO_IN));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam PARO_IN_670.GSR = "DISABLED";
    FD1P3AX NVIS_IN_671 (.D(NVIS_IN_N_254), .SP(Clk_enable_185), .CK(Clk), 
            .Q(NVIS_IN));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam NVIS_IN_671.GSR = "DISABLED";
    FD1P3AX SEV_IN_663 (.D(H_LINE2_N_439), .SP(Clk_enable_185), .CK(Clk), 
            .Q(SEV_IN));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam SEV_IN_663.GSR = "DISABLED";
    FD1P3AX FNT_IN_672 (.D(FNT_IN_N_357), .SP(Clk_enable_185), .CK(Clk), 
            .Q(FNT_IN));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam FNT_IN_672.GSR = "DISABLED";
    FD1P3AX FTB_IN_673 (.D(FTB_IN_N_360), .SP(Clk_enable_185), .CK(Clk), 
            .Q(FTB_IN));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam FTB_IN_673.GSR = "DISABLED";
    FD1P3AX S_EV_641 (.D(SEV_IN), .SP(Clk_enable_549), .CK(Clk), .Q(S_EV));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam S_EV_641.GSR = "DISABLED";
    FD1P3AX FTA_IN_674 (.D(FTA_IN_N_369), .SP(Clk_enable_185), .CK(Clk), 
            .Q(FTA_IN));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam FTA_IN_674.GSR = "DISABLED";
    FD1P3AX NFO1_675 (.D(NFO1_N_375), .SP(Clk_enable_185), .CK(Clk), .Q(NFO1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam NFO1_675.GSR = "DISABLED";
    FD1P3AX NFO2_676 (.D(n11749), .SP(Clk_enable_185), .CK(Clk), .Q(NFO2));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam NFO2_676.GSR = "DISABLED";
    LUT4 Hnn0_I_0_2_lut_rep_321_3_lut (.A(FTB_OUT), .B(NFO_OUT), .C(Hnn[0]), 
         .Z(n11797)) /* synthesis lut_function=(!(A+(B+!(C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(774[16:37])
    defparam Hnn0_I_0_2_lut_rep_321_3_lut.init = 16'h1010;
    FD1P3AX FAT_IN_677 (.D(FAT_IN_N_275), .SP(Clk_enable_185), .CK(Clk), 
            .Q(FAT_IN));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam FAT_IN_677.GSR = "DISABLED";
    LUT4 i7197_2_lut_rep_225_2_lut_3_lut_4_lut_4_lut (.A(FTB_OUT), .B(NFO_OUT), 
         .C(n12292), .D(Hnn[0]), .Z(n11701)) /* synthesis lut_function=(A (B+(C))+!A (B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(774[16:37])
    defparam i7197_2_lut_rep_225_2_lut_3_lut_4_lut_4_lut.init = 16'hfdfc;
    FD1P3AX CLIP1_664 (.D(CLIP1_N_339), .SP(Clk_enable_185), .CK(Clk), 
            .Q(CLIP1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam CLIP1_664.GSR = "DISABLED";
    FD1P3AX RESCL_IN_685 (.D(VC_LATCH_N_211), .SP(Clk_enable_185), .CK(Clk), 
            .Q(RESCL_IN));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam RESCL_IN_685.GSR = "DISABLED";
    FD1P3AX CLIP_OUT_642 (.D(CLIP_OUT_N_331), .SP(Clk_enable_549), .CK(Clk), 
            .Q(CLIP_OUT));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam CLIP_OUT_642.GSR = "DISABLED";
    FD1P3AX O_HPOS_643 (.D(HPOS_IN), .SP(Clk_enable_549), .CK(Clk), .Q(O_HPOS));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam O_HPOS_643.GSR = "DISABLED";
    LUT4 i1_4_lut (.A(n11746), .B(n10), .C(n10876), .D(Vo[4]), .Z(n28)) /* synthesis lut_function=(!(A+(B (C (D))+!B (C+!(D))))) */ ;
    defparam i1_4_lut.init = 16'h0544;
    LUT4 i1_2_lut_rep_339 (.A(H[7]), .B(H[6]), .Z(n11815)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(750[23:43])
    defparam i1_2_lut_rep_339.init = 16'heeee;
    LUT4 i10634_2_lut_2_lut_3_lut_4_lut (.A(H[7]), .B(H[6]), .C(n11819), 
         .D(H[4]), .Z(CLIP1_N_339)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(750[23:43])
    defparam i10634_2_lut_2_lut_3_lut_4_lut.init = 16'h0001;
    LUT4 i10586_2_lut (.A(CLIP_OUT), .B(BGCLIP), .Z(CLIP_B_N_240)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(733[17:39])
    defparam i10586_2_lut.init = 16'h1111;
    LUT4 i1_2_lut_rep_216_4_lut (.A(OVZ), .B(n11824), .C(SPR_OV), .D(n4185), 
         .Z(n11692)) /* synthesis lut_function=(A (D)+!A (B (D)+!B ((D)+!C))) */ ;
    defparam i1_2_lut_rep_216_4_lut.init = 16'hff01;
    FD1P3AX nEVAL_644 (.D(nEVAL_N_244), .SP(Clk_enable_549), .CK(Clk), 
            .Q(nEVAL));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam nEVAL_644.GSR = "DISABLED";
    LUT4 OMFG_I_0_1_lut_2_lut_4_lut (.A(OVZ), .B(n11824), .C(SPR_OV), 
         .D(n4185), .Z(OMFG)) /* synthesis lut_function=(!(A (D)+!A (B (D)+!B ((D)+!C)))) */ ;
    defparam OMFG_I_0_1_lut_2_lut_4_lut.init = 16'h00fe;
    LUT4 i1_2_lut_rep_343 (.A(H[3]), .B(H[5]), .Z(n11819)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(759[20:93])
    defparam i1_2_lut_rep_343.init = 16'heeee;
    LUT4 N_HB_I_59_2_lut_rep_344 (.A(\H[8] ), .B(H[7]), .Z(n11820)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(759[22:35])
    defparam N_HB_I_59_2_lut_rep_344.init = 16'hdddd;
    LUT4 i1_2_lut_rep_281_3_lut_4_lut (.A(\H[8] ), .B(H[7]), .C(H[5]), 
         .D(H[6]), .Z(n11757)) /* synthesis lut_function=((B+(C+(D)))+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(759[22:35])
    defparam i1_2_lut_rep_281_3_lut_4_lut.init = 16'hfffd;
    LUT4 i1_2_lut_rep_314_3_lut (.A(\H[8] ), .B(H[7]), .C(H[6]), .Z(n11790)) /* synthesis lut_function=((B+(C))+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(759[22:35])
    defparam i1_2_lut_rep_314_3_lut.init = 16'hfdfd;
    LUT4 i2_2_lut_3_lut_4_lut (.A(Vo[4]), .B(Vo[3]), .C(n11822), .D(Vo[0]), 
         .Z(n7)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(763[22:59])
    defparam i2_2_lut_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_adj_413 (.A(Vo[4]), .B(Vo[3]), .C(Vo[0]), .Z(n4312)) /* synthesis lut_function=(A+(B+!(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(763[22:59])
    defparam i1_2_lut_3_lut_adj_413.init = 16'hefef;
    LUT4 i1_2_lut_rep_345 (.A(Vo[7]), .B(Vo[6]), .Z(n11821)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(761[22:43])
    defparam i1_2_lut_rep_345.init = 16'heeee;
    LUT4 i1_2_lut_rep_313_3_lut (.A(Vo[7]), .B(Vo[6]), .C(V[8]), .Z(n11789)) /* synthesis lut_function=(A+(B+!(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(761[22:43])
    defparam i1_2_lut_rep_313_3_lut.init = 16'hefef;
    LUT4 V_LINE0P_I_159_2_lut_rep_270_3_lut_4_lut (.A(Vo[7]), .B(Vo[6]), 
         .C(Vo[5]), .D(V[8]), .Z(n11746)) /* synthesis lut_function=(A+(B+(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(761[22:43])
    defparam V_LINE0P_I_159_2_lut_rep_270_3_lut_4_lut.init = 16'hfeff;
    LUT4 i1_2_lut_rep_346 (.A(Vo[1]), .B(Vo[2]), .Z(n11822)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(766[22:75])
    defparam i1_2_lut_rep_346.init = 16'heeee;
    LUT4 i2_3_lut_rep_279_4_lut (.A(Vo[1]), .B(Vo[2]), .C(V_LINE0N_N_480), 
         .D(Vo[0]), .Z(n11755)) /* synthesis lut_function=(A+(B+(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(766[22:75])
    defparam i2_3_lut_rep_279_4_lut.init = 16'hfeff;
    LUT4 i1_2_lut_rep_315_3_lut (.A(Vo[1]), .B(Vo[2]), .C(Vo[0]), .Z(n11791)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(766[22:75])
    defparam i1_2_lut_rep_315_3_lut.init = 16'hfefe;
    LUT4 i10368_3_lut_4_lut (.A(Vo[1]), .B(Vo[2]), .C(Vo[3]), .D(Vo[0]), 
         .Z(n10876)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(766[22:75])
    defparam i10368_3_lut_4_lut.init = 16'hfffe;
    LUT4 i10610_2_lut_rep_240_2_lut_3_lut_4_lut (.A(Vo[1]), .B(Vo[2]), .C(V_LINE0N_N_480), 
         .D(Vo[0]), .Z(n11716)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(766[22:75])
    defparam i10610_2_lut_rep_240_2_lut_3_lut_4_lut.init = 16'h0001;
    LUT4 i3_4_lut_adj_414 (.A(Vo[3]), .B(n11746), .C(Vo[0]), .D(Vo[4]), 
         .Z(n6)) /* synthesis lut_function=(!((B+((D)+!C))+!A)) */ ;
    defparam i3_4_lut_adj_414.init = 16'h0020;
    LUT4 i1_2_lut_rep_347 (.A(H[3]), .B(H[1]), .Z(n11823)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(748[20:93])
    defparam i1_2_lut_rep_347.init = 16'hbbbb;
    LUT4 i1_2_lut_3_lut_adj_415 (.A(H[3]), .B(H[1]), .C(H[7]), .Z(n6_adj_1646)) /* synthesis lut_function=(A+((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(748[20:93])
    defparam i1_2_lut_3_lut_adj_415.init = 16'hfbfb;
    LUT4 i1_2_lut_rep_348 (.A(nVIS), .B(I_OAM2), .Z(n11824)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i1_2_lut_rep_348.init = 16'heeee;
    LUT4 PICT1_I_0_729_2_lut (.A(PICT1), .B(PICT2), .Z(nPICTURE)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(784[19:32])
    defparam PICT1_I_0_729_2_lut.init = 16'heeee;
    LUT4 i10729_3_lut_rep_218_4_lut (.A(nVIS), .B(I_OAM2), .C(SPR_OV), 
         .D(OVZ), .Z(n11694)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;
    defparam i10729_3_lut_rep_218_4_lut.init = 16'h0001;
    LUT4 i10723_2_lut_3_lut (.A(nVIS), .B(I_OAM2), .C(Hnn[0]), .Z(OMSTEP_1__N_1046)) /* synthesis lut_function=(A+(B+!(C))) */ ;
    defparam i10723_2_lut_3_lut.init = 16'hefef;
    LUT4 V_8__I_0_1_lut (.A(V[8]), .Z(V_8__N_508)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(761[22:27])
    defparam V_8__I_0_1_lut.init = 16'h5555;
    LUT4 ODDEVEN_0__I_0_1_lut (.A(ODDEVEN[0]), .Z(ODDEVEN_0__N_214)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(825[49:60])
    defparam ODDEVEN_0__I_0_1_lut.init = 16'h5555;
    LUT4 VSET_1__I_0_1_lut (.A(VSET[1]), .Z(VSET_1__N_219)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(859[22:30])
    defparam VSET_1__I_0_1_lut.init = 16'h5555;
    LUT4 VSET_0__I_0_1_lut (.A(VSET[0]), .Z(VSET_0__N_222)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(800[25:33])
    defparam VSET_0__I_0_1_lut.init = 16'h5555;
    FD1P3AX Hn_i0_i0 (.D(H[0]), .SP(Clk_enable_423), .CK(Clk), .Q(\Hn[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam Hn_i0_i0.GSR = "DISABLED";
    LUT4 i10617_2_lut_rep_353 (.A(NFO1), .B(NFO2), .Z(n11829)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(777[28:44])
    defparam i10617_2_lut_rep_353.init = 16'h1111;
    LUT4 i7165_2_lut_rep_318_3_lut (.A(NFO1), .B(NFO2), .C(FAT_IN), .Z(n11794)) /* synthesis lut_function=(A (C)+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(777[28:44])
    defparam i7165_2_lut_rep_318_3_lut.init = 16'he0e0;
    LUT4 n28_bdd_4_lut (.A(n28), .B(n25), .C(n11839), .D(N_HB), .Z(Clk_enable_565)) /* synthesis lut_function=(A (B (D)+!B !(C+!(D)))+!A (B (C (D)))) */ ;
    defparam n28_bdd_4_lut.init = 16'hca00;
    FD1P3AX ODDEVEN_i1 (.D(ODDEVEN_0__N_214), .SP(V_8__N_508), .CK(Clk), 
            .Q(ODDEVEN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam ODDEVEN_i1.GSR = "DISABLED";
    FD1P3AX VSET_i2 (.D(VSET_1__N_219), .SP(Clk_enable_423), .CK(Clk), 
            .Q(VSET[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam VSET_i2.GSR = "DISABLED";
    FD1P3AX VSET_i1 (.D(VSET_0__N_222), .SP(Clk_enable_564), .CK(Clk), 
            .Q(VSET[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam VSET_i1.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i5 (.D(Hn[5]), .SP(Clk_enable_564), .CK(Clk), .Q(Hnn[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam Hnn_i0_i5.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i4 (.D(Hn[4]), .SP(Clk_enable_564), .CK(Clk), .Q(Hnn[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam Hnn_i0_i4.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i3 (.D(Hn[3]), .SP(Clk_enable_564), .CK(Clk), .Q(Hnn[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam Hnn_i0_i3.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i2 (.D(\Hn[2] ), .SP(Clk_enable_513), .CK(Clk), .Q(Hnn_c[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam Hnn_i0_i2.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i1 (.D(\Hn[1] ), .SP(Clk_enable_513), .CK(Clk), .Q(Hnn_c[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam Hnn_i0_i1.GSR = "DISABLED";
    LUT4 i3_4_lut_adj_416 (.A(PAR_O), .B(Hnn[0]), .C(Hnn_c[1]), .D(Hnn_c[2]), 
         .Z(SH2_N_1365)) /* synthesis lut_function=(!((B+((D)+!C))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam i3_4_lut_adj_416.init = 16'h0020;
    LUT4 i2_3_lut_4_lut_adj_417 (.A(Hnn[0]), .B(PAR_O), .C(Hnn_c[2]), 
         .D(Hnn_c[1]), .Z(SH5_N_1378)) /* synthesis lut_function=(!((((D)+!C)+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam i2_3_lut_4_lut_adj_417.init = 16'h0080;
    LUT4 i1_2_lut_3_lut_4_lut_adj_418 (.A(Hnn[0]), .B(PAR_O), .C(Hnn_c[2]), 
         .D(Hnn_c[1]), .Z(SH3_N_1374)) /* synthesis lut_function=(!(((C+!(D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam i1_2_lut_3_lut_4_lut_adj_418.init = 16'h0800;
    LUT4 i1_2_lut_3_lut_4_lut_adj_419 (.A(Hnn[0]), .B(PAR_O), .C(Hnn_c[2]), 
         .D(Hnn_c[1]), .Z(SH7_N_1383)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam i1_2_lut_3_lut_4_lut_adj_419.init = 16'h8000;
    LUT4 i1_4_lut_adj_420 (.A(RESCL), .B(n10784), .C(\R2DB[0] ), .D(n4), 
         .Z(n4641)) /* synthesis lut_function=(!(A+!(B (C)+!B (C+!(D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam i1_4_lut_adj_420.init = 16'h5051;
    LUT4 i1_4_lut_adj_421 (.A(VSET[2]), .B(INT_FF_N_430), .C(VSET[0]), 
         .D(n12292), .Z(Clk_enable_76)) /* synthesis lut_function=(!(A (B)+!A !((C (D))+!B))) */ ;
    defparam i1_4_lut_adj_421.init = 16'h7333;
    LUT4 i10861_2_lut (.A(RESCL), .B(R2), .Z(INT_FF_N_430)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(799[14:24])
    defparam i10861_2_lut.init = 16'h1111;
    LUT4 i10622_3_lut (.A(EEV_IN), .B(EVAL_IN), .C(HPOS_IN), .Z(nEVAL_N_244)) /* synthesis lut_function=(!(A+(B+(C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(807[23:54])
    defparam i10622_3_lut.init = 16'h0101;
    LUT4 i1_4_lut_adj_422 (.A(I_OAM2), .B(SPR_OV), .C(n12292), .D(n13), 
         .Z(n10489)) /* synthesis lut_function=(!(A+!(B+(C (D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam i1_4_lut_adj_422.init = 16'h5444;
    LUT4 i1_4_lut_adj_423 (.A(OMV_LATCH), .B(\Hn[0] ), .C(n11830), .D(n4), 
         .Z(n13)) /* synthesis lut_function=(!(A (B (C)+!B (C (D)))+!A (B+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam i1_4_lut_adj_423.init = 16'h0a3b;
    LUT4 VB_FF_N_261_bdd_3_lut_10905_4_lut (.A(n11789), .B(Vo[5]), .C(n11810), 
         .D(n4312), .Z(n11627)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(761[22:51])
    defparam VB_FF_N_261_bdd_3_lut_10905_4_lut.init = 16'h0001;
    PFUMX i10903 (.BLUT(n11717), .ALUT(n11627), .C0(n11839), .Z(n11628));
    LUT4 FTB_IN_I_0_1_lut (.A(FTB_IN), .Z(FTB_IN_N_366)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(813[23:30])
    defparam FTB_IN_I_0_1_lut.init = 16'h5555;
    LUT4 NVIS_IN_I_0_1_lut (.A(NVIS_IN), .Z(NVIS_IN_N_251)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(811[23:31])
    defparam NVIS_IN_I_0_1_lut.init = 16'h5555;
    LUT4 FTA_IN_I_0_1_lut (.A(FTA_IN), .Z(FTA_IN_N_372)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(814[23:30])
    defparam FTA_IN_I_0_1_lut.init = 16'h5555;
    LUT4 i2_3_lut_rep_238_4_lut (.A(n11800), .B(\H[8] ), .C(H[5]), .D(H[6]), 
         .Z(n11714)) /* synthesis lut_function=(A+((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(751[23:35])
    defparam i2_3_lut_rep_238_4_lut.init = 16'hfbff;
    LUT4 FPORCH_FF_I_0_1_lut (.A(FPORCH_FF), .Z(FPORCH_FF_N_309)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(817[23:33])
    defparam FPORCH_FF_I_0_1_lut.init = 16'h5555;
    LUT4 i10625_2_lut (.A(N_HB), .B(VSYNCo), .Z(VSYNC_N_401)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(818[23:43])
    defparam i10625_2_lut.init = 16'h1111;
    LUT4 i3_4_lut_adj_424 (.A(n11839), .B(Vo[2]), .C(Vo[1]), .D(Vo[4]), 
         .Z(n11)) /* synthesis lut_function=(!(A+!(B (C (D))))) */ ;
    defparam i3_4_lut_adj_424.init = 16'h4000;
    LUT4 V_LINE3P_N_531_bdd_3_lut_rep_227_4_lut_4_lut (.A(n11791), .B(n11755), 
         .C(n11839), .D(V_LINE0N_N_480), .Z(n11703)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C+(D))+!B !(C+!(D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(769[19:85])
    defparam V_LINE3P_N_531_bdd_3_lut_rep_227_4_lut_4_lut.init = 16'h3035;
    LUT4 i10789_3_lut_3_lut_4_lut_4_lut (.A(n11791), .B(n11717), .C(n12292), 
         .D(V_LINE0N_N_480), .Z(Clk_enable_543)) /* synthesis lut_function=(!(A ((C)+!B)+!A (B (C)+!B (C+(D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(769[19:85])
    defparam i10789_3_lut_3_lut_4_lut_4_lut.init = 16'h0c0d;
    LUT4 i10785_3_lut_4_lut_4_lut_4_lut (.A(n11791), .B(V_LINE0N_N_480), 
         .C(VC_LATCH_N_211), .D(n12292), .Z(Clk_enable_544)) /* synthesis lut_function=(!(A ((D)+!C)+!A (B ((D)+!C)+!B (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(769[19:85])
    defparam i10785_3_lut_4_lut_4_lut_4_lut.init = 16'h00f1;
    LUT4 i10783_2_lut (.A(n11629), .B(n12292), .Z(Clk_enable_545)) /* synthesis lut_function=(!((B)+!A)) */ ;
    defparam i10783_2_lut.init = 16'h2222;
    LUT4 i10768_4_lut (.A(n12292), .B(n10882), .C(n10826), .D(H[7]), 
         .Z(Clk_enable_546)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;
    defparam i10768_4_lut.init = 16'h0001;
    LUT4 i10374_4_lut (.A(H[2]), .B(H[6]), .C(H[0]), .D(n11823), .Z(n10882)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i10374_4_lut.init = 16'hfffe;
    LUT4 i10318_2_lut (.A(H[4]), .B(H[5]), .Z(n10826)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i10318_2_lut.init = 16'heeee;
    LUT4 i10665_4_lut (.A(H[4]), .B(H[0]), .C(H[2]), .D(n11715), .Z(BPORCH_FF_N_413)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(850[10:42])
    defparam i10665_4_lut.init = 16'h0001;
    LUT4 i3_4_lut_adj_425 (.A(H[5]), .B(n11790), .C(H[4]), .D(n10790), 
         .Z(N_HB_N_293)) /* synthesis lut_function=((B+((D)+!C))+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(749[22:43])
    defparam i3_4_lut_adj_425.init = 16'hffdf;
    LUT4 i10776_2_lut (.A(n11240), .B(n12292), .Z(Clk_enable_548)) /* synthesis lut_function=(!((B)+!A)) */ ;
    defparam i10776_2_lut.init = 16'h2222;
    LUT4 i10774_4_lut (.A(n10790), .B(n11700), .C(n11757), .D(H[4]), 
         .Z(n11240)) /* synthesis lut_function=(A (B)+!A (B+!(C+(D)))) */ ;
    defparam i10774_4_lut.init = 16'hcccd;
    FD1P3AX Hn_i0_i1 (.D(H[1]), .SP(Clk_enable_526), .CK(Clk), .Q(\Hn[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam Hn_i0_i1.GSR = "DISABLED";
    FD1P3AX Hn_i0_i2 (.D(H[2]), .SP(Clk_enable_526), .CK(Clk), .Q(\Hn[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam Hn_i0_i2.GSR = "DISABLED";
    FD1P3AX Hn_i0_i3 (.D(H[3]), .SP(Clk_enable_526), .CK(Clk), .Q(Hn[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam Hn_i0_i3.GSR = "DISABLED";
    FD1P3AX Hn_i0_i4 (.D(H[4]), .SP(Clk_enable_526), .CK(Clk), .Q(Hn[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam Hn_i0_i4.GSR = "DISABLED";
    FD1P3AX Hn_i0_i5 (.D(H[5]), .SP(Clk_enable_526), .CK(Clk), .Q(Hn[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=242, LSE_RLINE=283 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam Hn_i0_i5.GSR = "DISABLED";
    LUT4 n11628_bdd_2_lut_4_lut (.A(n11716), .B(n11755), .C(n11839), .D(n11628), 
         .Z(n11629)) /* synthesis lut_function=(A (((D)+!C)+!B)+!A (B (D)+!B (C+(D)))) */ ;
    defparam n11628_bdd_2_lut_4_lut.init = 16'hff3a;
    LUT4 i10627_4_lut (.A(H_LINE23_N_471), .B(n5), .C(n11839), .D(ODDEVEN[0]), 
         .Z(HC_N_231)) /* synthesis lut_function=(A (((D)+!C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(825[23:88])
    defparam i10627_4_lut.init = 16'haa2a;
    LUT4 i1_2_lut (.A(H_LINE5_N_446), .B(RESCL), .Z(n5)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(825[39:76])
    defparam i1_2_lut.init = 16'h8888;
    LUT4 i10596_4_lut (.A(H[2]), .B(n11714), .C(n7645), .D(n6_adj_1646), 
         .Z(H_LINE5_N_446)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(751[19:101])
    defparam i10596_4_lut.init = 16'h0010;
    LUT4 i2_4_lut (.A(Vo[2]), .B(n4_adj_43), .C(n8), .D(n11789), .Z(VSET_0__N_224)) /* synthesis lut_function=(A (B)+!A (B+!((D)+!C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(858[22:52])
    defparam i2_4_lut.init = 16'hccdc;
    LUT4 i3_4_lut_adj_426 (.A(n4312), .B(Vo[5]), .C(DENDY_IN_c), .D(Vo[1]), 
         .Z(n8)) /* synthesis lut_function=(!(A+((C+!(D))+!B))) */ ;
    defparam i3_4_lut_adj_426.init = 16'h0400;
    LUT4 i2_4_lut_adj_427 (.A(n7714), .B(Vo[3]), .C(Vo[5]), .D(Vo[4]), 
         .Z(V_LINE0N_N_480)) /* synthesis lut_function=((B+!(C (D)))+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(771[22:51])
    defparam i2_4_lut_adj_427.init = 16'hdfff;
    LUT4 i7228_2_lut (.A(Vo[7]), .B(Vo[6]), .Z(n7714)) /* synthesis lut_function=(A (B)) */ ;
    defparam i7228_2_lut.init = 16'h8888;
    LUT4 i6_4_lut (.A(H[4]), .B(n12), .C(H[2]), .D(H[6]), .Z(H_LINE23_N_471)) /* synthesis lut_function=((B+!(C (D)))+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(759[20:93])
    defparam i6_4_lut.init = 16'hdfff;
    LUT4 i5_4_lut (.A(H[0]), .B(H[1]), .C(n11820), .D(n11819), .Z(n12)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(759[20:93])
    defparam i5_4_lut.init = 16'hfffe;
    LUT4 i7159_2_lut (.A(H[4]), .B(H[0]), .Z(n7645)) /* synthesis lut_function=(A (B)) */ ;
    defparam i7159_2_lut.init = 16'h8888;
    LUT4 i10779_3_lut_3_lut (.A(n11700), .B(n12292), .C(N_HB_N_293), .Z(Clk_enable_547)) /* synthesis lut_function=(!(A (B)+!A (B+(C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(748[19:93])
    defparam i10779_3_lut_3_lut.init = 16'h2323;
    LUT4 i4_4_lut (.A(H[2]), .B(H[3]), .C(H[0]), .D(n6_adj_1648), .Z(HIN5)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(737[15:47])
    defparam i4_4_lut.init = 16'h8000;
    LUT4 i1_2_lut_adj_428 (.A(H[4]), .B(H[1]), .Z(n6_adj_1648)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(737[15:47])
    defparam i1_2_lut_adj_428.init = 16'h8888;
    PFUMX i25 (.BLUT(n6_adj_1645), .ALUT(n11), .C0(Vo[5]), .Z(n14));
    LUT4 nRES_I_0_1_lut (.A(nRES_c), .Z(nRES_N_8)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(489[54:59])
    defparam nRES_I_0_1_lut.init = 16'h5555;
    LUT4 i1_2_lut_adj_429 (.A(H[5]), .B(HIN5), .Z(n10701)) /* synthesis lut_function=(A (B)) */ ;
    defparam i1_2_lut_adj_429.init = 16'h8888;
    FD1P3AX VB_FF_684 (.D(n11717), .SP(Clk_enable_543), .CK(Clk), .Q(VB_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam VB_FF_684.GSR = "DISABLED";
    FD1P3AX BLNK_FF_683 (.D(n11716), .SP(Clk_enable_544), .CK(Clk), .Q(BLNK_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam BLNK_FF_683.GSR = "DISABLED";
    FD1P3AX PEN_FF_682 (.D(n11703), .SP(Clk_enable_545), .CK(Clk), .Q(PEN_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam PEN_FF_682.GSR = "DISABLED";
    FD1P3AX BPORCH_FF_681 (.D(BPORCH_FF_N_413), .SP(Clk_enable_546), .CK(Clk), 
            .Q(BPORCH_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam BPORCH_FF_681.GSR = "DISABLED";
    FD1P3AX N_HB_680 (.D(n11700), .SP(Clk_enable_547), .CK(Clk), .Q(N_HB));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam N_HB_680.GSR = "DISABLED";
    FD1P3AX FPORCH_FF_678 (.D(n11700), .SP(Clk_enable_548), .CK(Clk), 
            .Q(FPORCH_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam FPORCH_FF_678.GSR = "DISABLED";
    FD1P3AX R2DB7_639 (.D(INT_FF), .SP(Clk_enable_553), .CK(Clk), .Q(\R2DB[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam R2DB7_639.GSR = "DISABLED";
    FD1P3AX VSYNC_FF_636 (.D(VSYNCo_N_320), .SP(Clk_enable_565), .CK(Clk), 
            .Q(VSYNCo));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(789[8] 861[26])
    defparam VSYNC_FF_636.GSR = "DISABLED";
    LUT4 i10592_4_lut (.A(H[7]), .B(n11749), .C(H[6]), .D(H[0]), .Z(n11058)) /* synthesis lut_function=(!(A+!(B (C (D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(750[19:101])
    defparam i10592_4_lut.init = 16'h4000;
    LUT4 i10600_4_lut (.A(n11800), .B(H[6]), .C(H[7]), .D(n10701), .Z(H_LINE7_N_461)) /* synthesis lut_function=(!(A+!(B (C (D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(753[19:93])
    defparam i10600_4_lut.init = 16'h4000;
    COUNTER_U63 Vo_7__I_0_736 (.Clk(Clk), .Clk_enable_530(Clk_enable_530), 
            .CNT1_N_558({CNT1_N_558_adj_1663}), .\Vo[7] (Vo[7]), .Clk_enable_564(Clk_enable_564), 
            .Vo_7__N_205(Vo_7__N_205)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(742[9:127])
    COUNTER_U64 VCNT_8 (.Clk(Clk), .Clk_enable_530(Clk_enable_530), .CNT1_N_558({CNT1_N_558_adj_1664}), 
            .\V[8] (V[8]), .Clk_enable_564(Clk_enable_564), .Vo_7__N_205(Vo_7__N_205)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(742[9:127])
    COUNTER_U65 VCNT_6 (.Clk(Clk), .Clk_enable_530(Clk_enable_530), .CNT1_N_558({CNT1_N_558_adj_1665}), 
            .\Vo[6] (Vo[6]), .Clk_enable_564(Clk_enable_564), .Vo_7__N_205(Vo_7__N_205), 
            .n11693(n11693), .\Vo[7] (Vo[7]), .\V[8] (V[8]), .CNT1_N_558_adj_42({CNT1_N_558_adj_1664})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(742[9:127])
    COUNTER_U66 VCNT_5 (.\Vo[5] (Vo[5]), .n11695(n11695), .\Vo[7] (Vo[7]), 
            .\Vo[6] (Vo[6]), .CNT1_N_558({CNT1_N_558_adj_1663}), .Clk(Clk), 
            .Clk_enable_530(Clk_enable_530), .CNT1_N_558_adj_40({CNT1_N_558_adj_1666}), 
            .Clk_enable_564(Clk_enable_564), .Vo_7__N_205(Vo_7__N_205)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(742[9:127])
    COUNTER_U67 VCNT_4 (.Clk(Clk), .Clk_enable_530(Clk_enable_530), .CNT1_N_558({CNT1_N_558_adj_1667}), 
            .\Vo[4] (Vo[4]), .Clk_enable_367(Clk_enable_367), .Vo_7__N_205(Vo_7__N_205), 
            .n11696(n11696), .\Vo[6] (Vo[6]), .\Vo[5] (Vo[5]), .CNT1_N_558_adj_38({CNT1_N_558_adj_1665})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(742[9:127])
    COUNTER_U68 VCNT_3 (.Clk(Clk), .Clk_enable_530(Clk_enable_530), .CNT1_N_558({CNT1_N_558_adj_1668}), 
            .\Vo[3] (Vo[3]), .Clk_enable_367(Clk_enable_367), .Vo_7__N_205(Vo_7__N_205), 
            .n11697(n11697), .\Vo[5] (Vo[5]), .\Vo[4] (Vo[4]), .n11693(n11693), 
            .CNT1_N_558_adj_36({CNT1_N_558_adj_1666})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(742[9:127])
    COUNTER_U69 VCNT_2 (.\Vo[2] (Vo[2]), .n11704(n11704), .\Vo[4] (Vo[4]), 
            .\Vo[3] (Vo[3]), .n11695(n11695), .Clk(Clk), .Clk_enable_530(Clk_enable_530), 
            .CNT1_N_558({CNT1_N_558_adj_1669}), .Clk_enable_367(Clk_enable_367), 
            .Vo_7__N_205(Vo_7__N_205), .CNT1_N_558_adj_34({CNT1_N_558_adj_1667})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(742[9:127])
    COUNTER_U70 VCNT_1 (.Clk(Clk), .Clk_enable_530(Clk_enable_530), .CNT1_N_558({CNT1_N_558_adj_1670}), 
            .\Vo[1] (Vo[1]), .Clk_enable_367(Clk_enable_367), .Vo_7__N_205(Vo_7__N_205), 
            .n11721(n11721), .\Vo[3] (Vo[3]), .\Vo[2] (Vo[2]), .n11696(n11696), 
            .CNT1_N_558_adj_32({CNT1_N_558_adj_1668})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(742[9:127])
    COUNTER_U71 VCNT_0 (.\Vo[0] (Vo[0]), .H_LINE23_N_471(H_LINE23_N_471), 
            .n11721(n11721), .\Vo[1] (Vo[1]), .n11704(n11704), .Clk(Clk), 
            .Clk_enable_549(Clk_enable_549), .Vo_7__N_205(Vo_7__N_205), 
            .CNT1_N_558({CNT1_N_558_adj_1670}), .\Vo[2] (Vo[2]), .n11697(n11697), 
            .CNT1_N_558_adj_30({CNT1_N_558_adj_1669}), .Clk_enable_530(Clk_enable_530)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(742[9:127])
    COUNTER_U72 H_8__I_0_700 (.Clk(Clk), .Clk_enable_185(Clk_enable_185), 
            .CNT1_N_558({CNT1_N_558_adj_1671}), .\H[8] (\H[8] ), .Clk_enable_549(Clk_enable_549), 
            .H_8__N_226(H_8__N_226)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(741[9:127])
    COUNTER_U73 HCNT_7 (.Clk(Clk), .Clk_enable_562(Clk_enable_562), .CNT1_N_558({CNT1_N_558_adj_1672}), 
            .\H[7] (H[7]), .Clk_enable_549(Clk_enable_549), .H_8__N_226(H_8__N_226)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(741[9:127])
    COUNTER_U74 HCNT_6 (.Clk(Clk), .Clk_enable_562(Clk_enable_562), .CNT1_N_558({CNT1_N_558_adj_1673}), 
            .\H[6] (H[6]), .n10701(n10701), .\H[7] (H[7]), .\H[8] (\H[8] ), 
            .CNT1_N_558_adj_28({CNT1_N_558_adj_1671}), .Clk_enable_549(Clk_enable_549), 
            .H_8__N_226(H_8__N_226)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(741[9:127])
    COUNTER_U75 HCNT_5 (.Clk(Clk), .Clk_enable_562(Clk_enable_562), .\H[5] (H[5]), 
            .HIN5(HIN5), .\H[7] (H[7]), .\H[6] (H[6]), .CNT1_N_558({CNT1_N_558_adj_1672}), 
            .CNT1_N_558_adj_26({CNT1_N_558_adj_1673}), .Clk_enable_549(Clk_enable_549), 
            .H_8__N_226(H_8__N_226)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(741[9:127])
    COUNTER_U76 HCNT_4 (.Clk(Clk), .Clk_enable_562(Clk_enable_562), .CNT1_N_558({CNT1_N_558_adj_1674}), 
            .\H[4] (H[4]), .Clk_enable_549(Clk_enable_549), .H_8__N_226(H_8__N_226)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(741[9:127])
    COUNTER_U77 HCNT_3 (.Clk(Clk), .Clk_enable_530(Clk_enable_530), .CNT1_N_558({CNT1_N_558_adj_1675}), 
            .\H[3] (H[3]), .Clk_enable_564(Clk_enable_564), .H_8__N_226(H_8__N_226)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(741[9:127])
    COUNTER_U78 HCNT_2 (.\H[2] (H[2]), .n11809(n11809), .\H[3] (H[3]), 
            .\H[4] (H[4]), .CNT1_N_558({CNT1_N_558_adj_1674}), .Clk(Clk), 
            .Clk_enable_530(Clk_enable_530), .CNT1_N_558_adj_24({CNT1_N_558_adj_1676}), 
            .Clk_enable_549(Clk_enable_549), .H_8__N_226(H_8__N_226)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(741[9:127])
    COUNTER_U79 HCNT_1 (.\H[1] (H[1]), .\H[0] (H[0]), .n11809(n11809), 
            .\H[3] (H[3]), .\H[2] (H[2]), .CNT1_N_558({CNT1_N_558_adj_1675}), 
            .CNT1_N_558_adj_22({CNT1_N_558_adj_1676}), .Clk(Clk), .Clk_enable_530(Clk_enable_530), 
            .Clk_enable_549(Clk_enable_549), .H_8__N_226(H_8__N_226)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(741[9:127])
    COUNTER_U80 HCNT_0 (.Clk(Clk), .Clk_enable_530(Clk_enable_530), .\H[0] (H[0]), 
            .Clk_enable_513(Clk_enable_513), .H_8__N_226(H_8__N_226)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(741[9:127])
    
endmodule
//
// Verilog Description of module COUNTER_U63
//

module COUNTER_U63 (Clk, Clk_enable_530, CNT1_N_558, \Vo[7] , Clk_enable_564, 
            Vo_7__N_205) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_530;
    input [0:0]CNT1_N_558;
    output \Vo[7] ;
    input Clk_enable_564;
    input Vo_7__N_205;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_564), .CD(Vo_7__N_205), .CK(Clk), 
            .Q(\Vo[7] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U64
//

module COUNTER_U64 (Clk, Clk_enable_530, CNT1_N_558, \V[8] , Clk_enable_564, 
            Vo_7__N_205) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_530;
    input [0:0]CNT1_N_558;
    output \V[8] ;
    input Clk_enable_564;
    input Vo_7__N_205;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_564), .CD(Vo_7__N_205), .CK(Clk), 
            .Q(\V[8] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U65
//

module COUNTER_U65 (Clk, Clk_enable_530, CNT1_N_558, \Vo[6] , Clk_enable_564, 
            Vo_7__N_205, n11693, \Vo[7] , \V[8] , CNT1_N_558_adj_42) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_530;
    input [0:0]CNT1_N_558;
    output \Vo[6] ;
    input Clk_enable_564;
    input Vo_7__N_205;
    input n11693;
    input \Vo[7] ;
    input \V[8] ;
    output [0:0]CNT1_N_558_adj_42;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_564), .CD(Vo_7__N_205), .CK(Clk), 
            .Q(\Vo[6] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 i1702_3_lut_4_lut (.A(\Vo[6] ), .B(n11693), .C(\Vo[7] ), .D(\V[8] ), 
         .Z(CNT1_N_558_adj_42[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1702_3_lut_4_lut.init = 16'h7f80;
    
endmodule
//
// Verilog Description of module COUNTER_U66
//

module COUNTER_U66 (\Vo[5] , n11695, \Vo[7] , \Vo[6] , CNT1_N_558, 
            Clk, Clk_enable_530, CNT1_N_558_adj_40, Clk_enable_564, 
            Vo_7__N_205) /* synthesis syn_module_defined=1 */ ;
    output \Vo[5] ;
    input n11695;
    input \Vo[7] ;
    input \Vo[6] ;
    output [0:0]CNT1_N_558;
    input Clk;
    input Clk_enable_530;
    input [0:0]CNT1_N_558_adj_40;
    input Clk_enable_564;
    input Vo_7__N_205;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    LUT4 i1709_2_lut_3_lut_4_lut (.A(\Vo[5] ), .B(n11695), .C(\Vo[7] ), 
         .D(\Vo[6] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1709_2_lut_3_lut_4_lut.init = 16'h78f0;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_40[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_564), .CD(Vo_7__N_205), .CK(Clk), 
            .Q(\Vo[5] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U67
//

module COUNTER_U67 (Clk, Clk_enable_530, CNT1_N_558, \Vo[4] , Clk_enable_367, 
            Vo_7__N_205, n11696, \Vo[6] , \Vo[5] , CNT1_N_558_adj_38) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_530;
    input [0:0]CNT1_N_558;
    output \Vo[4] ;
    input Clk_enable_367;
    input Vo_7__N_205;
    input n11696;
    input \Vo[6] ;
    input \Vo[5] ;
    output [0:0]CNT1_N_558_adj_38;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_367), .CD(Vo_7__N_205), .CK(Clk), 
            .Q(\Vo[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 i1716_2_lut_3_lut_4_lut (.A(\Vo[4] ), .B(n11696), .C(\Vo[6] ), 
         .D(\Vo[5] ), .Z(CNT1_N_558_adj_38[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1716_2_lut_3_lut_4_lut.init = 16'h78f0;
    
endmodule
//
// Verilog Description of module COUNTER_U68
//

module COUNTER_U68 (Clk, Clk_enable_530, CNT1_N_558, \Vo[3] , Clk_enable_367, 
            Vo_7__N_205, n11697, \Vo[5] , \Vo[4] , n11693, CNT1_N_558_adj_36) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_530;
    input [0:0]CNT1_N_558;
    output \Vo[3] ;
    input Clk_enable_367;
    input Vo_7__N_205;
    input n11697;
    input \Vo[5] ;
    input \Vo[4] ;
    output n11693;
    output [0:0]CNT1_N_558_adj_36;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_367), .CD(Vo_7__N_205), .CK(Clk), 
            .Q(\Vo[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 CNT_I_0_2_lut_rep_217_3_lut_4_lut (.A(\Vo[3] ), .B(n11697), .C(\Vo[5] ), 
         .D(\Vo[4] ), .Z(n11693)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam CNT_I_0_2_lut_rep_217_3_lut_4_lut.init = 16'h8000;
    LUT4 i1723_2_lut_3_lut_4_lut (.A(\Vo[3] ), .B(n11697), .C(\Vo[5] ), 
         .D(\Vo[4] ), .Z(CNT1_N_558_adj_36[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1723_2_lut_3_lut_4_lut.init = 16'h78f0;
    
endmodule
//
// Verilog Description of module COUNTER_U69
//

module COUNTER_U69 (\Vo[2] , n11704, \Vo[4] , \Vo[3] , n11695, Clk, 
            Clk_enable_530, CNT1_N_558, Clk_enable_367, Vo_7__N_205, 
            CNT1_N_558_adj_34) /* synthesis syn_module_defined=1 */ ;
    output \Vo[2] ;
    input n11704;
    input \Vo[4] ;
    input \Vo[3] ;
    output n11695;
    input Clk;
    input Clk_enable_530;
    input [0:0]CNT1_N_558;
    input Clk_enable_367;
    input Vo_7__N_205;
    output [0:0]CNT1_N_558_adj_34;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    LUT4 CNT_I_0_2_lut_rep_219_3_lut_4_lut (.A(\Vo[2] ), .B(n11704), .C(\Vo[4] ), 
         .D(\Vo[3] ), .Z(n11695)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam CNT_I_0_2_lut_rep_219_3_lut_4_lut.init = 16'h8000;
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_367), .CD(Vo_7__N_205), .CK(Clk), 
            .Q(\Vo[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 i1730_2_lut_3_lut_4_lut (.A(\Vo[2] ), .B(n11704), .C(\Vo[4] ), 
         .D(\Vo[3] ), .Z(CNT1_N_558_adj_34[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1730_2_lut_3_lut_4_lut.init = 16'h78f0;
    
endmodule
//
// Verilog Description of module COUNTER_U70
//

module COUNTER_U70 (Clk, Clk_enable_530, CNT1_N_558, \Vo[1] , Clk_enable_367, 
            Vo_7__N_205, n11721, \Vo[3] , \Vo[2] , n11696, CNT1_N_558_adj_32) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_530;
    input [0:0]CNT1_N_558;
    output \Vo[1] ;
    input Clk_enable_367;
    input Vo_7__N_205;
    input n11721;
    input \Vo[3] ;
    input \Vo[2] ;
    output n11696;
    output [0:0]CNT1_N_558_adj_32;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_367), .CD(Vo_7__N_205), .CK(Clk), 
            .Q(\Vo[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 CNT_I_0_2_lut_rep_220_3_lut_4_lut (.A(\Vo[1] ), .B(n11721), .C(\Vo[3] ), 
         .D(\Vo[2] ), .Z(n11696)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam CNT_I_0_2_lut_rep_220_3_lut_4_lut.init = 16'h8000;
    LUT4 i1737_2_lut_3_lut_4_lut (.A(\Vo[1] ), .B(n11721), .C(\Vo[3] ), 
         .D(\Vo[2] ), .Z(CNT1_N_558_adj_32[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1737_2_lut_3_lut_4_lut.init = 16'h78f0;
    
endmodule
//
// Verilog Description of module COUNTER_U71
//

module COUNTER_U71 (\Vo[0] , H_LINE23_N_471, n11721, \Vo[1] , n11704, 
            Clk, Clk_enable_549, Vo_7__N_205, CNT1_N_558, \Vo[2] , 
            n11697, CNT1_N_558_adj_30, Clk_enable_530) /* synthesis syn_module_defined=1 */ ;
    output \Vo[0] ;
    input H_LINE23_N_471;
    output n11721;
    input \Vo[1] ;
    output n11704;
    input Clk;
    input Clk_enable_549;
    input Vo_7__N_205;
    output [0:0]CNT1_N_558;
    input \Vo[2] ;
    output n11697;
    output [0:0]CNT1_N_558_adj_30;
    input Clk_enable_530;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    wire [0:0]CNT1_N_558_adj_1632;
    
    LUT4 CNT_I_0_2_lut_rep_245 (.A(\Vo[0] ), .B(H_LINE23_N_471), .Z(n11721)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam CNT_I_0_2_lut_rep_245.init = 16'h2222;
    LUT4 CNT_I_0_2_lut_rep_228_3_lut (.A(\Vo[0] ), .B(H_LINE23_N_471), .C(\Vo[1] ), 
         .Z(n11704)) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam CNT_I_0_2_lut_rep_228_3_lut.init = 16'h2020;
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_549), .CD(Vo_7__N_205), .CK(Clk), 
            .Q(\Vo[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 i1751_2_lut_3_lut (.A(\Vo[0] ), .B(H_LINE23_N_471), .C(\Vo[1] ), 
         .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (B (C)+!B !(C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1751_2_lut_3_lut.init = 16'hd2d2;
    LUT4 CNT_I_0_2_lut_rep_221_3_lut_4_lut (.A(\Vo[0] ), .B(H_LINE23_N_471), 
         .C(\Vo[2] ), .D(\Vo[1] ), .Z(n11697)) /* synthesis lut_function=(!((B+!(C (D)))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam CNT_I_0_2_lut_rep_221_3_lut_4_lut.init = 16'h2000;
    LUT4 i1744_2_lut_3_lut_4_lut (.A(\Vo[0] ), .B(H_LINE23_N_471), .C(\Vo[2] ), 
         .D(\Vo[1] ), .Z(CNT1_N_558_adj_30[0])) /* synthesis lut_function=(A (B (C)+!B !(C (D)+!C !(D)))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1744_2_lut_3_lut_4_lut.init = 16'hd2f0;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_1632[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\Vo[0] ), .B(H_LINE23_N_471), .Z(CNT1_N_558_adj_1632[0])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U72
//

module COUNTER_U72 (Clk, Clk_enable_185, CNT1_N_558, \H[8] , Clk_enable_549, 
            H_8__N_226) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_185;
    input [0:0]CNT1_N_558;
    output \H[8] ;
    input Clk_enable_549;
    input H_8__N_226;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_549), .CD(H_8__N_226), .CK(Clk), 
            .Q(\H[8] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U73
//

module COUNTER_U73 (Clk, Clk_enable_562, CNT1_N_558, \H[7] , Clk_enable_549, 
            H_8__N_226) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_562;
    input [0:0]CNT1_N_558;
    output \H[7] ;
    input Clk_enable_549;
    input H_8__N_226;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_549), .CD(H_8__N_226), .CK(Clk), 
            .Q(\H[7] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U74
//

module COUNTER_U74 (Clk, Clk_enable_562, CNT1_N_558, \H[6] , n10701, 
            \H[7] , \H[8] , CNT1_N_558_adj_28, Clk_enable_549, H_8__N_226) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_562;
    input [0:0]CNT1_N_558;
    output \H[6] ;
    input n10701;
    input \H[7] ;
    input \H[8] ;
    output [0:0]CNT1_N_558_adj_28;
    input Clk_enable_549;
    input H_8__N_226;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1638_3_lut_4_lut (.A(\H[6] ), .B(n10701), .C(\H[7] ), .D(\H[8] ), 
         .Z(CNT1_N_558_adj_28[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1638_3_lut_4_lut.init = 16'h7f80;
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_549), .CD(H_8__N_226), .CK(Clk), 
            .Q(\H[6] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U75
//

module COUNTER_U75 (Clk, Clk_enable_562, \H[5] , HIN5, \H[7] , \H[6] , 
            CNT1_N_558, CNT1_N_558_adj_26, Clk_enable_549, H_8__N_226) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_562;
    output \H[5] ;
    input HIN5;
    input \H[7] ;
    input \H[6] ;
    output [0:0]CNT1_N_558;
    output [0:0]CNT1_N_558_adj_26;
    input Clk_enable_549;
    input H_8__N_226;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    wire [0:0]CNT1_N_558_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558_c[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1659_2_lut (.A(\H[5] ), .B(HIN5), .Z(CNT1_N_558_c[0])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1663[26:36])
    defparam i1659_2_lut.init = 16'h6666;
    LUT4 i1645_2_lut_3_lut_4_lut (.A(\H[5] ), .B(HIN5), .C(\H[7] ), .D(\H[6] ), 
         .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1645_2_lut_3_lut_4_lut.init = 16'h78f0;
    LUT4 i1652_2_lut_3_lut (.A(\H[5] ), .B(HIN5), .C(\H[6] ), .Z(CNT1_N_558_adj_26[0])) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1652_2_lut_3_lut.init = 16'h7878;
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_549), .CD(H_8__N_226), .CK(Clk), 
            .Q(\H[5] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U76
//

module COUNTER_U76 (Clk, Clk_enable_562, CNT1_N_558, \H[4] , Clk_enable_549, 
            H_8__N_226) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_562;
    input [0:0]CNT1_N_558;
    output \H[4] ;
    input Clk_enable_549;
    input H_8__N_226;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_549), .CD(H_8__N_226), .CK(Clk), 
            .Q(\H[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U77
//

module COUNTER_U77 (Clk, Clk_enable_530, CNT1_N_558, \H[3] , Clk_enable_564, 
            H_8__N_226) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_530;
    input [0:0]CNT1_N_558;
    output \H[3] ;
    input Clk_enable_564;
    input H_8__N_226;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_564), .CD(H_8__N_226), .CK(Clk), 
            .Q(\H[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U78
//

module COUNTER_U78 (\H[2] , n11809, \H[3] , \H[4] , CNT1_N_558, Clk, 
            Clk_enable_530, CNT1_N_558_adj_24, Clk_enable_549, H_8__N_226) /* synthesis syn_module_defined=1 */ ;
    output \H[2] ;
    input n11809;
    input \H[3] ;
    input \H[4] ;
    output [0:0]CNT1_N_558;
    input Clk;
    input Clk_enable_530;
    input [0:0]CNT1_N_558_adj_24;
    input Clk_enable_549;
    input H_8__N_226;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    LUT4 i1666_3_lut_4_lut (.A(\H[2] ), .B(n11809), .C(\H[3] ), .D(\H[4] ), 
         .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1666_3_lut_4_lut.init = 16'h7f80;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_24[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_549), .CD(H_8__N_226), .CK(Clk), 
            .Q(\H[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U79
//

module COUNTER_U79 (\H[1] , \H[0] , n11809, \H[3] , \H[2] , CNT1_N_558, 
            CNT1_N_558_adj_22, Clk, Clk_enable_530, Clk_enable_549, 
            H_8__N_226) /* synthesis syn_module_defined=1 */ ;
    output \H[1] ;
    input \H[0] ;
    output n11809;
    input \H[3] ;
    input \H[2] ;
    output [0:0]CNT1_N_558;
    output [0:0]CNT1_N_558_adj_22;
    input Clk;
    input Clk_enable_530;
    input Clk_enable_549;
    input H_8__N_226;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    wire [0:0]CNT1_N_558_adj_1620;
    
    LUT4 CNT_I_0_2_lut_rep_333 (.A(\H[1] ), .B(\H[0] ), .Z(n11809)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam CNT_I_0_2_lut_rep_333.init = 16'h8888;
    LUT4 i1673_2_lut_3_lut_4_lut (.A(\H[1] ), .B(\H[0] ), .C(\H[3] ), 
         .D(\H[2] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1673_2_lut_3_lut_4_lut.init = 16'h78f0;
    LUT4 i1680_2_lut_3_lut (.A(\H[1] ), .B(\H[0] ), .C(\H[2] ), .Z(CNT1_N_558_adj_22[0])) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1680_2_lut_3_lut.init = 16'h7878;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_1620[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1687_2_lut (.A(\H[1] ), .B(\H[0] ), .Z(CNT1_N_558_adj_1620[0])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1663[26:36])
    defparam i1687_2_lut.init = 16'h6666;
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_549), .CD(H_8__N_226), .CK(Clk), 
            .Q(\H[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U80
//

module COUNTER_U80 (Clk, Clk_enable_530, \H[0] , Clk_enable_513, H_8__N_226) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_530;
    output \H[0] ;
    input Clk_enable_513;
    input H_8__N_226;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1, H_0__N_397;
    
    FD1P3AX CNT1_15 (.D(H_0__N_397), .SP(Clk_enable_530), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_513), .CD(H_8__N_226), .CK(Clk), 
            .Q(\H[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 H_0__I_0_1_lut (.A(\H[0] ), .Z(H_0__N_397)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(751[94:99])
    defparam H_0__I_0_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module OBJ_EVAL
//

module OBJ_EVAL (Clk, Clk_enable_562, OVZ, Clk_enable_120, n11694, 
            SPR0_EV1, SPR0_EV1_N_977, SPR0_EV, n2939, Clk_enable_564, 
            Clk_enable_549, Clk_enable_185, TAL_LATCH_N_883, Vo, OB_R, 
            GND_net, OV, n12292, n4185, O8_16, PD_FIFO, Clk_enable_563, 
            n11800, n7695) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_562;
    output OVZ;
    input Clk_enable_120;
    input n11694;
    output SPR0_EV1;
    input SPR0_EV1_N_977;
    output SPR0_EV;
    input n2939;
    input Clk_enable_564;
    input Clk_enable_549;
    input Clk_enable_185;
    input TAL_LATCH_N_883;
    input [7:0]Vo;
    input [7:0]OB_R;
    input GND_net;
    output [3:0]OV;
    input n12292;
    output n4185;
    input O8_16;
    output PD_FIFO;
    input Clk_enable_563;
    input n11800;
    output n7695;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [1:0]PDFIFO;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1185[10:16])
    wire [5:0]CLATCH;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1183[10:16])
    
    wire n10149;
    wire [7:0]OVS;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1188[11:14])
    
    wire n10148, n10147, n10146, PD_FIFO_N_972, PDFIFO_0__N_971, OVZ_N_984, 
        n10, n8;
    
    FD1P3AX PDFIFO_i0_i0 (.D(OVZ), .SP(Clk_enable_562), .CK(Clk), .Q(PDFIFO[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=365, LSE_RLINE=383 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1197[8] 1207[27])
    defparam PDFIFO_i0_i0.GSR = "DISABLED";
    FD1P3AX CLATCH_i0 (.D(n11694), .SP(Clk_enable_120), .CK(Clk), .Q(CLATCH[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=365, LSE_RLINE=383 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1197[8] 1207[27])
    defparam CLATCH_i0.GSR = "DISABLED";
    FD1P3AX SPR0_EV1_57 (.D(n11694), .SP(SPR0_EV1_N_977), .CK(Clk), .Q(SPR0_EV1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1197[8] 1207[27])
    defparam SPR0_EV1_57.GSR = "DISABLED";
    FD1S3AX SPR0_EV_58 (.D(n2939), .CK(Clk), .Q(SPR0_EV));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1197[8] 1207[27])
    defparam SPR0_EV_58.GSR = "DISABLED";
    FD1P3AX CLATCH_i5 (.D(CLATCH[4]), .SP(Clk_enable_564), .CK(Clk), .Q(CLATCH[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=365, LSE_RLINE=383 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1197[8] 1207[27])
    defparam CLATCH_i5.GSR = "DISABLED";
    FD1P3AX CLATCH_i4 (.D(CLATCH[3]), .SP(Clk_enable_120), .CK(Clk), .Q(CLATCH[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=365, LSE_RLINE=383 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1197[8] 1207[27])
    defparam CLATCH_i4.GSR = "DISABLED";
    FD1P3AX CLATCH_i3 (.D(CLATCH[2]), .SP(Clk_enable_549), .CK(Clk), .Q(CLATCH[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=365, LSE_RLINE=383 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1197[8] 1207[27])
    defparam CLATCH_i3.GSR = "DISABLED";
    FD1P3AX CLATCH_i2 (.D(CLATCH[1]), .SP(Clk_enable_120), .CK(Clk), .Q(CLATCH[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=365, LSE_RLINE=383 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1197[8] 1207[27])
    defparam CLATCH_i2.GSR = "DISABLED";
    FD1P3AX CLATCH_i1 (.D(CLATCH[0]), .SP(Clk_enable_549), .CK(Clk), .Q(CLATCH[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=365, LSE_RLINE=383 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1197[8] 1207[27])
    defparam CLATCH_i1.GSR = "DISABLED";
    FD1P3AX PDFIFO_i0_i1 (.D(TAL_LATCH_N_883), .SP(Clk_enable_185), .CK(Clk), 
            .Q(PDFIFO[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=365, LSE_RLINE=383 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1197[8] 1207[27])
    defparam PDFIFO_i0_i1.GSR = "DISABLED";
    CCU2D V_7__I_0_add_2_9 (.A0(Vo[7]), .B0(OB_R[7]), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n10149), 
          .S0(OVS[7]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1189[19:40])
    defparam V_7__I_0_add_2_9.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_9.INIT1 = 16'h0000;
    defparam V_7__I_0_add_2_9.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_9.INJECT1_1 = "NO";
    CCU2D V_7__I_0_add_2_7 (.A0(Vo[5]), .B0(OB_R[5]), .C0(GND_net), .D0(GND_net), 
          .A1(Vo[6]), .B1(OB_R[6]), .C1(GND_net), .D1(GND_net), .CIN(n10148), 
          .COUT(n10149), .S0(OVS[5]), .S1(OVS[6]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1189[19:40])
    defparam V_7__I_0_add_2_7.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_7.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_7.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_7.INJECT1_1 = "NO";
    CCU2D V_7__I_0_add_2_5 (.A0(Vo[3]), .B0(OB_R[3]), .C0(GND_net), .D0(GND_net), 
          .A1(Vo[4]), .B1(OB_R[4]), .C1(GND_net), .D1(GND_net), .CIN(n10147), 
          .COUT(n10148), .S0(OV[3]), .S1(OVS[4]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1189[19:40])
    defparam V_7__I_0_add_2_5.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_5.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_5.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_5.INJECT1_1 = "NO";
    CCU2D V_7__I_0_add_2_3 (.A0(Vo[1]), .B0(OB_R[1]), .C0(GND_net), .D0(GND_net), 
          .A1(Vo[2]), .B1(OB_R[2]), .C1(GND_net), .D1(GND_net), .CIN(n10146), 
          .COUT(n10147), .S0(OV[1]), .S1(OV[2]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1189[19:40])
    defparam V_7__I_0_add_2_3.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_3.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_3.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_3.INJECT1_1 = "NO";
    CCU2D V_7__I_0_add_2_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(Vo[0]), .B1(OB_R[0]), .C1(GND_net), .D1(GND_net), 
          .COUT(n10146), .S1(OV[0]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1189[19:40])
    defparam V_7__I_0_add_2_1.INIT0 = 16'h0000;
    defparam V_7__I_0_add_2_1.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_1.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_1.INJECT1_1 = "NO";
    LUT4 i10697_2_lut (.A(n12292), .B(PDFIFO[1]), .Z(PD_FIFO_N_972)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1203[15:36])
    defparam i10697_2_lut.init = 16'h2222;
    LUT4 PDFIFO_0__I_0_1_lut (.A(PDFIFO[0]), .Z(PDFIFO_0__N_971)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1203[49:59])
    defparam PDFIFO_0__I_0_1_lut.init = 16'h5555;
    LUT4 i2_3_lut (.A(CLATCH[1]), .B(CLATCH[3]), .C(CLATCH[5]), .Z(n4185)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1194[18:51])
    defparam i2_3_lut.init = 16'hfefe;
    LUT4 i1_4_lut (.A(n4185), .B(OVZ_N_984), .C(n10), .D(OVS[5]), .Z(OVZ)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1194[18:51])
    defparam i1_4_lut.init = 16'hfffe;
    LUT4 OVZ_I_281_2_lut (.A(O8_16), .B(OV[3]), .Z(OVZ_N_984)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1191[94:113])
    defparam OVZ_I_281_2_lut.init = 16'h4444;
    LUT4 i4_4_lut (.A(OVS[7]), .B(n8), .C(OB_R[7]), .D(Vo[7]), .Z(n10)) /* synthesis lut_function=(A+(B+!((D)+!C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1194[18:51])
    defparam i4_4_lut.init = 16'heefe;
    LUT4 i2_2_lut (.A(OVS[6]), .B(OVS[4]), .Z(n8)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1194[18:51])
    defparam i2_2_lut.init = 16'heeee;
    FD1P3AX PD_FIFO_56 (.D(PDFIFO_0__N_971), .SP(PD_FIFO_N_972), .CK(Clk), 
            .Q(PD_FIFO));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1197[8] 1207[27])
    defparam PD_FIFO_56.GSR = "DISABLED";
    LUT4 i10707_2_lut_2_lut_3_lut_4_lut (.A(n11694), .B(n4185), .C(Clk_enable_563), 
         .D(n11800), .Z(n7695)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1194[18:51])
    defparam i10707_2_lut_2_lut_3_lut_4_lut.init = 16'h0010;
    
endmodule
//
// Verilog Description of module LOCAL_BUS_CONTROL
//

module LOCAL_BUS_CONTROL (n11577, Clk, Clk_enable_564, Clk_enable_83, 
            DB_PARR, n12292, n11797, THSTEP_N_916, E_EV, n11709, 
            n11816, R7, n12276, Clk_enable_549, n11800, W7, PAMUX_7__N_844, 
            DBIN, \PAMUX[7] , \TP[3] , \Hn[1] , \TP[2] , TH_MUX, 
            nWR_c, \PAMUX[6] , \TP[1] , \TP[4] , \TP[0] , n11786, 
            RC, Clk_enable_87, n11748, Clk_enable_513, Clk_enable_423, 
            OMFG_LATCH, OVF_LATCH, n4, XRB_N_599, PA11_c_11, PA12_c_12, 
            PA8_c_8, PA13_c_13, PA9_c_9, PA10_c_10, n11579, n10784, 
            ALE_c) /* synthesis syn_module_defined=1 */ ;
    output n11577;
    input Clk;
    input Clk_enable_564;
    output Clk_enable_83;
    output DB_PARR;
    input n12292;
    input n11797;
    output THSTEP_N_916;
    input E_EV;
    output n11709;
    output n11816;
    input R7;
    input n12276;
    input Clk_enable_549;
    input n11800;
    input W7;
    input [7:0]PAMUX_7__N_844;
    input [7:0]DBIN;
    output \PAMUX[7] ;
    input \TP[3] ;
    input \Hn[1] ;
    input \TP[2] ;
    output TH_MUX;
    output nWR_c;
    output \PAMUX[6] ;
    input \TP[1] ;
    input \TP[4] ;
    input \TP[0] ;
    output n11786;
    input RC;
    output Clk_enable_87;
    output n11748;
    input Clk_enable_513;
    input Clk_enable_423;
    input OMFG_LATCH;
    input OVF_LATCH;
    output n4;
    output XRB_N_599;
    input PA11_c_11;
    input PA12_c_12;
    input PA8_c_8;
    input PA13_c_13;
    input PA9_c_9;
    input PA10_c_10;
    input n11579;
    input n10784;
    output ALE_c;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [4:0]W7Q;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(891[15:18])
    wire [4:0]R7Q;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(891[10:13])
    
    wire R7Q_2__N_568, W7Q_2__N_580, W7_FF, Clk_enable_28, R7_FF, 
        R7Q_3__N_561, BLNK_LATCH, W7Q_3__N_573, W7Q_2__N_576, R7Q_2__N_564, 
        n12;
    
    LUT4 n10784_bdd_4_lut (.A(W7Q[4]), .B(R7Q[2]), .C(W7Q[2]), .D(R7Q[4]), 
         .Z(n11577)) /* synthesis lut_function=(!(A ((D)+!B)+!A !(B (C+!(D))+!B (C)))) */ ;
    defparam n10784_bdd_4_lut.init = 16'h50dc;
    FD1P3AX R7Q_i0 (.D(R7Q_2__N_568), .SP(Clk_enable_564), .CK(Clk), .Q(R7Q[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=286, LSE_RLINE=304 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(903[8] 918[27])
    defparam R7Q_i0.GSR = "DISABLED";
    FD1P3AX W7Q_i0 (.D(W7Q_2__N_580), .SP(Clk_enable_564), .CK(Clk), .Q(W7Q[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=286, LSE_RLINE=304 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(903[8] 918[27])
    defparam W7Q_i0.GSR = "DISABLED";
    LUT4 THSTEP_I_259_3_lut_4_lut (.A(Clk_enable_83), .B(DB_PARR), .C(n12292), 
         .D(n11797), .Z(THSTEP_N_916)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C+!(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(895[17:36])
    defparam THSTEP_I_259_3_lut_4_lut.init = 16'hf0f1;
    LUT4 Z_TV_1__I_245_2_lut_rep_233_3_lut_4_lut (.A(Clk_enable_83), .B(DB_PARR), 
         .C(n12292), .D(E_EV), .Z(n11709)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C+!(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(895[17:36])
    defparam Z_TV_1__I_245_2_lut_rep_233_3_lut_4_lut.init = 16'hf0f1;
    FD1P3AX W7_FF_69 (.D(W7Q[3]), .SP(Clk_enable_28), .CK(Clk), .Q(W7_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(903[8] 918[27])
    defparam W7_FF_69.GSR = "DISABLED";
    FD1P3AX DB_PARR_46 (.D(n11816), .SP(Clk_enable_564), .CK(Clk), .Q(DB_PARR));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1582[8] 1632[26])
    defparam DB_PARR_46.GSR = "DISABLED";
    FD1P3IX R7_FF_68 (.D(n12276), .SP(R7), .CD(R7Q_3__N_561), .CK(Clk), 
            .Q(R7_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(903[8] 918[27])
    defparam R7_FF_68.GSR = "DISABLED";
    LUT4 R7_FF_I_0_84_2_lut (.A(R7_FF), .B(R7), .Z(R7Q_2__N_568)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(911[56:67])
    defparam R7_FF_I_0_84_2_lut.init = 16'h2222;
    FD1P3AX BLNK_LATCH_70 (.D(n11800), .SP(Clk_enable_549), .CK(Clk), 
            .Q(BLNK_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(903[8] 918[27])
    defparam BLNK_LATCH_70.GSR = "DISABLED";
    LUT4 W7_FF_I_0_83_2_lut (.A(W7_FF), .B(W7), .Z(W7Q_2__N_580)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(912[56:67])
    defparam W7_FF_I_0_83_2_lut.init = 16'h2222;
    LUT4 i10684_2_lut_rep_340 (.A(W7Q[3]), .B(W7Q[1]), .Z(n11816)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(897[17:38])
    defparam i10684_2_lut_rep_340.init = 16'h1111;
    LUT4 PAMUX_7__I_0_i8_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(PAMUX_7__N_844[7]), 
         .D(DBIN[7]), .Z(\PAMUX[7] )) /* synthesis lut_function=(A (C)+!A (B (C)+!B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(897[17:38])
    defparam PAMUX_7__I_0_i8_3_lut_4_lut.init = 16'hf1e0;
    LUT4 PAMUX_7__I_243_i5_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(DBIN[4]), 
         .D(\TP[3] ), .Z(PAMUX_7__N_844[4])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(897[17:38])
    defparam PAMUX_7__I_243_i5_3_lut_4_lut.init = 16'hfe10;
    LUT4 PAMUX_7__I_243_i4_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(DBIN[3]), 
         .D(\Hn[1] ), .Z(PAMUX_7__N_844[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(897[17:38])
    defparam PAMUX_7__I_243_i4_3_lut_4_lut.init = 16'hfe10;
    LUT4 PAMUX_7__I_243_i3_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(DBIN[2]), 
         .D(\TP[2] ), .Z(PAMUX_7__N_844[2])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(897[17:38])
    defparam PAMUX_7__I_243_i3_3_lut_4_lut.init = 16'hfe10;
    LUT4 DB_PAR_N_586_I_0_2_lut_2_lut_3_lut (.A(W7Q[3]), .B(W7Q[1]), .C(TH_MUX), 
         .Z(nWR_c)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(897[17:38])
    defparam DB_PAR_N_586_I_0_2_lut_2_lut_3_lut.init = 16'hfefe;
    LUT4 PAMUX_7__I_0_i7_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(PAMUX_7__N_844[6]), 
         .D(DBIN[6]), .Z(\PAMUX[6] )) /* synthesis lut_function=(A (C)+!A (B (C)+!B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(897[17:38])
    defparam PAMUX_7__I_0_i7_3_lut_4_lut.init = 16'hf1e0;
    LUT4 PAMUX_7__I_243_i2_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(DBIN[1]), 
         .D(\TP[1] ), .Z(PAMUX_7__N_844[1])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(897[17:38])
    defparam PAMUX_7__I_243_i2_3_lut_4_lut.init = 16'hfe10;
    LUT4 PAMUX_7__I_243_i6_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(DBIN[5]), 
         .D(\TP[4] ), .Z(PAMUX_7__N_844[5])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(897[17:38])
    defparam PAMUX_7__I_243_i6_3_lut_4_lut.init = 16'hfe10;
    LUT4 PAMUX_7__I_243_i1_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(DBIN[0]), 
         .D(\TP[0] ), .Z(PAMUX_7__N_844[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(897[17:38])
    defparam PAMUX_7__I_243_i1_3_lut_4_lut.init = 16'hfe10;
    LUT4 W7Q_3__I_0_79_1_lut (.A(W7Q[3]), .Z(W7Q_3__N_573)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(912[39:46])
    defparam W7Q_3__I_0_79_1_lut.init = 16'h5555;
    LUT4 W7Q_2__I_0_1_lut (.A(W7Q[2]), .Z(W7Q_2__N_576)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(901[50:57])
    defparam W7Q_2__I_0_1_lut.init = 16'h5555;
    LUT4 R7Q_2__I_0_1_lut (.A(R7Q[2]), .Z(R7Q_2__N_564)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(901[26:33])
    defparam R7Q_2__I_0_1_lut.init = 16'h5555;
    LUT4 i10677_2_lut_rep_349 (.A(R7Q[4]), .B(R7Q[2]), .Z(Clk_enable_83)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(896[17:38])
    defparam i10677_2_lut_rep_349.init = 16'h2222;
    LUT4 i1_2_lut_rep_310_3_lut (.A(R7Q[4]), .B(R7Q[2]), .C(DB_PARR), 
         .Z(n11786)) /* synthesis lut_function=(A ((C)+!B)+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(896[17:38])
    defparam i1_2_lut_rep_310_3_lut.init = 16'hf2f2;
    LUT4 i680_2_lut_3_lut (.A(R7Q[4]), .B(R7Q[2]), .C(RC), .Z(Clk_enable_87)) /* synthesis lut_function=(A ((C)+!B)+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(896[17:38])
    defparam i680_2_lut_3_lut.init = 16'hf2f2;
    LUT4 i1_2_lut_rep_272_3_lut_4_lut (.A(R7Q[4]), .B(R7Q[2]), .C(E_EV), 
         .D(DB_PARR), .Z(n11748)) /* synthesis lut_function=(A ((C+(D))+!B)+!A (C+(D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(896[17:38])
    defparam i1_2_lut_rep_272_3_lut_4_lut.init = 16'hfff2;
    FD1P3AX W7Q_i4 (.D(W7Q_3__N_573), .SP(Clk_enable_513), .CK(Clk), .Q(W7Q[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=286, LSE_RLINE=304 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(903[8] 918[27])
    defparam W7Q_i4.GSR = "DISABLED";
    FD1P3AX W7Q_i3 (.D(W7Q_2__N_576), .SP(Clk_enable_423), .CK(Clk), .Q(W7Q[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=286, LSE_RLINE=304 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(903[8] 918[27])
    defparam W7Q_i3.GSR = "DISABLED";
    FD1P3AX W7Q_i2 (.D(W7Q[1]), .SP(Clk_enable_549), .CK(Clk), .Q(W7Q[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=286, LSE_RLINE=304 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(903[8] 918[27])
    defparam W7Q_i2.GSR = "DISABLED";
    FD1P3AX W7Q_i1 (.D(W7Q[0]), .SP(Clk_enable_423), .CK(Clk), .Q(W7Q[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=286, LSE_RLINE=304 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(903[8] 918[27])
    defparam W7Q_i1.GSR = "DISABLED";
    FD1P3AX R7Q_i4 (.D(R7Q_3__N_561), .SP(Clk_enable_513), .CK(Clk), .Q(R7Q[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=286, LSE_RLINE=304 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(903[8] 918[27])
    defparam R7Q_i4.GSR = "DISABLED";
    FD1P3AX R7Q_i3 (.D(R7Q_2__N_564), .SP(Clk_enable_423), .CK(Clk), .Q(R7Q[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=286, LSE_RLINE=304 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(903[8] 918[27])
    defparam R7Q_i3.GSR = "DISABLED";
    FD1P3AX R7Q_i2 (.D(R7Q[1]), .SP(Clk_enable_549), .CK(Clk), .Q(R7Q[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=286, LSE_RLINE=304 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(903[8] 918[27])
    defparam R7Q_i2.GSR = "DISABLED";
    FD1P3AX R7Q_i1 (.D(R7Q[0]), .SP(Clk_enable_423), .CK(Clk), .Q(R7Q[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=286, LSE_RLINE=304 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(903[8] 918[27])
    defparam R7Q_i1.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(OMFG_LATCH), .B(OVF_LATCH), .Z(n4)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(901[65:76])
    defparam i1_2_lut.init = 16'heeee;
    LUT4 R7Q_3__I_0_1_lut (.A(R7Q[3]), .Z(R7Q_3__N_561)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(911[39:46])
    defparam R7Q_3__I_0_1_lut.init = 16'h5555;
    LUT4 R7_N_570_I_0_2_lut (.A(R7), .B(TH_MUX), .Z(XRB_N_599)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(900[15:31])
    defparam R7_N_570_I_0_2_lut.init = 16'hdddd;
    LUT4 i6_4_lut (.A(PA11_c_11), .B(n12), .C(PA12_c_12), .D(PA8_c_8), 
         .Z(TH_MUX)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(894[17:85])
    defparam i6_4_lut.init = 16'h8000;
    LUT4 i5_4_lut (.A(PA13_c_13), .B(PA9_c_9), .C(PA10_c_10), .D(BLNK_LATCH), 
         .Z(n12)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(894[17:85])
    defparam i5_4_lut.init = 16'h8000;
    PFUMX i10895 (.BLUT(n11579), .ALUT(n11577), .C0(n10784), .Z(ALE_c));
    LUT4 i1_2_lut_adj_408 (.A(W7), .B(W7Q[3]), .Z(Clk_enable_28)) /* synthesis lut_function=(A+!(B)) */ ;
    defparam i1_2_lut_adj_408.init = 16'hbbbb;
    
endmodule
//
// Verilog Description of module REG2000_2001
//

module REG2000_2001 (BGCLIP, Clk, EMP_R, EMP_G, Clk_enable_562, nVIS, 
            CLIP_B_N_240, CLIPOR, n11839, \ri[7] , n7934, I1_32, 
            O8_16, OBSEL, CLIP_OUT, BGSEL, W1, W0, RC, DBIN, 
            n11840, BLNK_FF, n11800, \H[8] , n11753, N_HB, SC_CNT, 
            \Hn[2] , n11762, n11772, n11577, n11579, \FVO[1] , NBFVO1, 
            n11749, n12292, OB2_7__N_1036, nCLPB_N_123, \EMPH[2] , 
            VBL_EN, B_W, n960) /* synthesis syn_module_defined=1 */ ;
    output BGCLIP;
    input Clk;
    output EMP_R;
    output EMP_G;
    input Clk_enable_562;
    input nVIS;
    input CLIP_B_N_240;
    output CLIPOR;
    input n11839;
    input \ri[7] ;
    output n7934;
    output I1_32;
    output O8_16;
    output OBSEL;
    input CLIP_OUT;
    output BGSEL;
    input W1;
    input W0;
    input RC;
    input [7:0]DBIN;
    output n11840;
    input BLNK_FF;
    output n11800;
    input \H[8] ;
    output n11753;
    input N_HB;
    output SC_CNT;
    input \Hn[2] ;
    output n11762;
    output n11772;
    input n11577;
    output n11579;
    input \FVO[1] ;
    output NBFVO1;
    output n11749;
    input n12292;
    output OB2_7__N_1036;
    output nCLPB_N_123;
    output \EMPH[2] ;
    output VBL_EN;
    output B_W;
    output n960;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire W1_N_120;
    wire [7:0]W1R;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(586[10:13])
    
    wire OBCLIP, BGE, OBE, nVISR, CLIPBR, CLIPOR_N_131, W0_N_114;
    wire [4:0]W0R;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(585[10:13])
    wire [4:0]n17;
    
    wire n1898;
    
    FD1P3AX BGCLIP_57 (.D(W1R[1]), .SP(W1_N_120), .CK(Clk), .Q(BGCLIP));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam BGCLIP_57.GSR = "DISABLED";
    FD1P3AX OBCLIP_58 (.D(W1R[2]), .SP(W1_N_120), .CK(Clk), .Q(OBCLIP));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam OBCLIP_58.GSR = "DISABLED";
    FD1P3AX BGE_59 (.D(W1R[3]), .SP(W1_N_120), .CK(Clk), .Q(BGE));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam BGE_59.GSR = "DISABLED";
    FD1P3AX OBE_60 (.D(W1R[4]), .SP(W1_N_120), .CK(Clk), .Q(OBE));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam OBE_60.GSR = "DISABLED";
    FD1P3AX EMP_R_61 (.D(W1R[5]), .SP(W1_N_120), .CK(Clk), .Q(EMP_R));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam EMP_R_61.GSR = "DISABLED";
    FD1P3AX EMP_G_62 (.D(W1R[6]), .SP(W1_N_120), .CK(Clk), .Q(EMP_G));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam EMP_G_62.GSR = "DISABLED";
    FD1P3AX nVISR_63 (.D(nVIS), .SP(Clk_enable_562), .CK(Clk), .Q(nVISR));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam nVISR_63.GSR = "DISABLED";
    FD1P3AX CLIPBR_64 (.D(CLIP_B_N_240), .SP(Clk_enable_562), .CK(Clk), 
            .Q(CLIPBR));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam CLIPBR_64.GSR = "DISABLED";
    FD1P3AX CLIPOR_65 (.D(CLIPOR_N_131), .SP(Clk_enable_562), .CK(Clk), 
            .Q(CLIPOR));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam CLIPOR_65.GSR = "DISABLED";
    LUT4 i10864_2_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(n11839), .D(\ri[7] ), 
         .Z(n7934)) /* synthesis lut_function=(!(A (B (D)+!B (C (D)))+!A !((C+!(D))+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(599[15:37])
    defparam i10864_2_lut_4_lut.init = 16'h53ff;
    FD1P3AX I1_32_53 (.D(W0R[0]), .SP(W0_N_114), .CK(Clk), .Q(I1_32));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam I1_32_53.GSR = "DISABLED";
    FD1P3AX O8_16_56 (.D(W0R[3]), .SP(W0_N_114), .CK(Clk), .Q(O8_16));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam O8_16_56.GSR = "DISABLED";
    FD1P3AX OBSEL_54 (.D(W0R[1]), .SP(W0_N_114), .CK(Clk), .Q(OBSEL));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam OBSEL_54.GSR = "DISABLED";
    LUT4 i10583_4_lut (.A(nVISR), .B(CLIP_OUT), .C(OBE), .D(OBCLIP), 
         .Z(CLIPOR_N_131)) /* synthesis lut_function=(!(A+!(B (C)+!B (C (D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(610[20:46])
    defparam i10583_4_lut.init = 16'h5040;
    FD1P3AX BGSEL_55 (.D(W0R[2]), .SP(W0_N_114), .CK(Clk), .Q(BGSEL));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam BGSEL_55.GSR = "DISABLED";
    LUT4 W1_I_0_1_lut (.A(W1), .Z(W1_N_120)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(606[14:17])
    defparam W1_I_0_1_lut.init = 16'h5555;
    LUT4 i7330_2_lut_3_lut (.A(W0), .B(RC), .C(DBIN[5]), .Z(n17[3])) /* synthesis lut_function=(!(A (B+!(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam i7330_2_lut_3_lut.init = 16'h7070;
    LUT4 i7331_2_lut_3_lut (.A(W0), .B(RC), .C(DBIN[7]), .Z(n17[4])) /* synthesis lut_function=(!(A (B+!(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam i7331_2_lut_3_lut.init = 16'h7070;
    LUT4 i7294_2_lut_3_lut (.A(W0), .B(RC), .C(DBIN[2]), .Z(n17[0])) /* synthesis lut_function=(!(A (B+!(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam i7294_2_lut_3_lut.init = 16'h7070;
    LUT4 i7328_2_lut_3_lut (.A(W0), .B(RC), .C(DBIN[3]), .Z(n17[1])) /* synthesis lut_function=(!(A (B+!(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam i7328_2_lut_3_lut.init = 16'h7070;
    LUT4 i7329_2_lut_3_lut (.A(W0), .B(RC), .C(DBIN[4]), .Z(n17[2])) /* synthesis lut_function=(!(A (B+!(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam i7329_2_lut_3_lut.init = 16'h7070;
    LUT4 BGE_I_0_66_2_lut_rep_364 (.A(BGE), .B(OBE), .Z(n11840)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(592[17:30])
    defparam BGE_I_0_66_2_lut_rep_364.init = 16'heeee;
    LUT4 BLACK_I_0_2_lut_rep_324_3_lut (.A(BGE), .B(OBE), .C(BLNK_FF), 
         .Z(n11800)) /* synthesis lut_function=(A (C)+!A ((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(592[17:30])
    defparam BLACK_I_0_2_lut_rep_324_3_lut.init = 16'hf1f1;
    LUT4 BLNK_I_0_713_2_lut_rep_277_3_lut_4_lut (.A(BGE), .B(OBE), .C(\H[8] ), 
         .D(BLNK_FF), .Z(n11753)) /* synthesis lut_function=(A ((D)+!C)+!A (((D)+!C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(592[17:30])
    defparam BLNK_I_0_713_2_lut_rep_277_3_lut_4_lut.init = 16'hff1f;
    LUT4 i7167_2_lut_3_lut (.A(BGE), .B(OBE), .C(N_HB), .Z(SC_CNT)) /* synthesis lut_function=(A (C)+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(592[17:30])
    defparam i7167_2_lut_3_lut.init = 16'he0e0;
    LUT4 Hn2_I_0_2_lut_rep_286_3_lut_4_lut (.A(BGE), .B(OBE), .C(\Hn[2] ), 
         .D(BLNK_FF), .Z(n11762)) /* synthesis lut_function=(!(A ((D)+!C)+!A (((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(592[17:30])
    defparam Hn2_I_0_2_lut_rep_286_3_lut_4_lut.init = 16'h00e0;
    LUT4 I1_32_I_0_2_lut_rep_296_3_lut_4_lut (.A(BGE), .B(OBE), .C(I1_32), 
         .D(BLNK_FF), .Z(n11772)) /* synthesis lut_function=(A (C (D))+!A (B (C (D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(592[17:30])
    defparam I1_32_I_0_2_lut_rep_296_3_lut_4_lut.init = 16'hf010;
    LUT4 n224_bdd_2_lut_10908_3_lut_4_lut (.A(BGE), .B(OBE), .C(n11577), 
         .D(BLNK_FF), .Z(n11579)) /* synthesis lut_function=(A (C+!(D))+!A (B (C+!(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(592[17:30])
    defparam n224_bdd_2_lut_10908_3_lut_4_lut.init = 16'hf0fe;
    LUT4 BLNK_N_925_I_0_2_lut_3_lut_4_lut (.A(BGE), .B(OBE), .C(\FVO[1] ), 
         .D(BLNK_FF), .Z(NBFVO1)) /* synthesis lut_function=(A (C+!(D))+!A (B (C+!(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(592[17:30])
    defparam BLNK_N_925_I_0_2_lut_3_lut_4_lut.init = 16'hf0fe;
    LUT4 i10660_2_lut_rep_273_3_lut_4_lut (.A(BGE), .B(OBE), .C(\H[8] ), 
         .D(BLNK_FF), .Z(n11749)) /* synthesis lut_function=(!(A (C+(D))+!A ((C+(D))+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(592[17:30])
    defparam i10660_2_lut_rep_273_3_lut_4_lut.init = 16'h000e;
    LUT4 i10770_2_lut_2_lut_3_lut_4_lut (.A(BGE), .B(OBE), .C(n12292), 
         .D(BLNK_FF), .Z(OB2_7__N_1036)) /* synthesis lut_function=(!(A ((D)+!C)+!A (((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(592[17:30])
    defparam i10770_2_lut_2_lut_3_lut_4_lut.init = 16'h00e0;
    LUT4 W0_I_0_1_lut (.A(W0), .Z(W0_N_114)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(605[14:17])
    defparam W0_I_0_1_lut.init = 16'h5555;
    LUT4 i10580_3_lut (.A(nVISR), .B(BGE), .C(CLIPBR), .Z(nCLPB_N_123)) /* synthesis lut_function=(!(A+((C)+!B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(595[16:42])
    defparam i10580_3_lut.init = 16'h0404;
    LUT4 i1466_2_lut (.A(W1), .B(RC), .Z(n1898)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam i1466_2_lut.init = 16'h8888;
    FD1P3IX W1R__i7 (.D(DBIN[7]), .SP(W1), .CD(n1898), .CK(Clk), .Q(\EMPH[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=197, LSE_RLINE=220 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam W1R__i7.GSR = "DISABLED";
    FD1P3IX W1R__i6 (.D(DBIN[6]), .SP(W1), .CD(n1898), .CK(Clk), .Q(W1R[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=197, LSE_RLINE=220 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam W1R__i6.GSR = "DISABLED";
    FD1P3IX W1R__i5 (.D(DBIN[5]), .SP(W1), .CD(n1898), .CK(Clk), .Q(W1R[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=197, LSE_RLINE=220 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam W1R__i5.GSR = "DISABLED";
    FD1P3IX W1R__i4 (.D(DBIN[4]), .SP(W1), .CD(n1898), .CK(Clk), .Q(W1R[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=197, LSE_RLINE=220 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam W1R__i4.GSR = "DISABLED";
    FD1P3IX W1R__i3 (.D(DBIN[3]), .SP(W1), .CD(n1898), .CK(Clk), .Q(W1R[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=197, LSE_RLINE=220 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam W1R__i3.GSR = "DISABLED";
    FD1P3IX W1R__i2 (.D(DBIN[2]), .SP(W1), .CD(n1898), .CK(Clk), .Q(W1R[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=197, LSE_RLINE=220 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam W1R__i2.GSR = "DISABLED";
    FD1P3IX W1R__i1 (.D(DBIN[1]), .SP(W1), .CD(n1898), .CK(Clk), .Q(W1R[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=197, LSE_RLINE=220 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam W1R__i1.GSR = "DISABLED";
    FD1P3AX W0R__i4 (.D(n17[4]), .SP(W0), .CK(Clk), .Q(VBL_EN)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=197, LSE_RLINE=220 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam W0R__i4.GSR = "DISABLED";
    FD1P3AX W0R__i3 (.D(n17[3]), .SP(W0), .CK(Clk), .Q(W0R[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=197, LSE_RLINE=220 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam W0R__i3.GSR = "DISABLED";
    FD1P3AX W0R__i2 (.D(n17[2]), .SP(W0), .CK(Clk), .Q(W0R[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=197, LSE_RLINE=220 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam W0R__i2.GSR = "DISABLED";
    FD1P3AX W0R__i1 (.D(n17[1]), .SP(W0), .CK(Clk), .Q(W0R[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=197, LSE_RLINE=220 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam W0R__i1.GSR = "DISABLED";
    FD1P3IX W1R__i0 (.D(DBIN[0]), .SP(W1), .CD(n1898), .CK(Clk), .Q(B_W)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=197, LSE_RLINE=220 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam W1R__i0.GSR = "DISABLED";
    FD1P3AX W0R__i0 (.D(n17[0]), .SP(W0), .CK(Clk), .Q(W0R[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=197, LSE_RLINE=220 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam W0R__i0.GSR = "DISABLED";
    LUT4 i481_3_lut (.A(\EMPH[2] ), .B(EMP_R), .C(EMP_G), .Z(n960)) /* synthesis lut_function=(!((B (C)+!B !(C))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(602[8] 612[27])
    defparam i481_3_lut.init = 16'h2828;
    
endmodule
//
// Verilog Description of module PLL
//

module PLL (MCLK_c, Clk, GND_net) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input MCLK_c;
    output Clk;
    input GND_net;
    
    wire MCLK_c /* synthesis is_clock=1, SET_AS_NETWORK=MCLK_c */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(36[7:11])
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    EHXPLLJ PLLInst_0 (.CLKI(MCLK_c), .CLKFB(Clk), .PHASESEL0(GND_net), 
            .PHASESEL1(GND_net), .PHASEDIR(GND_net), .PHASESTEP(GND_net), 
            .LOADREG(GND_net), .STDBY(GND_net), .PLLWAKESYNC(GND_net), 
            .RST(GND_net), .RESETC(GND_net), .RESETD(GND_net), .RESETM(GND_net), 
            .ENCLKOP(GND_net), .ENCLKOS(GND_net), .ENCLKOS2(GND_net), 
            .ENCLKOS3(GND_net), .PLLCLK(GND_net), .PLLRST(GND_net), .PLLSTB(GND_net), 
            .PLLWE(GND_net), .PLLDATI0(GND_net), .PLLDATI1(GND_net), .PLLDATI2(GND_net), 
            .PLLDATI3(GND_net), .PLLDATI4(GND_net), .PLLDATI5(GND_net), 
            .PLLDATI6(GND_net), .PLLDATI7(GND_net), .PLLADDR0(GND_net), 
            .PLLADDR1(GND_net), .PLLADDR2(GND_net), .PLLADDR3(GND_net), 
            .PLLADDR4(GND_net), .CLKOP(Clk)) /* synthesis FREQUENCY_PIN_CLKOP="42.954000", FREQUENCY_PIN_CLKI="21.477000", ICP_CURRENT="7", LPF_RESISTOR="8", syn_instantiated=1, LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=158, LSE_RLINE=161 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(158[5] 161[2])
    defparam PLLInst_0.CLKI_DIV = 1;
    defparam PLLInst_0.CLKFB_DIV = 2;
    defparam PLLInst_0.CLKOP_DIV = 11;
    defparam PLLInst_0.CLKOS_DIV = 1;
    defparam PLLInst_0.CLKOS2_DIV = 1;
    defparam PLLInst_0.CLKOS3_DIV = 1;
    defparam PLLInst_0.CLKOP_ENABLE = "ENABLED";
    defparam PLLInst_0.CLKOS_ENABLE = "DISABLED";
    defparam PLLInst_0.CLKOS2_ENABLE = "DISABLED";
    defparam PLLInst_0.CLKOS3_ENABLE = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_A0 = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_B0 = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_C0 = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_D0 = "DISABLED";
    defparam PLLInst_0.CLKOP_CPHASE = 10;
    defparam PLLInst_0.CLKOS_CPHASE = 0;
    defparam PLLInst_0.CLKOS2_CPHASE = 0;
    defparam PLLInst_0.CLKOS3_CPHASE = 0;
    defparam PLLInst_0.CLKOP_FPHASE = 0;
    defparam PLLInst_0.CLKOS_FPHASE = 0;
    defparam PLLInst_0.CLKOS2_FPHASE = 0;
    defparam PLLInst_0.CLKOS3_FPHASE = 0;
    defparam PLLInst_0.FEEDBK_PATH = "CLKOP";
    defparam PLLInst_0.FRACN_ENABLE = "DISABLED";
    defparam PLLInst_0.FRACN_DIV = 0;
    defparam PLLInst_0.CLKOP_TRIM_POL = "RISING";
    defparam PLLInst_0.CLKOP_TRIM_DELAY = 0;
    defparam PLLInst_0.CLKOS_TRIM_POL = "FALLING";
    defparam PLLInst_0.CLKOS_TRIM_DELAY = 0;
    defparam PLLInst_0.PLL_USE_WB = "DISABLED";
    defparam PLLInst_0.PREDIVIDER_MUXA1 = 0;
    defparam PLLInst_0.PREDIVIDER_MUXB1 = 0;
    defparam PLLInst_0.PREDIVIDER_MUXC1 = 0;
    defparam PLLInst_0.PREDIVIDER_MUXD1 = 0;
    defparam PLLInst_0.OUTDIVIDER_MUXA2 = "DIVA";
    defparam PLLInst_0.OUTDIVIDER_MUXB2 = "DIVB";
    defparam PLLInst_0.OUTDIVIDER_MUXC2 = "DIVC";
    defparam PLLInst_0.OUTDIVIDER_MUXD2 = "DIVD";
    defparam PLLInst_0.PLL_LOCK_MODE = 0;
    defparam PLLInst_0.STDBY_ENABLE = "DISABLED";
    defparam PLLInst_0.DPHASE_SOURCE = "DISABLED";
    defparam PLLInst_0.PLLRST_ENA = "DISABLED";
    defparam PLLInst_0.MRST_ENA = "DISABLED";
    defparam PLLInst_0.DCRST_ENA = "DISABLED";
    defparam PLLInst_0.DDRST_ENA = "DISABLED";
    defparam PLLInst_0.INTFB_WAKE = "DISABLED";
    
endmodule
//
// Verilog Description of module REGISTER_SELECT
//

module REGISTER_SELECT (Clk, A_c_0, RnWR, RnW_c, nDBER, nDBE_c, 
            W5_1, W5_2, W6_1, W6_2, A_c_2, A_c_1, DBIN, DB_out_0, 
            R2, W0, W1, W3, R4, W4, R7, W7, Clk_enable_514, 
            RC, TH_4__N_769, DB_out_1, DB_out_2, DB_out_3, DB_out_4, 
            DB_out_5, DB_out_6, DB_out_7, Clk_enable_553) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input A_c_0;
    output RnWR;
    input RnW_c;
    output nDBER;
    input nDBE_c;
    output W5_1;
    output W5_2;
    output W6_1;
    output W6_2;
    input A_c_2;
    input A_c_1;
    output [7:0]DBIN;
    input DB_out_0;
    output R2;
    output W0;
    output W1;
    output W3;
    output R4;
    output W4;
    output R7;
    output W7;
    output Clk_enable_514;
    input RC;
    output TH_4__N_769;
    input DB_out_1;
    input DB_out_2;
    input DB_out_3;
    input DB_out_4;
    input DB_out_5;
    input DB_out_6;
    input DB_out_7;
    output Clk_enable_553;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [2:0]ADR;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(523[10:13])
    
    wire W5_1_N_61, W5_2_N_65, W6_1_N_73, W6_2_N_78, n11833, n11835, 
        DWR2, n11836, DBIN_7__N_26, DWR1, Clk_enable_124, DWR2_N_67, 
        Clk_enable_128, W0_N_34, W1_N_46, R2_N_49, W3_N_53, R4_N_60, 
        W4_N_56, R7_N_83, W7_N_80;
    
    FD1S3AX ADR_i0 (.D(A_c_0), .CK(Clk), .Q(ADR[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam ADR_i0.GSR = "DISABLED";
    FD1S3AX RnWR_132 (.D(RnW_c), .CK(Clk), .Q(RnWR)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam RnWR_132.GSR = "DISABLED";
    FD1S3AX nDBER_133 (.D(nDBE_c), .CK(Clk), .Q(nDBER)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam nDBER_133.GSR = "DISABLED";
    FD1S3AX W5_1_140 (.D(W5_1_N_61), .CK(Clk), .Q(W5_1)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam W5_1_140.GSR = "DISABLED";
    FD1S3AX W5_2_141 (.D(W5_2_N_65), .CK(Clk), .Q(W5_2)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam W5_2_141.GSR = "DISABLED";
    FD1S3AX W6_1_142 (.D(W6_1_N_73), .CK(Clk), .Q(W6_1)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam W6_1_142.GSR = "DISABLED";
    FD1S3AX W6_2_143 (.D(W6_2_N_78), .CK(Clk), .Q(W6_2)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam W6_2_143.GSR = "DISABLED";
    LUT4 i1_2_lut_4_lut (.A(n11833), .B(ADR[0]), .C(n11835), .D(DWR2), 
         .Z(W6_1_N_73)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(542[18:61])
    defparam i1_2_lut_4_lut.init = 16'h0200;
    LUT4 i1_2_lut_4_lut_adj_400 (.A(n11833), .B(ADR[0]), .C(n11835), .D(DWR2), 
         .Z(W6_2_N_78)) /* synthesis lut_function=(!((B+(C+(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(542[18:61])
    defparam i1_2_lut_4_lut_adj_400.init = 16'h0002;
    LUT4 i1_2_lut_4_lut_adj_401 (.A(n11836), .B(ADR[0]), .C(n11835), .D(DWR2), 
         .Z(W5_1_N_61)) /* synthesis lut_function=(!(((C+!(D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(540[18:61])
    defparam i1_2_lut_4_lut_adj_401.init = 16'h0800;
    LUT4 i1_2_lut_4_lut_adj_402 (.A(n11836), .B(ADR[0]), .C(n11835), .D(DWR2), 
         .Z(W5_2_N_65)) /* synthesis lut_function=(!(((C+(D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(540[18:61])
    defparam i1_2_lut_4_lut_adj_402.init = 16'h0008;
    FD1S3AX ADR_i2 (.D(A_c_2), .CK(Clk), .Q(ADR[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam ADR_i2.GSR = "DISABLED";
    FD1S3AX ADR_i1 (.D(A_c_1), .CK(Clk), .Q(ADR[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam ADR_i1.GSR = "DISABLED";
    FD1P3AX DBIN_i0_i0 (.D(DB_out_0), .SP(DBIN_7__N_26), .CK(Clk), .Q(DBIN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam DBIN_i0_i0.GSR = "DISABLED";
    FD1P3JX DWR1_146 (.D(DWR2_N_67), .SP(Clk_enable_124), .PD(R2), .CK(Clk), 
            .Q(DWR1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam DWR1_146.GSR = "DISABLED";
    FD1P3JX DWR2_147 (.D(DWR1), .SP(Clk_enable_128), .PD(R2), .CK(Clk), 
            .Q(DWR2));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam DWR2_147.GSR = "DISABLED";
    FD1S3IX W0_134 (.D(W0_N_34), .CK(Clk), .CD(nDBER), .Q(W0));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam W0_134.GSR = "DISABLED";
    FD1S3IX W1_135 (.D(W1_N_46), .CK(Clk), .CD(nDBER), .Q(W1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam W1_135.GSR = "DISABLED";
    FD1S3IX R2_136 (.D(R2_N_49), .CK(Clk), .CD(nDBER), .Q(R2));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam R2_136.GSR = "DISABLED";
    FD1S3IX W3_137 (.D(W3_N_53), .CK(Clk), .CD(nDBER), .Q(W3));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam W3_137.GSR = "DISABLED";
    FD1S3IX R4_138 (.D(R4_N_60), .CK(Clk), .CD(nDBER), .Q(R4));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam R4_138.GSR = "DISABLED";
    FD1S3IX W4_139 (.D(W4_N_56), .CK(Clk), .CD(nDBER), .Q(W4));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam W4_139.GSR = "DISABLED";
    FD1S3IX R7_144 (.D(R7_N_83), .CK(Clk), .CD(nDBER), .Q(R7));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam R7_144.GSR = "DISABLED";
    FD1S3IX W7_145 (.D(W7_N_80), .CK(Clk), .CD(nDBER), .Q(W7));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam W7_145.GSR = "DISABLED";
    LUT4 i1_2_lut_rep_350 (.A(W6_2), .B(W5_1), .Z(Clk_enable_514)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(548[15:40])
    defparam i1_2_lut_rep_350.init = 16'heeee;
    LUT4 i4057_1_lut_3_lut_4_lut (.A(W6_2), .B(W5_1), .C(W5_2), .D(W6_1), 
         .Z(Clk_enable_128)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(548[15:40])
    defparam i4057_1_lut_3_lut_4_lut.init = 16'h0001;
    LUT4 i1_2_lut_3_lut (.A(W6_2), .B(W5_1), .C(RC), .Z(TH_4__N_769)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(548[15:40])
    defparam i1_2_lut_3_lut.init = 16'hfefe;
    LUT4 i2_3_lut_rep_316_4_lut (.A(W6_2), .B(W5_1), .C(W5_2), .D(W6_1), 
         .Z(Clk_enable_124)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(548[15:40])
    defparam i2_3_lut_rep_316_4_lut.init = 16'hfffe;
    LUT4 ADR_2__I_0_2_lut_rep_357 (.A(ADR[2]), .B(ADR[1]), .Z(n11833)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(542[18:34])
    defparam ADR_2__I_0_2_lut_rep_357.init = 16'h8888;
    LUT4 i1_2_lut_3_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(RnWR), .D(ADR[0]), 
         .Z(R7_N_83)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(542[18:34])
    defparam i1_2_lut_3_lut_4_lut.init = 16'h8000;
    LUT4 i1_2_lut_3_lut_4_lut_adj_403 (.A(ADR[2]), .B(ADR[1]), .C(RnWR), 
         .D(ADR[0]), .Z(W7_N_80)) /* synthesis lut_function=(!(((C+!(D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(542[18:34])
    defparam i1_2_lut_3_lut_4_lut_adj_403.init = 16'h0800;
    LUT4 i7226_2_lut_rep_359 (.A(RnWR), .B(nDBER), .Z(n11835)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i7226_2_lut_rep_359.init = 16'heeee;
    LUT4 ADR_2__I_0_154_2_lut_rep_360 (.A(ADR[2]), .B(ADR[1]), .Z(n11836)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(539[18:34])
    defparam ADR_2__I_0_154_2_lut_rep_360.init = 16'h2222;
    FD1P3AX DBIN_i0_i1 (.D(DB_out_1), .SP(DBIN_7__N_26), .CK(Clk), .Q(DBIN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam DBIN_i0_i1.GSR = "DISABLED";
    LUT4 i2_3_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), .D(RnWR), 
         .Z(W4_N_56)) /* synthesis lut_function=(!((B+(C+(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(539[18:34])
    defparam i2_3_lut_4_lut.init = 16'h0002;
    FD1P3AX DBIN_i0_i2 (.D(DB_out_2), .SP(DBIN_7__N_26), .CK(Clk), .Q(DBIN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam DBIN_i0_i2.GSR = "DISABLED";
    FD1P3AX DBIN_i0_i3 (.D(DB_out_3), .SP(DBIN_7__N_26), .CK(Clk), .Q(DBIN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam DBIN_i0_i3.GSR = "DISABLED";
    FD1P3AX DBIN_i0_i4 (.D(DB_out_4), .SP(DBIN_7__N_26), .CK(Clk), .Q(DBIN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam DBIN_i0_i4.GSR = "DISABLED";
    FD1P3AX DBIN_i0_i5 (.D(DB_out_5), .SP(DBIN_7__N_26), .CK(Clk), .Q(DBIN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam DBIN_i0_i5.GSR = "DISABLED";
    FD1P3AX DBIN_i0_i6 (.D(DB_out_6), .SP(DBIN_7__N_26), .CK(Clk), .Q(DBIN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam DBIN_i0_i6.GSR = "DISABLED";
    FD1P3AX DBIN_i0_i7 (.D(DB_out_7), .SP(DBIN_7__N_26), .CK(Clk), .Q(DBIN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=174, LSE_RLINE=194 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam DBIN_i0_i7.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut_adj_404 (.A(RnWR), .B(ADR[0]), .C(ADR[1]), 
         .D(ADR[2]), .Z(R4_N_60)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(539[18:44])
    defparam i1_2_lut_3_lut_4_lut_adj_404.init = 16'h0200;
    LUT4 i2_3_lut_4_lut_adj_405 (.A(RnWR), .B(ADR[0]), .C(ADR[1]), .D(ADR[2]), 
         .Z(R2_N_49)) /* synthesis lut_function=(!((B+((D)+!C))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(539[18:44])
    defparam i2_3_lut_4_lut_adj_405.init = 16'h0020;
    LUT4 i10704_2_lut_3_lut_4_lut (.A(RnWR), .B(ADR[2]), .C(ADR[0]), .D(ADR[1]), 
         .Z(W0_N_34)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;
    defparam i10704_2_lut_3_lut_4_lut.init = 16'h0001;
    LUT4 i1_2_lut_3_lut_4_lut_adj_406 (.A(RnWR), .B(ADR[2]), .C(ADR[0]), 
         .D(ADR[1]), .Z(W1_N_46)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;
    defparam i1_2_lut_3_lut_4_lut_adj_406.init = 16'h0010;
    LUT4 i2_3_lut_4_lut_adj_407 (.A(RnWR), .B(ADR[2]), .C(ADR[0]), .D(ADR[1]), 
         .Z(W3_N_53)) /* synthesis lut_function=(!(A+(B+!(C (D))))) */ ;
    defparam i2_3_lut_4_lut_adj_407.init = 16'h1000;
    LUT4 i10577_2_lut (.A(nDBE_c), .B(RnW_c), .Z(DBIN_7__N_26)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i10577_2_lut.init = 16'h1111;
    LUT4 DWR2_I_0_1_lut (.A(DWR2), .Z(DWR2_N_67)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(541[64:69])
    defparam DWR2_I_0_1_lut.init = 16'h5555;
    LUT4 i5258_1_lut (.A(R2), .Z(Clk_enable_553)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(530[8] 552[26])
    defparam i5258_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module PAR_GEN
//

module PAR_GEN (PAR_O, O8_16, \FVO[1] , Clk, RC, \PAD[0] , Clk_enable_564, 
            W6_1, W5_2, DBIN, Clk_enable_562, OV, OB, E_EV, PD_out_0, 
            TP, n11709, TAL_LATCH_N_883, I1_32, n11800, THO, TVZ, 
            Clk_enable_208, SC_CNT, Clk_enable_185, \TP[4] , \TP[3] , 
            \TP[2] , \TP[1] , PD_out_7, PD_out_6, PD_out_5, PD_out_4, 
            PD_out_3, PD_out_2, PD_out_1, Clk_enable_549, W0, RESCL, 
            NTVDO, NTV_IN, W6_2, Clk_enable_530, n12292, PA12_c_12, 
            PA11_c_11, PA10_c_10, PA9_c_9, Clk_enable_367, PA8_c_8, 
            \PAD[7] , \PAMUX[7] , \PAD[6] , \PAMUX[6] , \PAD[5] , 
            \PAD[4] , n11748, \PAD[3] , \PAD[2] , \PAD[1] , F_NT, 
            \Hnn[0] , n10702, TVO1, Clk_enable_514, \TVO[2] , \TVO[4] , 
            \TVO[0] , \TVO[3] , SH2, SEL_LATCH, ATR_IN1_2__N_1355, 
            ATR_IN0_2__N_1353, n11762, n11794, ATR_IN2_2__N_1356, ATR_IN3_2__N_1357, 
            ATR_IN4_2__N_1358, ATR_IN5_2__N_1359, ATR_IN6_2__N_1360, ATR_IN7_2__N_1361, 
            W5_1, PAMUX_7__N_844, TH_4__N_769, \Hn[2] , \PAMUX_7__N_852[1] , 
            n10992, \PAMUX_7__N_852[2] , \PAMUX_7__N_852[3] , \PAMUX_7__N_852[4] , 
            \PAMUX_7__N_852[5] , \PAMUX_7__N_852[0] , PA13_c_13, n5786, 
            NBFVO1, BGSEL, OBSEL, Clk_enable_513, n11786, THSTEP_N_916, 
            n11729, n11772, CNT1_N_558, TVZB, n11724) /* synthesis syn_module_defined=1 */ ;
    input PAR_O;
    input O8_16;
    output \FVO[1] ;
    input Clk;
    input RC;
    output \PAD[0] ;
    input Clk_enable_564;
    input W6_1;
    input W5_2;
    input [7:0]DBIN;
    input Clk_enable_562;
    input [3:0]OV;
    input [7:0]OB;
    input E_EV;
    input PD_out_0;
    output [11:0]TP;
    input n11709;
    output TAL_LATCH_N_883;
    input I1_32;
    input n11800;
    output [4:0]THO;
    input TVZ;
    output Clk_enable_208;
    input SC_CNT;
    input Clk_enable_185;
    output \TP[4] ;
    output \TP[3] ;
    output \TP[2] ;
    output \TP[1] ;
    input PD_out_7;
    input PD_out_6;
    input PD_out_5;
    input PD_out_4;
    input PD_out_3;
    input PD_out_2;
    input PD_out_1;
    input Clk_enable_549;
    input W0;
    input RESCL;
    output NTVDO;
    output NTV_IN;
    input W6_2;
    input Clk_enable_530;
    input n12292;
    output PA12_c_12;
    output PA11_c_11;
    output PA10_c_10;
    output PA9_c_9;
    input Clk_enable_367;
    output PA8_c_8;
    output \PAD[7] ;
    input \PAMUX[7] ;
    output \PAD[6] ;
    input \PAMUX[6] ;
    output \PAD[5] ;
    output \PAD[4] ;
    input n11748;
    output \PAD[3] ;
    output \PAD[2] ;
    output \PAD[1] ;
    input F_NT;
    input \Hnn[0] ;
    output n10702;
    output TVO1;
    input Clk_enable_514;
    output \TVO[2] ;
    output \TVO[4] ;
    output \TVO[0] ;
    output \TVO[3] ;
    input SH2;
    input [7:0]SEL_LATCH;
    output ATR_IN1_2__N_1355;
    output ATR_IN0_2__N_1353;
    input n11762;
    input n11794;
    output ATR_IN2_2__N_1356;
    output ATR_IN3_2__N_1357;
    output ATR_IN4_2__N_1358;
    output ATR_IN5_2__N_1359;
    output ATR_IN6_2__N_1360;
    output ATR_IN7_2__N_1361;
    input W5_1;
    output [7:0]PAMUX_7__N_844;
    input TH_4__N_769;
    input \Hn[2] ;
    input \PAMUX_7__N_852[1] ;
    input n10992;
    input \PAMUX_7__N_852[2] ;
    input \PAMUX_7__N_852[3] ;
    input \PAMUX_7__N_852[4] ;
    input \PAMUX_7__N_852[5] ;
    input \PAMUX_7__N_852[0] ;
    output PA13_c_13;
    input n5786;
    input NBFVO1;
    input BGSEL;
    input OBSEL;
    input Clk_enable_513;
    input n11786;
    input THSTEP_N_916;
    input n11729;
    input n11772;
    input [0:0]CNT1_N_558;
    input TVZB;
    input n11724;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]PDOUT;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1054[10:15])
    wire [7:0]OBOUT;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1055[10:15])
    wire [6:0]TP_11__N_864;
    
    wire TP_11__N_872, TP_11__N_871, VINV_LATCH;
    wire [3:0]OVOUT;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1052[10:15])
    wire [2:0]FVO;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1091[11:14])
    wire [2:0]TP_11__N_873;
    wire [2:0]FV;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1060[10:12])
    
    wire TV_4__N_796, FV_2__N_830;
    wire [13:0]PAMUX;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1105[12:17])
    wire [3:0]OVR;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1051[10:13])
    wire [4:0]TV;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1058[10:12])
    
    wire TV_4__N_809, TV_4__N_817, OVOUT_3__N_861;
    wire [7:0]PDIN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1053[10:14])
    
    wire TV_IN, TV_IN_N_906;
    wire [1:0]EEVR;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1061[10:14])
    wire [1:0]W62;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1066[10:13])
    
    wire W62_1__N_839;
    wire [1:0]Z_TV;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1063[10:14])
    
    wire TAL_LATCH, n11705;
    wire [0:0]CNT1_N_558_c;
    
    wire TVZR, SCCNTR, TVZR_N_877;
    wire [11:0]TP_c;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1056[11:13])
    
    wire TP_11__N_862, Clk_enable_538, n11814, W62_FF, Clk_enable_209, 
        n11767, TV_4__N_797, TV_4__N_793;
    wire [0:0]CNT1_N_558_adj_1606;
    
    wire TV_4__N_800, TV_4__N_805, TV_4__N_812, CNT1, n5593, CNT1_adj_1587, 
        n5258, CNT1_adj_1588, n5527, CNT1_adj_1589, n5150, FV_2__N_822, 
        FV_2__N_825, NTHDO;
    wire [4:0]TH;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1057[10:12])
    
    wire TH_4__N_788, n6, THLOAD_N_909, n6_adj_1590, n10706, TH_4__N_783, 
        CNT1_adj_1591, n5794, CNT1_adj_1592, n5796, n5528, n5259, 
        TH_4__N_778, TH_4__N_773, NTV, n5594, n5151, CNT1_adj_1593, 
        n5792, CNT1_adj_1594, n5766, CNT1_adj_1595, n5764, n4, TH_4__N_766, 
        ZTV_N_921, NTH_N_892, NTV_N_899, NTH, TP_11__N_863;
    wire [0:0]CNT1_N_558_adj_1607;
    
    wire Clk_enable_552;
    wire [0:0]CNT1_N_558_adj_1608;
    wire [0:0]CNT1_N_558_adj_1609;
    
    wire n11801, n11841;
    wire [0:0]CNT1_N_558_adj_1610;
    wire [0:0]CNT1_N_558_adj_1611;
    wire [0:0]CNT1_N_558_adj_1612;
    wire [0:0]CNT1_N_558_adj_1613;
    wire [0:0]CNT1_N_558_adj_1615;
    wire [0:0]CNT1_N_558_adj_1616;
    
    LUT4 mux_199_i7_3_lut (.A(PDOUT[7]), .B(OBOUT[7]), .C(PAR_O), .Z(TP_11__N_864[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1148[20:53])
    defparam mux_199_i7_3_lut.init = 16'hcaca;
    LUT4 mux_199_i6_3_lut (.A(PDOUT[6]), .B(OBOUT[6]), .C(PAR_O), .Z(TP_11__N_864[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1148[20:53])
    defparam mux_199_i6_3_lut.init = 16'hcaca;
    LUT4 mux_199_i1_3_lut (.A(PDOUT[1]), .B(OBOUT[1]), .C(PAR_O), .Z(TP_11__N_864[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1148[20:53])
    defparam mux_199_i1_3_lut.init = 16'hcaca;
    LUT4 PDOUT_0__I_0_3_lut (.A(PDOUT[0]), .B(TP_11__N_872), .C(PAR_O), 
         .Z(TP_11__N_871)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1147[20:77])
    defparam PDOUT_0__I_0_3_lut.init = 16'hcaca;
    LUT4 OBOUT_0__I_0_4_lut (.A(OBOUT[0]), .B(VINV_LATCH), .C(O8_16), 
         .D(OVOUT[3]), .Z(TP_11__N_872)) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1147[30:66])
    defparam OBOUT_0__I_0_4_lut.init = 16'h3aca;
    LUT4 mux_196_i3_4_lut (.A(FVO[2]), .B(VINV_LATCH), .C(PAR_O), .D(OVOUT[2]), 
         .Z(TP_11__N_873[2])) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1146[20:53])
    defparam mux_196_i3_4_lut.init = 16'h3aca;
    LUT4 mux_196_i2_4_lut (.A(\FVO[1] ), .B(VINV_LATCH), .C(PAR_O), .D(OVOUT[1]), 
         .Z(TP_11__N_873[1])) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1146[20:53])
    defparam mux_196_i2_4_lut.init = 16'h3aca;
    FD1P3IX FV__i0 (.D(FV_2__N_830), .SP(TV_4__N_796), .CD(RC), .CK(Clk), 
            .Q(FV[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam FV__i0.GSR = "DISABLED";
    FD1P3AX PAD_i0_i0 (.D(PAMUX[0]), .SP(Clk_enable_564), .CK(Clk), .Q(\PAD[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i0.GSR = "DISABLED";
    LUT4 FV_2__I_242_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[4]), .D(DBIN[0]), 
         .Z(FV_2__N_830)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1123[50:85])
    defparam FV_2__I_242_4_lut.init = 16'heca0;
    FD1P3AX OVR_i0_i0 (.D(OV[0]), .SP(Clk_enable_562), .CK(Clk), .Q(OVR[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OVR_i0_i0.GSR = "DISABLED";
    FD1P3IX TV_i0 (.D(TV_4__N_817), .SP(TV_4__N_809), .CD(RC), .CK(Clk), 
            .Q(TV[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TV_i0.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i0 (.D(OB[0]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(OBOUT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OBOUT_i0_i0.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i0 (.D(PDIN[0]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(PDOUT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDOUT_i0_i0.GSR = "DISABLED";
    FD1S3AX TV_IN_241 (.D(TV_IN_N_906), .CK(Clk), .Q(TV_IN)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TV_IN_241.GSR = "DISABLED";
    FD1P3AX EEVR_i0 (.D(E_EV), .SP(Clk_enable_562), .CK(Clk), .Q(EEVR[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam EEVR_i0.GSR = "DISABLED";
    FD1P3AX W62_i0 (.D(W62_1__N_839), .SP(Clk_enable_562), .CK(Clk), .Q(W62[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam W62_i0.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i0 (.D(PD_out_0), .SP(Clk_enable_562), .CK(Clk), .Q(PDIN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDIN_i0_i0.GSR = "DISABLED";
    FD1P3AX TP_i0_i0 (.D(TP_11__N_873[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(TP[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TP_i0_i0.GSR = "DISABLED";
    FD1P3AX Z_TV_i0_i0 (.D(n11709), .SP(Clk_enable_562), .CK(Clk), .Q(Z_TV[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam Z_TV_i0_i0.GSR = "DISABLED";
    FD1P3AX TAL_LATCH_251 (.D(TAL_LATCH_N_883), .SP(Clk_enable_562), .CK(Clk), 
            .Q(TAL_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TAL_LATCH_251.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut_rep_229_3_lut_4_lut (.A(I1_32), .B(n11800), .C(THO[1]), 
         .D(THO[0]), .Z(n11705)) /* synthesis lut_function=(!(A (B+!(C (D)))+!A !(C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1079[17:33])
    defparam CNT_I_0_2_lut_rep_229_3_lut_4_lut.init = 16'h7000;
    LUT4 i1786_2_lut_3_lut_4_lut (.A(I1_32), .B(n11800), .C(THO[1]), .D(THO[0]), 
         .Z(CNT1_N_558_c[0])) /* synthesis lut_function=(A (B (C)+!B !(C (D)+!C !(D)))+!A !(C (D)+!C !(D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1079[17:33])
    defparam i1786_2_lut_3_lut_4_lut.init = 16'h87f0;
    FD1P3AX TVZR_246 (.D(TVZ), .SP(Clk_enable_564), .CK(Clk), .Q(TVZR));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TVZR_246.GSR = "DISABLED";
    FD1P3AX VINV_LATCH_240 (.D(OB[7]), .SP(Clk_enable_208), .CK(Clk), 
            .Q(VINV_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam VINV_LATCH_240.GSR = "DISABLED";
    FD1P3AX SCCNTR_248 (.D(SC_CNT), .SP(Clk_enable_564), .CK(Clk), .Q(SCCNTR));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam SCCNTR_248.GSR = "DISABLED";
    FD1P3AX Z_TV_i0_i1 (.D(TVZR_N_877), .SP(Clk_enable_185), .CK(Clk), 
            .Q(Z_TV[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam Z_TV_i0_i1.GSR = "DISABLED";
    FD1P3AX TP_i0_i11 (.D(TP_11__N_862), .SP(Clk_enable_185), .CK(Clk), 
            .Q(TP_c[11])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TP_i0_i11.GSR = "DISABLED";
    FD1P3AX TP_i0_i10 (.D(TP_11__N_864[6]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(TP_c[10])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TP_i0_i10.GSR = "DISABLED";
    FD1P3AX TP_i0_i9 (.D(TP_11__N_864[5]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(TP_c[9])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TP_i0_i9.GSR = "DISABLED";
    FD1P3AX TP_i0_i8 (.D(TP_11__N_864[4]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(TP_c[8])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TP_i0_i8.GSR = "DISABLED";
    FD1P3AX TP_i0_i7 (.D(TP_11__N_864[3]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(TP_c[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TP_i0_i7.GSR = "DISABLED";
    FD1P3AX TP_i0_i6 (.D(TP_11__N_864[2]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(TP_c[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TP_i0_i6.GSR = "DISABLED";
    FD1P3AX TP_i0_i5 (.D(TP_11__N_864[1]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(TP_c[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TP_i0_i5.GSR = "DISABLED";
    FD1P3AX TP_i0_i4 (.D(TP_11__N_864[0]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(\TP[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TP_i0_i4.GSR = "DISABLED";
    FD1P3AX TP_i0_i3 (.D(TP_11__N_871), .SP(Clk_enable_185), .CK(Clk), 
            .Q(\TP[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TP_i0_i3.GSR = "DISABLED";
    FD1P3AX TP_i0_i2 (.D(TP_11__N_873[2]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(\TP[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TP_i0_i2.GSR = "DISABLED";
    FD1P3AX TP_i0_i1 (.D(TP_11__N_873[1]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(\TP[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TP_i0_i1.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i7 (.D(PD_out_7), .SP(Clk_enable_185), .CK(Clk), .Q(PDIN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDIN_i0_i7.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i6 (.D(PD_out_6), .SP(Clk_enable_185), .CK(Clk), .Q(PDIN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDIN_i0_i6.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i5 (.D(PD_out_5), .SP(Clk_enable_185), .CK(Clk), .Q(PDIN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDIN_i0_i5.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i4 (.D(PD_out_4), .SP(Clk_enable_185), .CK(Clk), .Q(PDIN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDIN_i0_i4.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i3 (.D(PD_out_3), .SP(Clk_enable_185), .CK(Clk), .Q(PDIN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDIN_i0_i3.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i2 (.D(PD_out_2), .SP(Clk_enable_185), .CK(Clk), .Q(PDIN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDIN_i0_i2.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i1 (.D(PD_out_1), .SP(Clk_enable_185), .CK(Clk), .Q(PDIN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDIN_i0_i1.GSR = "DISABLED";
    FD1P3AX W62_i1 (.D(W62[0]), .SP(Clk_enable_549), .CK(Clk), .Q(W62[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam W62_i1.GSR = "DISABLED";
    FD1P3AX EEVR_i1 (.D(EEVR[0]), .SP(Clk_enable_549), .CK(Clk), .Q(EEVR[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam EEVR_i1.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i7 (.D(PDIN[7]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(PDOUT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDOUT_i0_i7.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i6 (.D(PDIN[6]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(PDOUT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDOUT_i0_i6.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i5 (.D(PDIN[5]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(PDOUT[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDOUT_i0_i5.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i4 (.D(PDIN[4]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(PDOUT[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDOUT_i0_i4.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i3 (.D(PDIN[3]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(PDOUT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDOUT_i0_i3.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i2 (.D(PDIN[2]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(PDOUT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDOUT_i0_i2.GSR = "DISABLED";
    LUT4 mux_199_i2_3_lut (.A(PDOUT[2]), .B(OBOUT[2]), .C(PAR_O), .Z(TP_11__N_864[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1148[20:53])
    defparam mux_199_i2_3_lut.init = 16'hcaca;
    FD1P3AX PDOUT_i0_i1 (.D(PDIN[1]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(PDOUT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PDOUT_i0_i1.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i7 (.D(OB[7]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(OBOUT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OBOUT_i0_i7.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i6 (.D(OB[6]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(OBOUT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OBOUT_i0_i6.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut (.A(RC), .B(W6_1), .C(W5_2), .Z(TV_4__N_796)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1120[11:22])
    defparam i1_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut_adj_396 (.A(RC), .B(W6_1), .C(W0), .Z(Clk_enable_538)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1120[11:22])
    defparam i1_2_lut_3_lut_adj_396.init = 16'hfefe;
    LUT4 TVLOAD_I_258_3_lut_rep_338 (.A(SCCNTR), .B(W62[1]), .C(RESCL), 
         .Z(n11814)) /* synthesis lut_function=(A (B+(C))+!A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1074[21:50])
    defparam TVLOAD_I_258_3_lut_rep_338.init = 16'hecec;
    FD1P3AX OBOUT_i0_i5 (.D(OB[5]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(OBOUT[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OBOUT_i0_i5.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i4 (.D(OB[4]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(OBOUT[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OBOUT_i0_i4.GSR = "DISABLED";
    FD1P3AX W62_FF_245 (.D(n11767), .SP(Clk_enable_209), .CK(Clk), .Q(W62_FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam W62_FF_245.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i3 (.D(OB[3]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(OBOUT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OBOUT_i0_i3.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i2 (.D(OB[2]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(OBOUT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OBOUT_i0_i2.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i1 (.D(OB[1]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(OBOUT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OBOUT_i0_i1.GSR = "DISABLED";
    FD1P3IX TV_i4 (.D(TV_4__N_793), .SP(TV_4__N_797), .CD(RC), .CK(Clk), 
            .Q(TV[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TV_i4.GSR = "DISABLED";
    LUT4 i1863_2_lut_4_lut (.A(n11800), .B(NTVDO), .C(NTV_IN), .D(FVO[0]), 
         .Z(CNT1_N_558_adj_1606[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1082[17:40])
    defparam i1863_2_lut_4_lut.init = 16'h2ad5;
    FD1P3IX TV_i3 (.D(TV_4__N_800), .SP(TV_4__N_797), .CD(RC), .CK(Clk), 
            .Q(TV[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TV_i3.GSR = "DISABLED";
    FD1P3IX TV_i2 (.D(TV_4__N_805), .SP(TV_4__N_809), .CD(RC), .CK(Clk), 
            .Q(TV[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TV_i2.GSR = "DISABLED";
    FD1P3IX TV_i1 (.D(TV_4__N_812), .SP(TV_4__N_809), .CD(RC), .CK(Clk), 
            .Q(TV[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TV_i1.GSR = "DISABLED";
    LUT4 W6_2_I_0_271_2_lut (.A(W6_2), .B(W5_2), .Z(TV_4__N_809)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1118[11:22])
    defparam W6_2_I_0_271_2_lut.init = 16'heeee;
    LUT4 TV_4__I_237_4_lut (.A(W6_2), .B(W5_2), .C(DBIN[5]), .D(DBIN[3]), 
         .Z(TV_4__N_817)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1116[50:85])
    defparam TV_4__I_237_4_lut.init = 16'heca0;
    FD1P3AX OVR_i0_i3 (.D(OV[3]), .SP(Clk_enable_530), .CK(Clk), .Q(OVR[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OVR_i0_i3.GSR = "DISABLED";
    FD1P3AX OVR_i0_i2 (.D(OV[2]), .SP(Clk_enable_530), .CK(Clk), .Q(OVR[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OVR_i0_i2.GSR = "DISABLED";
    FD1P3AX OVR_i0_i1 (.D(OV[1]), .SP(Clk_enable_530), .CK(Clk), .Q(OVR[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OVR_i0_i1.GSR = "DISABLED";
    LUT4 i10772_2_lut (.A(n12292), .B(TAL_LATCH), .Z(OVOUT_3__N_861)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1128[12:33])
    defparam i10772_2_lut.init = 16'h2222;
    FD1P3AX PAD_i0_i12 (.D(PAMUX[12]), .SP(Clk_enable_549), .CK(Clk), 
            .Q(PA12_c_12)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i12.GSR = "DISABLED";
    FD1P3AX PAD_i0_i11 (.D(PAMUX[11]), .SP(Clk_enable_549), .CK(Clk), 
            .Q(PA11_c_11)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i11.GSR = "DISABLED";
    FD1P3AX PAD_i0_i10 (.D(PAMUX[10]), .SP(Clk_enable_549), .CK(Clk), 
            .Q(PA10_c_10)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i10.GSR = "DISABLED";
    FD1P3AX PAD_i0_i9 (.D(PAMUX[9]), .SP(Clk_enable_367), .CK(Clk), .Q(PA9_c_9)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i9.GSR = "DISABLED";
    FD1P3AX PAD_i0_i8 (.D(PAMUX[8]), .SP(Clk_enable_367), .CK(Clk), .Q(PA8_c_8)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i8.GSR = "DISABLED";
    FD1P3AX PAD_i0_i7 (.D(\PAMUX[7] ), .SP(Clk_enable_367), .CK(Clk), 
            .Q(\PAD[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i7.GSR = "DISABLED";
    LUT4 mux_199_i5_3_lut (.A(PDOUT[5]), .B(OBOUT[5]), .C(PAR_O), .Z(TP_11__N_864[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1148[20:53])
    defparam mux_199_i5_3_lut.init = 16'hcaca;
    FD1P3AX PAD_i0_i6 (.D(\PAMUX[6] ), .SP(Clk_enable_367), .CK(Clk), 
            .Q(\PAD[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i6.GSR = "DISABLED";
    FD1P3AX PAD_i0_i5 (.D(PAMUX[5]), .SP(Clk_enable_367), .CK(Clk), .Q(\PAD[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i5.GSR = "DISABLED";
    FD1P3AX PAD_i0_i4 (.D(PAMUX[4]), .SP(Clk_enable_367), .CK(Clk), .Q(\PAD[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i4.GSR = "DISABLED";
    LUT4 i5088_3_lut_4_lut (.A(n11748), .B(n12292), .C(CNT1), .D(NTVDO), 
         .Z(n5593)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1076[18:48])
    defparam i5088_3_lut_4_lut.init = 16'hfd20;
    FD1P3AX PAD_i0_i3 (.D(PAMUX[3]), .SP(Clk_enable_367), .CK(Clk), .Q(\PAD[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i3.GSR = "DISABLED";
    FD1P3AX PAD_i0_i2 (.D(PAMUX[2]), .SP(Clk_enable_367), .CK(Clk), .Q(\PAD[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i2.GSR = "DISABLED";
    FD1P3AX PAD_i0_i1 (.D(PAMUX[1]), .SP(Clk_enable_367), .CK(Clk), .Q(\PAD[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i1.GSR = "DISABLED";
    LUT4 i4753_3_lut_4_lut (.A(n11748), .B(n12292), .C(CNT1_adj_1587), 
         .D(FVO[0]), .Z(n5258)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1076[18:48])
    defparam i4753_3_lut_4_lut.init = 16'hfd20;
    LUT4 mux_199_i4_3_lut (.A(PDOUT[4]), .B(OBOUT[4]), .C(PAR_O), .Z(TP_11__N_864[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1148[20:53])
    defparam mux_199_i4_3_lut.init = 16'hcaca;
    LUT4 W62_FF_I_0_287_2_lut (.A(W62_FF), .B(W6_2), .Z(W62_1__N_839)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1152[20:34])
    defparam W62_FF_I_0_287_2_lut.init = 16'h2222;
    LUT4 i5022_3_lut_4_lut (.A(n11748), .B(n12292), .C(CNT1_adj_1588), 
         .D(\FVO[1] ), .Z(n5527)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1076[18:48])
    defparam i5022_3_lut_4_lut.init = 16'hfd20;
    LUT4 mux_196_i1_4_lut (.A(FVO[0]), .B(VINV_LATCH), .C(PAR_O), .D(OVOUT[0]), 
         .Z(TP_11__N_873[0])) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1146[20:53])
    defparam mux_196_i1_4_lut.init = 16'h3aca;
    LUT4 i4645_3_lut_4_lut (.A(n11748), .B(n12292), .C(CNT1_adj_1589), 
         .D(FVO[2]), .Z(n5150)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1076[18:48])
    defparam i4645_3_lut_4_lut.init = 16'hfd20;
    FD1P3AX OVOUT_i0_i0 (.D(OVR[0]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(OVOUT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OVOUT_i0_i0.GSR = "DISABLED";
    LUT4 i10700_2_lut (.A(F_NT), .B(\Hnn[0] ), .Z(TAL_LATCH_N_883)) /* synthesis lut_function=(!(A (B))) */ ;
    defparam i10700_2_lut.init = 16'h7777;
    LUT4 W5_2_I_0_277_2_lut (.A(W5_2), .B(DBIN[2]), .Z(FV_2__N_822)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1125[69:85])
    defparam W5_2_I_0_277_2_lut.init = 16'h8888;
    LUT4 FV_2__I_240_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[5]), .D(DBIN[1]), 
         .Z(FV_2__N_825)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1124[50:85])
    defparam FV_2__I_240_4_lut.init = 16'heca0;
    LUT4 i1_4_lut (.A(n10702), .B(n11800), .C(NTHDO), .D(TVO1), .Z(NTV_IN)) /* synthesis lut_function=(A (B (C (D))+!B !(D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1081[19:40])
    defparam i1_4_lut.init = 16'h8022;
    FD1P3IX TH__i0 (.D(TH_4__N_788), .SP(Clk_enable_514), .CD(RC), .CK(Clk), 
            .Q(TH[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TH__i0.GSR = "DISABLED";
    LUT4 i4_4_lut (.A(\TVO[2] ), .B(TV_IN), .C(\TVO[4] ), .D(n6), .Z(n10702)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1087[15:39])
    defparam i4_4_lut.init = 16'h8000;
    LUT4 i1_2_lut (.A(\TVO[0] ), .B(\TVO[3] ), .Z(n6)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1087[15:39])
    defparam i1_2_lut.init = 16'h8888;
    FD1P3IX FV__i2 (.D(FV_2__N_822), .SP(TV_4__N_797), .CD(RC), .CK(Clk), 
            .Q(FV[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam FV__i2.GSR = "DISABLED";
    FD1P3IX FV__i1 (.D(FV_2__N_825), .SP(TV_4__N_797), .CD(RC), .CK(Clk), 
            .Q(FV[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam FV__i1.GSR = "DISABLED";
    LUT4 TVZR_I_0_1_lut (.A(TVZR), .Z(TVZR_N_877)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1150[21:26])
    defparam TVZR_I_0_1_lut.init = 16'h5555;
    LUT4 W6_1_I_0_266_2_lut (.A(W6_1), .B(W5_2), .Z(TV_4__N_797)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1120[11:22])
    defparam W6_1_I_0_266_2_lut.init = 16'heeee;
    LUT4 TV_4__I_227_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[1]), .D(DBIN[7]), 
         .Z(TV_4__N_793)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1120[50:85])
    defparam TV_4__I_227_4_lut.init = 16'heca0;
    LUT4 TV_4__I_230_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[0]), .D(DBIN[6]), 
         .Z(TV_4__N_800)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1119[50:85])
    defparam TV_4__I_230_4_lut.init = 16'heca0;
    LUT4 TV_4__I_232_4_lut (.A(W6_2), .B(W5_2), .C(DBIN[7]), .D(DBIN[5]), 
         .Z(TV_4__N_805)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1118[50:85])
    defparam TV_4__I_232_4_lut.init = 16'heca0;
    LUT4 TV_4__I_235_4_lut (.A(W6_2), .B(W5_2), .C(DBIN[6]), .D(DBIN[4]), 
         .Z(TV_4__N_812)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1117[50:85])
    defparam TV_4__I_235_4_lut.init = 16'heca0;
    LUT4 THLOAD_I_254_3_lut (.A(EEVR[1]), .B(n12292), .C(W62[1]), .Z(THLOAD_N_909)) /* synthesis lut_function=(A (B)+!A (B+!(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1073[18:51])
    defparam THLOAD_I_254_3_lut.init = 16'hcdcd;
    LUT4 i4_4_lut_adj_397 (.A(THO[2]), .B(THO[4]), .C(THO[1]), .D(n6_adj_1590), 
         .Z(n10706)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1084[15:58])
    defparam i4_4_lut_adj_397.init = 16'h8000;
    LUT4 i1_2_lut_adj_398 (.A(THO[0]), .B(THO[3]), .Z(n6_adj_1590)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1084[15:58])
    defparam i1_2_lut_adj_398.init = 16'h8888;
    LUT4 PCLK_I_0_2_lut_rep_271 (.A(n12292), .B(SH2), .Z(Clk_enable_208)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1126[12:22])
    defparam PCLK_I_0_2_lut_rep_271.init = 16'h8888;
    LUT4 ATR_IN0_2__N_1354_I_0_356_2_lut_3_lut (.A(n12292), .B(SH2), .C(SEL_LATCH[1]), 
         .Z(ATR_IN1_2__N_1355)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1126[12:22])
    defparam ATR_IN0_2__N_1354_I_0_356_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__I_364_2_lut_3_lut (.A(n12292), .B(SH2), .C(SEL_LATCH[0]), 
         .Z(ATR_IN0_2__N_1353)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1126[12:22])
    defparam ATR_IN0_2__I_364_2_lut_3_lut.init = 16'h8080;
    LUT4 NBFVO1_I_0_i2_4_lut (.A(\TVO[4] ), .B(TP_c[8]), .C(n11762), .D(n11794), 
         .Z(PAMUX[9])) /* synthesis lut_function=(A (B+!(C))+!A (B (C+(D))+!B !(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1107[22:98])
    defparam NBFVO1_I_0_i2_4_lut.init = 16'hcfca;
    LUT4 ATR_IN0_2__N_1354_I_0_357_2_lut_3_lut (.A(n12292), .B(SH2), .C(SEL_LATCH[2]), 
         .Z(ATR_IN2_2__N_1356)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1126[12:22])
    defparam ATR_IN0_2__N_1354_I_0_357_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__N_1354_I_0_358_2_lut_3_lut (.A(n12292), .B(SH2), .C(SEL_LATCH[3]), 
         .Z(ATR_IN3_2__N_1357)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1126[12:22])
    defparam ATR_IN0_2__N_1354_I_0_358_2_lut_3_lut.init = 16'h8080;
    LUT4 NBFVO1_I_0_i1_4_lut (.A(\TVO[3] ), .B(TP_c[7]), .C(n11762), .D(n11794), 
         .Z(PAMUX[8])) /* synthesis lut_function=(A (B+!(C))+!A (B (C+(D))+!B !(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1107[22:98])
    defparam NBFVO1_I_0_i1_4_lut.init = 16'hcfca;
    LUT4 ATR_IN0_2__N_1354_I_0_359_2_lut_3_lut (.A(n12292), .B(SH2), .C(SEL_LATCH[4]), 
         .Z(ATR_IN4_2__N_1358)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1126[12:22])
    defparam ATR_IN0_2__N_1354_I_0_359_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__N_1354_I_0_360_2_lut_3_lut (.A(n12292), .B(SH2), .C(SEL_LATCH[5]), 
         .Z(ATR_IN5_2__N_1359)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1126[12:22])
    defparam ATR_IN0_2__N_1354_I_0_360_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__N_1354_I_0_361_2_lut_3_lut (.A(n12292), .B(SH2), .C(SEL_LATCH[6]), 
         .Z(ATR_IN6_2__N_1360)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1126[12:22])
    defparam ATR_IN0_2__N_1354_I_0_361_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__N_1354_I_0_2_lut_3_lut (.A(n12292), .B(SH2), .C(SEL_LATCH[7]), 
         .Z(ATR_IN7_2__N_1361)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1126[12:22])
    defparam ATR_IN0_2__N_1354_I_0_2_lut_3_lut.init = 16'h8080;
    LUT4 TH_4__I_223_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[1]), .D(DBIN[4]), 
         .Z(TH_4__N_783)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1112[50:85])
    defparam TH_4__I_223_4_lut.init = 16'heca0;
    LUT4 PAMUX_7__I_243_i8_4_lut (.A(\TVO[2] ), .B(TP_c[6]), .C(n11762), 
         .D(n11794), .Z(PAMUX_7__N_844[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C+(D))+!B !(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1106[43:128])
    defparam PAMUX_7__I_243_i8_4_lut.init = 16'hcfca;
    LUT4 i5289_3_lut_4_lut (.A(n11814), .B(n12292), .C(TV[3]), .D(CNT1_adj_1591), 
         .Z(n5794)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1074[18:59])
    defparam i5289_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5291_3_lut_4_lut (.A(n11814), .B(n12292), .C(TV[2]), .D(CNT1_adj_1592), 
         .Z(n5796)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1074[18:59])
    defparam i5291_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5023_3_lut_4_lut (.A(n11814), .B(n12292), .C(FV[1]), .D(n5527), 
         .Z(n5528)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1074[18:59])
    defparam i5023_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4754_3_lut_4_lut (.A(n11814), .B(n12292), .C(FV[0]), .D(n5258), 
         .Z(n5259)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1074[18:59])
    defparam i4754_3_lut_4_lut.init = 16'hfd20;
    LUT4 TH_4__I_221_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[2]), .D(DBIN[5]), 
         .Z(TH_4__N_778)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1113[50:85])
    defparam TH_4__I_221_4_lut.init = 16'heca0;
    LUT4 TH_4__I_219_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[3]), .D(DBIN[6]), 
         .Z(TH_4__N_773)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1114[50:85])
    defparam TH_4__I_219_4_lut.init = 16'heca0;
    LUT4 i5089_3_lut_4_lut (.A(n11814), .B(n12292), .C(NTV), .D(n5593), 
         .Z(n5594)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1074[18:59])
    defparam i5089_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4646_3_lut_4_lut (.A(n11814), .B(n12292), .C(FV[2]), .D(n5150), 
         .Z(n5151)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1074[18:59])
    defparam i4646_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5287_3_lut_4_lut (.A(n11814), .B(n12292), .C(TV[4]), .D(CNT1_adj_1593), 
         .Z(n5792)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1074[18:59])
    defparam i5287_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5261_3_lut_4_lut (.A(n11814), .B(n12292), .C(TV[0]), .D(CNT1_adj_1594), 
         .Z(n5766)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1074[18:59])
    defparam i5261_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5259_3_lut_4_lut (.A(n11814), .B(n12292), .C(TV[1]), .D(CNT1_adj_1595), 
         .Z(n5764)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1074[18:59])
    defparam i5259_3_lut_4_lut.init = 16'hfd20;
    LUT4 I1_32_bdd_4_lut (.A(I1_32), .B(n10706), .C(n4), .D(n11800), 
         .Z(TV_IN_N_906)) /* synthesis lut_function=(A (C+(D))+!A (B (C+(D))+!B !((D)+!C))) */ ;
    defparam I1_32_bdd_4_lut.init = 16'heef0;
    LUT4 TH_4__I_216_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[4]), .D(DBIN[7]), 
         .Z(TH_4__N_766)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1115[50:85])
    defparam TH_4__I_216_4_lut.init = 16'heca0;
    LUT4 PAMUX_7__I_243_i7_4_lut (.A(TVO1), .B(TP_c[5]), .C(n11762), .D(n11794), 
         .Z(PAMUX_7__N_844[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C+(D))+!B !(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1106[43:128])
    defparam PAMUX_7__I_243_i7_4_lut.init = 16'hcfca;
    LUT4 i2_3_lut (.A(\FVO[1] ), .B(FVO[2]), .C(FVO[0]), .Z(n4)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1127[16:45])
    defparam i2_3_lut.init = 16'h8080;
    FD1P3AX OVOUT_i0_i1 (.D(OVR[1]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(OVOUT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OVOUT_i0_i1.GSR = "DISABLED";
    FD1P3AX OVOUT_i0_i2 (.D(OVR[2]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(OVOUT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OVOUT_i0_i2.GSR = "DISABLED";
    FD1P3AX OVOUT_i0_i3 (.D(OVR[3]), .SP(OVOUT_3__N_861), .CK(Clk), .Q(OVOUT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam OVOUT_i0_i3.GSR = "DISABLED";
    LUT4 i10694_2_lut (.A(Z_TV[0]), .B(Z_TV[1]), .Z(ZTV_N_921)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1077[14:36])
    defparam i10694_2_lut.init = 16'h1111;
    LUT4 NTH_I_249_4_lut (.A(W6_1), .B(W0), .C(DBIN[2]), .D(DBIN[0]), 
         .Z(NTH_N_892)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1121[50:85])
    defparam NTH_I_249_4_lut.init = 16'heca0;
    LUT4 NTV_I_252_4_lut (.A(W6_1), .B(W0), .C(DBIN[3]), .D(DBIN[1]), 
         .Z(NTV_N_899)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1122[50:85])
    defparam NTV_I_252_4_lut.init = 16'heca0;
    FD1P3IX TH__i1 (.D(TH_4__N_783), .SP(TH_4__N_769), .CD(RC), .CK(Clk), 
            .Q(TH[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TH__i1.GSR = "DISABLED";
    FD1P3IX TH__i2 (.D(TH_4__N_778), .SP(TH_4__N_769), .CD(RC), .CK(Clk), 
            .Q(TH[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TH__i2.GSR = "DISABLED";
    FD1P3IX TH__i3 (.D(TH_4__N_773), .SP(TH_4__N_769), .CD(RC), .CK(Clk), 
            .Q(TH[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TH__i3.GSR = "DISABLED";
    FD1P3IX TH__i4 (.D(TH_4__N_766), .SP(Clk_enable_514), .CD(RC), .CK(Clk), 
            .Q(TH[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam TH__i4.GSR = "DISABLED";
    LUT4 NBFVO1_I_0_i4_3_lut_4_lut (.A(\Hn[2] ), .B(n11800), .C(TP_c[10]), 
         .D(NTVDO), .Z(PAMUX[11])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1104[16:27])
    defparam NBFVO1_I_0_i4_3_lut_4_lut.init = 16'hfd20;
    LUT4 NBFVO1_I_0_i3_3_lut_4_lut (.A(\Hn[2] ), .B(n11800), .C(TP_c[9]), 
         .D(NTHDO), .Z(PAMUX[10])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1104[16:27])
    defparam NBFVO1_I_0_i3_3_lut_4_lut.init = 16'hfd20;
    LUT4 NBFVO1_I_0_i5_4_lut_4_lut (.A(\Hn[2] ), .B(n11800), .C(FVO[0]), 
         .D(TP_c[11]), .Z(PAMUX[12])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1104[16:27])
    defparam NBFVO1_I_0_i5_4_lut_4_lut.init = 16'he2c0;
    LUT4 i10839_2_lut_rep_291 (.A(n12292), .B(W62[1]), .Z(n11767)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam i10839_2_lut_rep_291.init = 16'hbbbb;
    LUT4 i1_2_lut_3_lut_adj_399 (.A(n12292), .B(W62[1]), .C(W6_2), .Z(Clk_enable_209)) /* synthesis lut_function=(A (C)+!A (B+(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam i1_2_lut_3_lut_adj_399.init = 16'hf4f4;
    PFUMX PAMUX_7__I_0_i2 (.BLUT(\PAMUX_7__N_852[1] ), .ALUT(PAMUX_7__N_844[1]), 
          .C0(n10992), .Z(PAMUX[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;
    PFUMX PAMUX_7__I_0_i3 (.BLUT(\PAMUX_7__N_852[2] ), .ALUT(PAMUX_7__N_844[2]), 
          .C0(n10992), .Z(PAMUX[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;
    PFUMX PAMUX_7__I_0_i4 (.BLUT(\PAMUX_7__N_852[3] ), .ALUT(PAMUX_7__N_844[3]), 
          .C0(n10992), .Z(PAMUX[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;
    PFUMX PAMUX_7__I_0_i5 (.BLUT(\PAMUX_7__N_852[4] ), .ALUT(PAMUX_7__N_844[4]), 
          .C0(n10992), .Z(PAMUX[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;
    PFUMX PAMUX_7__I_0_i6 (.BLUT(\PAMUX_7__N_852[5] ), .ALUT(PAMUX_7__N_844[5]), 
          .C0(n10992), .Z(PAMUX[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;
    PFUMX PAMUX_7__I_0_i1 (.BLUT(\PAMUX_7__N_852[0] ), .ALUT(PAMUX_7__N_844[0]), 
          .C0(n10992), .Z(PAMUX[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;
    LUT4 TH_4__I_225_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[0]), .D(DBIN[3]), 
         .Z(TH_4__N_788)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1111[50:85])
    defparam TH_4__I_225_4_lut.init = 16'heca0;
    FD1P3IX PAD_i0_i13 (.D(NBFVO1), .SP(Clk_enable_549), .CD(n5786), .CK(Clk), 
            .Q(PA13_c_13)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=327, LSE_RLINE=362 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam PAD_i0_i13.GSR = "DISABLED";
    FD1P3IX NTH_237 (.D(NTH_N_892), .SP(Clk_enable_538), .CD(RC), .CK(Clk), 
            .Q(NTH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam NTH_237.GSR = "DISABLED";
    FD1P3IX NTV_238 (.D(NTV_N_899), .SP(Clk_enable_538), .CD(RC), .CK(Clk), 
            .Q(NTV));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1110[8] 1154[26])
    defparam NTV_238.GSR = "DISABLED";
    LUT4 BGSEL_I_0_3_lut (.A(BGSEL), .B(TP_11__N_863), .C(PAR_O), .Z(TP_11__N_862)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1149[20:74])
    defparam BGSEL_I_0_3_lut.init = 16'hcaca;
    LUT4 OBSEL_I_0_3_lut (.A(OBSEL), .B(OBOUT[0]), .C(O8_16), .Z(TP_11__N_863)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1149[30:63])
    defparam OBSEL_I_0_3_lut.init = 16'hcaca;
    LUT4 mux_199_i3_3_lut (.A(PDOUT[3]), .B(OBOUT[3]), .C(PAR_O), .Z(TP_11__N_864[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1148[20:53])
    defparam mux_199_i3_3_lut.init = 16'hcaca;
    COUNTER_U81 TVCNT_4 (.CNT1(CNT1_adj_1593), .Clk(Clk), .Clk_enable_513(Clk_enable_513), 
            .CNT1_N_558({CNT1_N_558_adj_1607}), .\TVO[4] (\TVO[4] ), .Clk_enable_552(Clk_enable_552), 
            .ZTV_N_921(ZTV_N_921), .n5792(n5792)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1095[9:115])
    COUNTER_U82 TVCNT_3 (.CNT1(CNT1_adj_1591), .Clk(Clk), .Clk_enable_564(Clk_enable_564), 
            .CNT1_N_558({CNT1_N_558_adj_1608}), .n12292(n12292), .n11814(n11814), 
            .n11786(n11786), .E_EV(E_EV), .Clk_enable_552(Clk_enable_552), 
            .\TVO[3] (\TVO[3] ), .ZTV_N_921(ZTV_N_921), .n5794(n5794)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1095[9:115])
    COUNTER_U83 TVCNT_2 (.CNT1(CNT1_adj_1592), .Clk(Clk), .Clk_enable_564(Clk_enable_564), 
            .CNT1_N_558({CNT1_N_558_adj_1609}), .\TVO[2] (\TVO[2] ), .n11801(n11801), 
            .\TVO[3] (\TVO[3] ), .\TVO[4] (\TVO[4] ), .CNT1_N_558_adj_20({CNT1_N_558_adj_1607}), 
            .Clk_enable_552(Clk_enable_552), .ZTV_N_921(ZTV_N_921), .n5796(n5796)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1095[9:115])
    COUNTER_U84 TVCNT_1 (.TVO1(TVO1), .n11841(n11841), .\TVO[3] (\TVO[3] ), 
            .\TVO[2] (\TVO[2] ), .CNT1_N_558({CNT1_N_558_adj_1608}), .CNT1(CNT1_adj_1595), 
            .Clk(Clk), .Clk_enable_513(Clk_enable_513), .CNT1_N_558_adj_18({CNT1_N_558_adj_1610}), 
            .Clk_enable_552(Clk_enable_552), .ZTV_N_921(ZTV_N_921), .n5764(n5764)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1095[9:115])
    COUNTER_U85 TVCNT_0 (.CNT1(CNT1_adj_1594), .Clk(Clk), .Clk_enable_564(Clk_enable_564), 
            .\TVO[0] (\TVO[0] ), .TV_IN(TV_IN), .n11841(n11841), .TVO1(TVO1), 
            .n11801(n11801), .CNT1_N_558({CNT1_N_558_adj_1610}), .\TVO[2] (\TVO[2] ), 
            .CNT1_N_558_adj_16({CNT1_N_558_adj_1609}), .Clk_enable_552(Clk_enable_552), 
            .ZTV_N_921(ZTV_N_921), .n5766(n5766)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1095[9:115])
    COUNTER_U86 THCNT_4 (.Clk(Clk), .Clk_enable_367(Clk_enable_367), .CNT1_N_558({CNT1_N_558_adj_1611}), 
            .\THO[4] (THO[4]), .\TH[4] (TH[4]), .THLOAD_N_909(THLOAD_N_909), 
            .THSTEP_N_916(THSTEP_N_916)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1094[9:115])
    COUNTER_U87 THCNT_3 (.Clk(Clk), .Clk_enable_564(Clk_enable_564), .CNT1_N_558({CNT1_N_558_adj_1612}), 
            .\THO[3] (THO[3]), .\TH[3] (TH[3]), .THLOAD_N_909(THLOAD_N_909), 
            .THSTEP_N_916(THSTEP_N_916)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1094[9:115])
    COUNTER_U88 THCNT_2 (.\THO[2] (THO[2]), .n11705(n11705), .\THO[3] (THO[3]), 
            .\THO[4] (THO[4]), .CNT1_N_558({CNT1_N_558_adj_1611}), .Clk(Clk), 
            .Clk_enable_564(Clk_enable_564), .CNT1_N_558_adj_14({CNT1_N_558_adj_1613}), 
            .\TH[2] (TH[2]), .THLOAD_N_909(THLOAD_N_909), .THSTEP_N_916(THSTEP_N_916)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1094[9:115])
    COUNTER_U89 THCNT_1 (.Clk(Clk), .Clk_enable_564(Clk_enable_564), .CNT1_N_558({CNT1_N_558_c}), 
            .\TH[1] (TH[1]), .THLOAD_N_909(THLOAD_N_909), .\THO[1] (THO[1]), 
            .THSTEP_N_916(THSTEP_N_916), .n11729(n11729), .\THO[3] (THO[3]), 
            .\THO[2] (THO[2]), .CNT1_N_558_adj_12({CNT1_N_558_adj_1612})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1094[9:115])
    COUNTER_U90 THCNT_0 (.\TH[0] (TH[0]), .THLOAD_N_909(THLOAD_N_909), .\THO[0] (THO[0]), 
            .THSTEP_N_916(THSTEP_N_916), .n11772(n11772), .\THO[2] (THO[2]), 
            .\THO[1] (THO[1]), .CNT1_N_558({CNT1_N_558_adj_1613}), .Clk(Clk), 
            .Clk_enable_549(Clk_enable_549), .CNT1_N_558_adj_10({CNT1_N_558})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1094[9:115])
    COUNTER_U91 NTVCNT (.CNT1(CNT1), .Clk(Clk), .Clk_enable_549(Clk_enable_549), 
            .NTVDO(NTVDO), .n5594(n5594), .NTV_IN(NTV_IN)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1097[9:107])
    COUNTER_U92 NTHCNT (.Clk(Clk), .Clk_enable_564(Clk_enable_564), .NTHDO(NTHDO), 
            .n11800(n11800), .TVZB(TVZB), .n10706(n10706), .NTH(NTH), 
            .THLOAD_N_909(THLOAD_N_909), .THSTEP_N_916(THSTEP_N_916)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1096[9:107])
    COUNTER_U93 FVCNT_2 (.CNT1(CNT1_adj_1589), .Clk(Clk), .Clk_enable_513(Clk_enable_513), 
            .CNT1_N_558({CNT1_N_558_adj_1615}), .\FVO[2] (FVO[2]), .n5151(n5151)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1098[9:115])
    COUNTER_U94 FVCNT_1 (.CNT1(CNT1_adj_1588), .Clk(Clk), .Clk_enable_564(Clk_enable_564), 
            .CNT1_N_558({CNT1_N_558_adj_1616}), .\FVO[1] (\FVO[1] ), .n5528(n5528)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1098[9:115])
    COUNTER_U95 FVCNT_0 (.CNT1(CNT1_adj_1587), .Clk(Clk), .Clk_enable_564(Clk_enable_564), 
            .CNT1_N_558({CNT1_N_558_adj_1606}), .FVO({FVO[2], \FVO[1] , 
            FVO[0]}), .n5259(n5259), .n11724(n11724), .CNT1_N_558_adj_7({CNT1_N_558_adj_1616}), 
            .CNT1_N_558_adj_8({CNT1_N_558_adj_1615})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1098[9:115])
    
endmodule
//
// Verilog Description of module COUNTER_U81
//

module COUNTER_U81 (CNT1, Clk, Clk_enable_513, CNT1_N_558, \TVO[4] , 
            Clk_enable_552, ZTV_N_921, n5792) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_513;
    input [0:0]CNT1_N_558;
    output \TVO[4] ;
    input Clk_enable_552;
    input ZTV_N_921;
    input n5792;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_513), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(n5792), .SP(Clk_enable_552), .CK(Clk), .CD(ZTV_N_921), 
            .Q(\TVO[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U82
//

module COUNTER_U82 (CNT1, Clk, Clk_enable_564, CNT1_N_558, n12292, 
            n11814, n11786, E_EV, Clk_enable_552, \TVO[3] , ZTV_N_921, 
            n5794) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_564;
    input [0:0]CNT1_N_558;
    input n12292;
    input n11814;
    input n11786;
    input E_EV;
    output Clk_enable_552;
    output \TVO[3] ;
    input ZTV_N_921;
    input n5794;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_564), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i10890_3_lut_4_lut_4_lut (.A(n12292), .B(n11814), .C(n11786), 
         .D(E_EV), .Z(Clk_enable_552)) /* synthesis lut_function=(!(A+!(B+(C+(D))))) */ ;
    defparam i10890_3_lut_4_lut_4_lut.init = 16'h5554;
    FD1P3DX CNT_14 (.D(n5794), .SP(Clk_enable_552), .CK(Clk), .CD(ZTV_N_921), 
            .Q(\TVO[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U83
//

module COUNTER_U83 (CNT1, Clk, Clk_enable_564, CNT1_N_558, \TVO[2] , 
            n11801, \TVO[3] , \TVO[4] , CNT1_N_558_adj_20, Clk_enable_552, 
            ZTV_N_921, n5796) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_564;
    input [0:0]CNT1_N_558;
    output \TVO[2] ;
    input n11801;
    input \TVO[3] ;
    input \TVO[4] ;
    output [0:0]CNT1_N_558_adj_20;
    input Clk_enable_552;
    input ZTV_N_921;
    input n5796;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_564), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1800_3_lut_4_lut (.A(\TVO[2] ), .B(n11801), .C(\TVO[3] ), .D(\TVO[4] ), 
         .Z(CNT1_N_558_adj_20[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1800_3_lut_4_lut.init = 16'h7f80;
    FD1P3DX CNT_14 (.D(n5796), .SP(Clk_enable_552), .CK(Clk), .CD(ZTV_N_921), 
            .Q(\TVO[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U84
//

module COUNTER_U84 (TVO1, n11841, \TVO[3] , \TVO[2] , CNT1_N_558, 
            CNT1, Clk, Clk_enable_513, CNT1_N_558_adj_18, Clk_enable_552, 
            ZTV_N_921, n5764) /* synthesis syn_module_defined=1 */ ;
    output TVO1;
    input n11841;
    input \TVO[3] ;
    input \TVO[2] ;
    output [0:0]CNT1_N_558;
    output CNT1;
    input Clk;
    input Clk_enable_513;
    input [0:0]CNT1_N_558_adj_18;
    input Clk_enable_552;
    input ZTV_N_921;
    input n5764;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    LUT4 i1807_2_lut_3_lut_4_lut (.A(TVO1), .B(n11841), .C(\TVO[3] ), 
         .D(\TVO[2] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1807_2_lut_3_lut_4_lut.init = 16'h78f0;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_18[0]), .SP(Clk_enable_513), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(n5764), .SP(Clk_enable_552), .CK(Clk), .CD(ZTV_N_921), 
            .Q(TVO1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U85
//

module COUNTER_U85 (CNT1, Clk, Clk_enable_564, \TVO[0] , TV_IN, n11841, 
            TVO1, n11801, CNT1_N_558, \TVO[2] , CNT1_N_558_adj_16, 
            Clk_enable_552, ZTV_N_921, n5766) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_564;
    output \TVO[0] ;
    input TV_IN;
    output n11841;
    input TVO1;
    output n11801;
    output [0:0]CNT1_N_558;
    input \TVO[2] ;
    output [0:0]CNT1_N_558_adj_16;
    input Clk_enable_552;
    input ZTV_N_921;
    input n5766;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558_c[0]), .SP(Clk_enable_564), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut_rep_365 (.A(\TVO[0] ), .B(TV_IN), .Z(n11841)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam CNT_I_0_2_lut_rep_365.init = 16'h8888;
    LUT4 CNT_I_0_2_lut_rep_325_3_lut (.A(\TVO[0] ), .B(TV_IN), .C(TVO1), 
         .Z(n11801)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam CNT_I_0_2_lut_rep_325_3_lut.init = 16'h8080;
    LUT4 i1821_2_lut_3_lut (.A(\TVO[0] ), .B(TV_IN), .C(TVO1), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1821_2_lut_3_lut.init = 16'h7878;
    LUT4 i1814_2_lut_3_lut_4_lut (.A(\TVO[0] ), .B(TV_IN), .C(\TVO[2] ), 
         .D(TVO1), .Z(CNT1_N_558_adj_16[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1814_2_lut_3_lut_4_lut.init = 16'h78f0;
    LUT4 i1828_2_lut (.A(\TVO[0] ), .B(TV_IN), .Z(CNT1_N_558_c[0])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1663[26:36])
    defparam i1828_2_lut.init = 16'h6666;
    FD1P3DX CNT_14 (.D(n5766), .SP(Clk_enable_552), .CK(Clk), .CD(ZTV_N_921), 
            .Q(\TVO[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U86
//

module COUNTER_U86 (Clk, Clk_enable_367, CNT1_N_558, \THO[4] , \TH[4] , 
            THLOAD_N_909, THSTEP_N_916) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_367;
    input [0:0]CNT1_N_558;
    output \THO[4] ;
    input \TH[4] ;
    input THLOAD_N_909;
    input THSTEP_N_916;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1, n5143, n5142;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_367), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n5143), .CK(Clk), .Q(\THO[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i4638_3_lut (.A(n5142), .B(\TH[4] ), .C(THLOAD_N_909), .Z(n5143)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam i4638_3_lut.init = 16'hacac;
    LUT4 i4637_3_lut (.A(\THO[4] ), .B(CNT1), .C(THSTEP_N_916), .Z(n5142)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam i4637_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U87
//

module COUNTER_U87 (Clk, Clk_enable_564, CNT1_N_558, \THO[3] , \TH[3] , 
            THLOAD_N_909, THSTEP_N_916) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_564;
    input [0:0]CNT1_N_558;
    output \THO[3] ;
    input \TH[3] ;
    input THLOAD_N_909;
    input THSTEP_N_916;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1, n5444, n5443;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_564), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n5444), .CK(Clk), .Q(\THO[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i4939_3_lut (.A(n5443), .B(\TH[3] ), .C(THLOAD_N_909), .Z(n5444)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam i4939_3_lut.init = 16'hacac;
    LUT4 i4938_3_lut (.A(\THO[3] ), .B(CNT1), .C(THSTEP_N_916), .Z(n5443)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam i4938_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U88
//

module COUNTER_U88 (\THO[2] , n11705, \THO[3] , \THO[4] , CNT1_N_558, 
            Clk, Clk_enable_564, CNT1_N_558_adj_14, \TH[2] , THLOAD_N_909, 
            THSTEP_N_916) /* synthesis syn_module_defined=1 */ ;
    output \THO[2] ;
    input n11705;
    input \THO[3] ;
    input \THO[4] ;
    output [0:0]CNT1_N_558;
    input Clk;
    input Clk_enable_564;
    input [0:0]CNT1_N_558_adj_14;
    input \TH[2] ;
    input THLOAD_N_909;
    input THSTEP_N_916;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1, n5612, n5611;
    
    LUT4 i1765_3_lut_4_lut (.A(\THO[2] ), .B(n11705), .C(\THO[3] ), .D(\THO[4] ), 
         .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1765_3_lut_4_lut.init = 16'h7f80;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_14[0]), .SP(Clk_enable_564), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n5612), .CK(Clk), .Q(\THO[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i5107_3_lut (.A(n5611), .B(\TH[2] ), .C(THLOAD_N_909), .Z(n5612)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam i5107_3_lut.init = 16'hacac;
    LUT4 i5106_3_lut (.A(\THO[2] ), .B(CNT1), .C(THSTEP_N_916), .Z(n5611)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam i5106_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U89
//

module COUNTER_U89 (Clk, Clk_enable_564, CNT1_N_558, \TH[1] , THLOAD_N_909, 
            \THO[1] , THSTEP_N_916, n11729, \THO[3] , \THO[2] , CNT1_N_558_adj_12) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_564;
    input [0:0]CNT1_N_558;
    input \TH[1] ;
    input THLOAD_N_909;
    output \THO[1] ;
    input THSTEP_N_916;
    input n11729;
    input \THO[3] ;
    input \THO[2] ;
    output [0:0]CNT1_N_558_adj_12;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1, n5262, n5263;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_564), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i4758_3_lut (.A(n5262), .B(\TH[1] ), .C(THLOAD_N_909), .Z(n5263)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam i4758_3_lut.init = 16'hacac;
    LUT4 i4757_3_lut (.A(\THO[1] ), .B(CNT1), .C(THSTEP_N_916), .Z(n5262)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam i4757_3_lut.init = 16'hacac;
    FD1S3AX CNT_14 (.D(n5263), .CK(Clk), .Q(\THO[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1772_2_lut_3_lut_4_lut (.A(\THO[1] ), .B(n11729), .C(\THO[3] ), 
         .D(\THO[2] ), .Z(CNT1_N_558_adj_12[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1772_2_lut_3_lut_4_lut.init = 16'h78f0;
    
endmodule
//
// Verilog Description of module COUNTER_U90
//

module COUNTER_U90 (\TH[0] , THLOAD_N_909, \THO[0] , THSTEP_N_916, n11772, 
            \THO[2] , \THO[1] , CNT1_N_558, Clk, Clk_enable_549, CNT1_N_558_adj_10) /* synthesis syn_module_defined=1 */ ;
    input \TH[0] ;
    input THLOAD_N_909;
    output \THO[0] ;
    input THSTEP_N_916;
    input n11772;
    input \THO[2] ;
    input \THO[1] ;
    output [0:0]CNT1_N_558;
    input Clk;
    input Clk_enable_549;
    input [0:0]CNT1_N_558_adj_10;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire n5254, n5255, CNT1;
    
    LUT4 i4750_3_lut (.A(n5254), .B(\TH[0] ), .C(THLOAD_N_909), .Z(n5255)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam i4750_3_lut.init = 16'hacac;
    LUT4 i4749_3_lut (.A(\THO[0] ), .B(CNT1), .C(THSTEP_N_916), .Z(n5254)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam i4749_3_lut.init = 16'hacac;
    LUT4 i1779_2_lut_3_lut_4_lut (.A(\THO[0] ), .B(n11772), .C(\THO[2] ), 
         .D(\THO[1] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(A (B (C)+!B !(C (D)+!C !(D)))+!A (C)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1779_2_lut_3_lut_4_lut.init = 16'hd2f0;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_10[0]), .SP(Clk_enable_549), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n5255), .CK(Clk), .Q(\THO[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U91
//

module COUNTER_U91 (CNT1, Clk, Clk_enable_549, NTVDO, n5594, NTV_IN) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_549;
    output NTVDO;
    input n5594;
    input NTV_IN;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [0:0]CNT1_N_558;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_549), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n5594), .CK(Clk), .Q(NTVDO));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1842_2_lut (.A(NTVDO), .B(NTV_IN), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1663[26:36])
    defparam i1842_2_lut.init = 16'h6666;
    
endmodule
//
// Verilog Description of module COUNTER_U92
//

module COUNTER_U92 (Clk, Clk_enable_564, NTHDO, n11800, TVZB, n10706, 
            NTH, THLOAD_N_909, THSTEP_N_916) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_564;
    output NTHDO;
    input n11800;
    input TVZB;
    input n10706;
    input NTH;
    input THLOAD_N_909;
    input THSTEP_N_916;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    wire [0:0]CNT1_N_558;
    
    wire n5610, n5609;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_564), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n5610), .CK(Clk), .Q(NTHDO));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1835_4_lut (.A(NTHDO), .B(n11800), .C(TVZB), .D(n10706), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A (B (C)+!B (C+(D)))+!A !(B (C)+!B (C+(D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1663[26:36])
    defparam i1835_4_lut.init = 16'h595a;
    LUT4 i5105_3_lut (.A(n5609), .B(NTH), .C(THLOAD_N_909), .Z(n5610)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam i5105_3_lut.init = 16'hacac;
    LUT4 i5104_3_lut (.A(NTHDO), .B(CNT1), .C(THSTEP_N_916), .Z(n5609)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam i5104_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U93
//

module COUNTER_U93 (CNT1, Clk, Clk_enable_513, CNT1_N_558, \FVO[2] , 
            n5151) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_513;
    input [0:0]CNT1_N_558;
    output \FVO[2] ;
    input n5151;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_513), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n5151), .CK(Clk), .Q(\FVO[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U94
//

module COUNTER_U94 (CNT1, Clk, Clk_enable_564, CNT1_N_558, \FVO[1] , 
            n5528) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_564;
    input [0:0]CNT1_N_558;
    output \FVO[1] ;
    input n5528;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_564), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n5528), .CK(Clk), .Q(\FVO[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U95
//

module COUNTER_U95 (CNT1, Clk, Clk_enable_564, CNT1_N_558, FVO, n5259, 
            n11724, CNT1_N_558_adj_7, CNT1_N_558_adj_8) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_564;
    input [0:0]CNT1_N_558;
    input [2:0]FVO;
    input n5259;
    input n11724;
    output [0:0]CNT1_N_558_adj_7;
    output [0:0]CNT1_N_558_adj_8;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_564), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n5259), .CK(Clk), .Q(FVO[0]));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1856_2_lut_3_lut (.A(FVO[0]), .B(n11724), .C(FVO[1]), .Z(CNT1_N_558_adj_7[0])) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1856_2_lut_3_lut.init = 16'h7878;
    LUT4 i1849_3_lut_4_lut (.A(FVO[0]), .B(n11724), .C(FVO[1]), .D(FVO[2]), 
         .Z(CNT1_N_558_adj_8[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1849_3_lut_4_lut.init = 16'h7f80;
    
endmodule
//
// Verilog Description of module OAM
//

module OAM (ORES_LATCH, Clk, Clk_enable_562, nEVAL, OVF_LATCH, OMFG_LATCH, 
            OMFG, OMV_LATCH, OB2_7__N_1036, OB, Clk_enable_564, OSTEP, 
            n11692, I_OAM2, \W4Q[4] , \W4Q[2] , OMSTEP_1__N_1046, 
            PAR_O, \Hn[0] , \Hn[2] , n4430, \Hnn[0] , n10, n12292, 
            \R2DB[0] , n4641, SPR_OV, n10489, OAMCTR2, n11741, W4, 
            n11830, W3, Clk_enable_563, n11800, OAP_N_1084, \OAM1ADR[0] , 
            n5755, GND_net, OAMQ_7__N_1034, DBIN, n11691, CNT_7__N_1133, 
            n5745, n7695, \CNT1[0] , Clk_enable_423, OAM2STEP_N_1097, 
            ORES, Clk_enable_185, Clk_enable_530) /* synthesis syn_module_defined=1 */ ;
    output ORES_LATCH;
    input Clk;
    input Clk_enable_562;
    input nEVAL;
    output OVF_LATCH;
    output OMFG_LATCH;
    input OMFG;
    output OMV_LATCH;
    input OB2_7__N_1036;
    output [7:0]OB;
    input Clk_enable_564;
    output [2:0]OSTEP;
    input n11692;
    input I_OAM2;
    output \W4Q[4] ;
    output \W4Q[2] ;
    input OMSTEP_1__N_1046;
    input PAR_O;
    input \Hn[0] ;
    input \Hn[2] ;
    output n4430;
    input \Hnn[0] ;
    input n10;
    input n12292;
    output \R2DB[0] ;
    input n4641;
    output SPR_OV;
    input n10489;
    output OAMCTR2;
    input n11741;
    input W4;
    output n11830;
    input W3;
    output Clk_enable_563;
    input n11800;
    input OAP_N_1084;
    output \OAM1ADR[0] ;
    input n5755;
    input GND_net;
    input OAMQ_7__N_1034;
    input [7:0]DBIN;
    input n11691;
    input CNT_7__N_1133;
    input n5745;
    input n7695;
    output \CNT1[0] ;
    input Clk_enable_423;
    input OAM2STEP_N_1097;
    input ORES;
    input Clk_enable_185;
    input Clk_enable_530;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire OAMCTR2_N_1054, OMV_LATCH_N_1068, TMV_LATCH, C_OUT_N_556;
    wire [7:0]OAM1ADR;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1262[11:18])
    
    wire n11817, n11711;
    wire [7:0]OB2;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1246[10:13])
    wire [1:0]OMSTEP;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1240[10:16])
    
    wire OFETCH_N_1083;
    wire [4:0]W4Q;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1239[10:13])
    
    wire W4Q_2__N_1012, OSTEP_2__N_1052;
    wire [2:0]OSTEP_c;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1242[10:15])
    
    wire n11838, W4Q_2__N_1007, OAM2STEP_N_1107, WE, n11787, n11751, 
        Clk_enable_219, W4FF, Clk_enable_223, n4;
    wire [7:0]OAM1Cout;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1683[11:19])
    wire [7:0]CNT1_7__N_1135;
    wire [7:0]OAMQ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1270[11:15])
    wire [7:0]OAM2Q;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1270[17:22])
    wire [7:0]n115;
    
    wire OBDZ_2__N_1031, OAM1ADR_0__N_1033, n4183;
    wire [0:0]CNT1_N_558;
    wire [4:0]OAM2ADR;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1261[11:18])
    wire [0:0]CNT1_N_558_adj_1566;
    
    wire n11813;
    wire [0:0]CNT1_N_558_adj_1567;
    
    FD1P3AX ORES_LATCH_123 (.D(nEVAL), .SP(Clk_enable_562), .CK(Clk), 
            .Q(ORES_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam ORES_LATCH_123.GSR = "DISABLED";
    FD1P3AX OVF_LATCH_124 (.D(OAMCTR2_N_1054), .SP(Clk_enable_562), .CK(Clk), 
            .Q(OVF_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OVF_LATCH_124.GSR = "DISABLED";
    FD1P3AX OMFG_LATCH_125 (.D(OMFG), .SP(Clk_enable_562), .CK(Clk), .Q(OMFG_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OMFG_LATCH_125.GSR = "DISABLED";
    FD1P3AX OMV_LATCH_126 (.D(OMV_LATCH_N_1068), .SP(Clk_enable_562), .CK(Clk), 
            .Q(OMV_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OMV_LATCH_126.GSR = "DISABLED";
    FD1P3AX TMV_LATCH_127 (.D(C_OUT_N_556), .SP(Clk_enable_562), .CK(Clk), 
            .Q(TMV_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam TMV_LATCH_127.GSR = "DISABLED";
    LUT4 i1_2_lut_rep_235_3_lut_4_lut (.A(OAM1ADR[4]), .B(n11817), .C(OAM1ADR[6]), 
         .D(OAM1ADR[5]), .Z(n11711)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1293[30:43])
    defparam i1_2_lut_rep_235_3_lut_4_lut.init = 16'h8000;
    FD1P3AX OB2_i0_i0 (.D(OB[0]), .SP(OB2_7__N_1036), .CK(Clk), .Q(OB2[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB2_i0_i0.GSR = "DISABLED";
    FD1P3AX OMSTEP_i0_i0 (.D(OFETCH_N_1083), .SP(Clk_enable_562), .CK(Clk), 
            .Q(OMSTEP[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OMSTEP_i0_i0.GSR = "DISABLED";
    FD1P3AX W4Q_i0 (.D(W4Q_2__N_1012), .SP(Clk_enable_564), .CK(Clk), 
            .Q(W4Q[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam W4Q_i0.GSR = "DISABLED";
    FD1P3AX OSTEP_i0_i0 (.D(OSTEP_2__N_1052), .SP(Clk_enable_562), .CK(Clk), 
            .Q(OSTEP[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OSTEP_i0_i0.GSR = "DISABLED";
    FD1P3AX OSTEP_i0_i2 (.D(n11692), .SP(Clk_enable_562), .CK(Clk), .Q(OSTEP_c[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OSTEP_i0_i2.GSR = "DISABLED";
    FD1P3AX OSTEP_i0_i1 (.D(I_OAM2), .SP(Clk_enable_562), .CK(Clk), .Q(OSTEP_c[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OSTEP_i0_i1.GSR = "DISABLED";
    FD1P3AX W4Q_i4 (.D(n11838), .SP(Clk_enable_564), .CK(Clk), .Q(\W4Q[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam W4Q_i4.GSR = "DISABLED";
    FD1P3AX W4Q_i3 (.D(W4Q_2__N_1007), .SP(Clk_enable_562), .CK(Clk), 
            .Q(W4Q[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam W4Q_i3.GSR = "DISABLED";
    FD1P3AX W4Q_i2 (.D(W4Q[1]), .SP(Clk_enable_564), .CK(Clk), .Q(\W4Q[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam W4Q_i2.GSR = "DISABLED";
    FD1P3AX W4Q_i1 (.D(W4Q[0]), .SP(Clk_enable_562), .CK(Clk), .Q(W4Q[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam W4Q_i1.GSR = "DISABLED";
    FD1P3AX OMSTEP_i0_i1 (.D(OMSTEP_1__N_1046), .SP(Clk_enable_562), .CK(Clk), 
            .Q(OMSTEP[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OMSTEP_i0_i1.GSR = "DISABLED";
    LUT4 i1_4_lut (.A(PAR_O), .B(\Hn[0] ), .C(\Hn[2] ), .D(OAM2STEP_N_1107), 
         .Z(n4430)) /* synthesis lut_function=(A (B (C)+!B !((D)+!C))+!A (B+!(D))) */ ;
    defparam i1_4_lut.init = 16'hc4f5;
    LUT4 OSTEP_1__I_0_2_lut (.A(OSTEP_c[1]), .B(OSTEP_c[2]), .Z(OAM2STEP_N_1107)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1258[72:95])
    defparam OSTEP_1__I_0_2_lut.init = 16'heeee;
    FD1P3AX OB2_i0_i7 (.D(OB[7]), .SP(OB2_7__N_1036), .CK(Clk), .Q(OB2[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB2_i0_i7.GSR = "DISABLED";
    FD1P3AX OB2_i0_i6 (.D(OB[6]), .SP(OB2_7__N_1036), .CK(Clk), .Q(OB2[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB2_i0_i6.GSR = "DISABLED";
    FD1P3AX OB2_i0_i5 (.D(OB[5]), .SP(OB2_7__N_1036), .CK(Clk), .Q(OB2[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB2_i0_i5.GSR = "DISABLED";
    FD1P3AX OB2_i0_i4 (.D(OB[4]), .SP(OB2_7__N_1036), .CK(Clk), .Q(OB2[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB2_i0_i4.GSR = "DISABLED";
    FD1P3AX OB2_i0_i3 (.D(OB[3]), .SP(OB2_7__N_1036), .CK(Clk), .Q(OB2[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB2_i0_i3.GSR = "DISABLED";
    FD1P3AX OB2_i0_i2 (.D(OB[2]), .SP(OB2_7__N_1036), .CK(Clk), .Q(OB2[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB2_i0_i2.GSR = "DISABLED";
    FD1P3AX OB2_i0_i1 (.D(OB[1]), .SP(OB2_7__N_1036), .CK(Clk), .Q(OB2[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB2_i0_i1.GSR = "DISABLED";
    LUT4 i10711_4_lut (.A(\Hnn[0] ), .B(OFETCH_N_1083), .C(n10), .D(n12292), 
         .Z(WE)) /* synthesis lut_function=(A (B+!(C+(D)))+!A (B)) */ ;
    defparam i10711_4_lut.init = 16'hccce;
    LUT4 i1_2_lut_rep_341 (.A(OAM1ADR[2]), .B(OAM1ADR[3]), .Z(n11817)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1293[30:43])
    defparam i1_2_lut_rep_341.init = 16'h8888;
    LUT4 i1_2_lut_rep_311_3_lut (.A(OAM1ADR[2]), .B(OAM1ADR[3]), .C(OAM1ADR[4]), 
         .Z(n11787)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1293[30:43])
    defparam i1_2_lut_rep_311_3_lut.init = 16'h8080;
    LUT4 i1_2_lut_rep_275_3_lut_4_lut (.A(OAM1ADR[2]), .B(OAM1ADR[3]), .C(OAM1ADR[5]), 
         .D(OAM1ADR[4]), .Z(n11751)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1293[30:43])
    defparam i1_2_lut_rep_275_3_lut_4_lut.init = 16'h8000;
    FD1S3AX R2DB5_115 (.D(n4641), .CK(Clk), .Q(\R2DB[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam R2DB5_115.GSR = "DISABLED";
    FD1S3AX SPR_OV_116 (.D(n10489), .CK(Clk), .Q(SPR_OV));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam SPR_OV_116.GSR = "DISABLED";
    FD1P3AX OAMCTR2_117 (.D(n11741), .SP(Clk_enable_219), .CK(Clk), .Q(OAMCTR2));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OAMCTR2_117.GSR = "DISABLED";
    FD1P3AX W4FF_114 (.D(W4Q[3]), .SP(Clk_enable_223), .CK(Clk), .Q(W4FF));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam W4FF_114.GSR = "DISABLED";
    LUT4 i10714_2_lut (.A(\W4Q[2] ), .B(\W4Q[4] ), .Z(OFETCH_N_1083)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1251[17:38])
    defparam i10714_2_lut.init = 16'h2222;
    LUT4 i10720_2_lut (.A(W4), .B(W4FF), .Z(W4Q_2__N_1012)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1284[66:79])
    defparam i10720_2_lut.init = 16'h4444;
    LUT4 i10725_2_lut (.A(nEVAL), .B(OAMCTR2), .Z(OSTEP_2__N_1052)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1289[41:60])
    defparam i10725_2_lut.init = 16'hdddd;
    LUT4 W4Q_2__I_0_1_lut (.A(\W4Q[2] ), .Z(W4Q_2__N_1007)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1251[20:27])
    defparam W4Q_2__I_0_1_lut.init = 16'h5555;
    LUT4 OAMSTEP_I_303_2_lut_rep_354 (.A(OMSTEP[0]), .B(OMSTEP[1]), .Z(n11830)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1255[19:67])
    defparam OAMSTEP_I_303_2_lut_rep_354.init = 16'h4444;
    LUT4 i10843_2_lut_rep_226_3_lut_3_lut_4_lut (.A(OMSTEP[0]), .B(OMSTEP[1]), 
         .C(W3), .D(n12292), .Z(Clk_enable_563)) /* synthesis lut_function=(!(A (C+(D))+!A (B (C)+!B (C+(D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1255[19:67])
    defparam i10843_2_lut_rep_226_3_lut_3_lut_4_lut.init = 16'h040f;
    LUT4 W4Q_3__I_0_1_lut_rep_362 (.A(W4Q[3]), .Z(n11838)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1284[49:56])
    defparam W4Q_3__I_0_1_lut_rep_362.init = 16'h5555;
    LUT4 i1_2_lut_2_lut (.A(W4Q[3]), .B(W4), .Z(Clk_enable_223)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1284[49:56])
    defparam i1_2_lut_2_lut.init = 16'hdddd;
    LUT4 i1_4_lut_adj_395 (.A(n12292), .B(ORES_LATCH), .C(n4430), .D(n4), 
         .Z(Clk_enable_219)) /* synthesis lut_function=(!((B (C+!(D)))+!A)) */ ;
    defparam i1_4_lut_adj_395.init = 16'h2a22;
    LUT4 i1_2_lut (.A(TMV_LATCH), .B(OSTEP[0]), .Z(n4)) /* synthesis lut_function=(!((B)+!A)) */ ;
    defparam i1_2_lut.init = 16'h2222;
    LUT4 mux_14_i3_3_lut_4_lut (.A(n11692), .B(n11800), .C(OAM1Cout[1]), 
         .D(OAM1ADR[2]), .Z(CNT1_7__N_1135[2])) /* synthesis lut_function=(!(A (C (D)+!C !(D))+!A (B (C (D)+!C !(D))+!B (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1256[14:30])
    defparam mux_14_i3_3_lut_4_lut.init = 16'h0ef1;
    LUT4 mux_71_i2_3_lut (.A(OAMQ[1]), .B(OAM2Q[1]), .C(OAP_N_1084), .Z(n115[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1287[38:90])
    defparam mux_71_i2_3_lut.init = 16'hcaca;
    LUT4 mux_71_i3_4_lut (.A(OAMQ[2]), .B(OAM2Q[2]), .C(OAP_N_1084), .D(OBDZ_2__N_1031), 
         .Z(n115[2])) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1287[38:90])
    defparam mux_71_i3_4_lut.init = 16'hc0ca;
    LUT4 OAM1ADR_1__I_0_137_2_lut (.A(OAM1ADR[1]), .B(\OAM1ADR[0] ), .Z(OBDZ_2__N_1031)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1260[38:66])
    defparam OAM1ADR_1__I_0_137_2_lut.init = 16'h2222;
    LUT4 mux_71_i4_4_lut (.A(OAMQ[3]), .B(OAM2Q[3]), .C(OAP_N_1084), .D(OBDZ_2__N_1031), 
         .Z(n115[3])) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1287[38:90])
    defparam mux_71_i4_4_lut.init = 16'hc0ca;
    LUT4 mux_71_i5_4_lut (.A(OAMQ[4]), .B(OAM2Q[4]), .C(OAP_N_1084), .D(OBDZ_2__N_1031), 
         .Z(n115[4])) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1287[38:90])
    defparam mux_71_i5_4_lut.init = 16'hc0ca;
    LUT4 mux_71_i6_3_lut (.A(OAMQ[5]), .B(OAM2Q[5]), .C(OAP_N_1084), .Z(n115[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1287[38:90])
    defparam mux_71_i6_3_lut.init = 16'hcaca;
    LUT4 mux_71_i7_3_lut (.A(OAMQ[6]), .B(OAM2Q[6]), .C(OAP_N_1084), .Z(n115[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1287[38:90])
    defparam mux_71_i7_3_lut.init = 16'hcaca;
    LUT4 OAMCTR2_I_0_1_lut (.A(OAMCTR2), .Z(OAMCTR2_N_1054)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1289[51:59])
    defparam OAMCTR2_I_0_1_lut.init = 16'h5555;
    LUT4 mux_71_i8_3_lut (.A(OAMQ[7]), .B(OAM2Q[7]), .C(OAP_N_1084), .Z(n115[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1287[38:90])
    defparam mux_71_i8_3_lut.init = 16'hcaca;
    LUT4 mux_71_i1_3_lut (.A(OAMQ[0]), .B(OAM2Q[0]), .C(OAP_N_1084), .Z(n115[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1287[38:90])
    defparam mux_71_i1_3_lut.init = 16'hcaca;
    LUT4 OAM1ADR_0__I_0_1_lut (.A(\OAM1ADR[0] ), .Z(OAM1ADR_0__N_1033)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1260[53:64])
    defparam OAM1ADR_0__I_0_1_lut.init = 16'h5555;
    FD1P3JX OB_i0_i1 (.D(n115[1]), .SP(Clk_enable_562), .PD(n5755), .CK(Clk), 
            .Q(OB[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB_i0_i1.GSR = "DISABLED";
    FD1P3JX OB_i0_i2 (.D(n115[2]), .SP(Clk_enable_562), .PD(n5755), .CK(Clk), 
            .Q(OB[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB_i0_i2.GSR = "DISABLED";
    FD1P3JX OB_i0_i3 (.D(n115[3]), .SP(Clk_enable_562), .PD(n5755), .CK(Clk), 
            .Q(OB[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB_i0_i3.GSR = "DISABLED";
    FD1P3JX OB_i0_i4 (.D(n115[4]), .SP(Clk_enable_562), .PD(n5755), .CK(Clk), 
            .Q(OB[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB_i0_i4.GSR = "DISABLED";
    FD1P3JX OB_i0_i5 (.D(n115[5]), .SP(Clk_enable_562), .PD(n5755), .CK(Clk), 
            .Q(OB[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB_i0_i5.GSR = "DISABLED";
    FD1P3JX OB_i0_i6 (.D(n115[6]), .SP(Clk_enable_562), .PD(n5755), .CK(Clk), 
            .Q(OB[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB_i0_i6.GSR = "DISABLED";
    FD1P3JX OB_i0_i7 (.D(n115[7]), .SP(Clk_enable_562), .PD(n5755), .CK(Clk), 
            .Q(OB[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB_i0_i7.GSR = "DISABLED";
    FD1P3JX OB_i0_i0 (.D(n115[0]), .SP(Clk_enable_562), .PD(n5755), .CK(Clk), 
            .Q(OB[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=386, LSE_RLINE=406 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1274[8] 1296[27])
    defparam OB_i0_i0.GSR = "DISABLED";
    LUT4 i2_3_lut_4_lut (.A(OAM1ADR[6]), .B(n11751), .C(OAM1ADR[7]), .D(n4183), 
         .Z(OMV_LATCH_N_1068)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1293[30:43])
    defparam i2_3_lut_4_lut.init = 16'h8000;
    OAM_RAM OAMQ_7__I_0 (.Clk(Clk), .GND_net(GND_net), .OAMQ_7__N_1034(OAMQ_7__N_1034), 
            .OAM1ADR({OAM1ADR[7:1], \OAM1ADR[0] }), .DBIN({DBIN}), .OAMQ({OAMQ})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1271[10:90])
    OAM_COUNTER OAMCNT (.Clk(Clk), .Clk_enable_563(Clk_enable_563), .\CNT1_7__N_1135[2] (CNT1_7__N_1135[2]), 
            .n11691(n11691), .\OAM1Cout[1] (OAM1Cout[1]), .n11751(n11751), 
            .OAM1ADR({OAM1ADR[7:1], \OAM1ADR[0] }), .n4183(n4183), .PAR_O(PAR_O), 
            .DBIN({DBIN}), .W3(W3), .n11711(n11711), .n11787(n11787), 
            .CNT_7__N_1133(CNT_7__N_1133), .n5745(n5745), .n7695(n7695), 
            .\CNT1[0] (\CNT1[0] ), .OAM1ADR_0__N_1033(OAM1ADR_0__N_1033), 
            .n11817(n11817)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1265[13:76])
    COUNTER_U118 OAM2CNT_4 (.Clk(Clk), .Clk_enable_423(Clk_enable_423), 
            .CNT1_N_558({CNT1_N_558}), .\OAM2ADR[4] (OAM2ADR[4]), .OAM2STEP_N_1097(OAM2STEP_N_1097), 
            .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1268[9:121])
    COUNTER_U119 OAM2CNT_3 (.\OAM2ADR[3] (OAM2ADR[3]), .Clk(Clk), .OAM2STEP_N_1097(OAM2STEP_N_1097), 
            .ORES(ORES), .Clk_enable_423(Clk_enable_423), .CNT1_N_558({CNT1_N_558_adj_1566})) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1268[9:121])
    COUNTER_U120 OAM2CNT_2 (.\OAM2ADR[2] (OAM2ADR[2]), .n11813(n11813), 
            .\OAM2ADR[4] (OAM2ADR[4]), .\OAM2ADR[3] (OAM2ADR[3]), .C_OUT_N_556(C_OUT_N_556), 
            .CNT1_N_558({CNT1_N_558}), .Clk(Clk), .Clk_enable_185(Clk_enable_185), 
            .CNT1_N_558_adj_4({CNT1_N_558_adj_1567}), .OAM2STEP_N_1097(OAM2STEP_N_1097), 
            .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1268[9:121])
    COUNTER_U121 OAM2CNT_1 (.\OAM2ADR[1] (OAM2ADR[1]), .\OAM2ADR[0] (OAM2ADR[0]), 
            .n11813(n11813), .\OAM2ADR[2] (OAM2ADR[2]), .CNT1_N_558({CNT1_N_558_adj_1567}), 
            .\OAM2ADR[3] (OAM2ADR[3]), .CNT1_N_558_adj_2({CNT1_N_558_adj_1566}), 
            .Clk(Clk), .OAM2STEP_N_1097(OAM2STEP_N_1097), .ORES(ORES), 
            .Clk_enable_530(Clk_enable_530)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1268[9:121])
    COUNTER_U122 OAM2CNT_0 (.Clk(Clk), .Clk_enable_530(Clk_enable_530), 
            .\OAM2ADR[0] (OAM2ADR[0]), .OAM2STEP_N_1097(OAM2STEP_N_1097), 
            .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1268[9:121])
    OAM2_RAM MOD_OAM2_RAM (.Clk(Clk), .GND_net(GND_net), .WE(WE), .OAM2ADR({OAM2ADR}), 
            .OB2({OB2}), .OAM2Q({OAM2Q})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1272[10:90])
    
endmodule
//
// Verilog Description of module OAM_RAM
//

module OAM_RAM (Clk, GND_net, OAMQ_7__N_1034, OAM1ADR, DBIN, OAMQ) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input Clk;
    input GND_net;
    input OAMQ_7__N_1034;
    input [7:0]OAM1ADR;
    input [7:0]DBIN;
    output [7:0]OAMQ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire VCC_net;
    
    DP8KC OAM_RAM_0_0_0 (.DIA0(DBIN[0]), .DIA1(DBIN[1]), .DIA2(DBIN[2]), 
          .DIA3(DBIN[3]), .DIA4(DBIN[4]), .DIA5(DBIN[5]), .DIA6(DBIN[6]), 
          .DIA7(DBIN[7]), .DIA8(GND_net), .ADA0(VCC_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(OAM1ADR[0]), .ADA4(OAM1ADR[1]), .ADA5(OAM1ADR[2]), 
          .ADA6(OAM1ADR[3]), .ADA7(OAM1ADR[4]), .ADA8(OAM1ADR[5]), .ADA9(OAM1ADR[6]), 
          .ADA10(OAM1ADR[7]), .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(OAMQ_7__N_1034), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), 
          .ADB4(GND_net), .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), 
          .ADB8(GND_net), .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), 
          .ADB12(GND_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(GND_net), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(OAMQ[0]), .DOA1(OAMQ[1]), .DOA2(OAMQ[2]), 
          .DOA3(OAMQ[3]), .DOA4(OAMQ[4]), .DOA5(OAMQ[5]), .DOA6(OAMQ[6]), 
          .DOA7(OAMQ[7])) /* synthesis MEM_LPC_FILE="OAM_RAM.lpc", MEM_INIT_FILE="INIT_ALL_0s", syn_instantiated=1, LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=90, LSE_LLINE=1271, LSE_RLINE=1271 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1271[10:90])
    defparam OAM_RAM_0_0_0.DATA_WIDTH_A = 9;
    defparam OAM_RAM_0_0_0.DATA_WIDTH_B = 9;
    defparam OAM_RAM_0_0_0.REGMODE_A = "NOREG";
    defparam OAM_RAM_0_0_0.REGMODE_B = "NOREG";
    defparam OAM_RAM_0_0_0.CSDECODE_A = "0b000";
    defparam OAM_RAM_0_0_0.CSDECODE_B = "0b111";
    defparam OAM_RAM_0_0_0.WRITEMODE_A = "NORMAL";
    defparam OAM_RAM_0_0_0.WRITEMODE_B = "NORMAL";
    defparam OAM_RAM_0_0_0.GSR = "ENABLED";
    defparam OAM_RAM_0_0_0.RESETMODE = "ASYNC";
    defparam OAM_RAM_0_0_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam OAM_RAM_0_0_0.INIT_DATA = "STATIC";
    defparam OAM_RAM_0_0_0.INITVAL_00 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_01 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_02 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_03 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_04 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_05 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_06 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_07 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    VHI i1 (.Z(VCC_net));
    
endmodule
//
// Verilog Description of module OAM_COUNTER
//

module OAM_COUNTER (Clk, Clk_enable_563, \CNT1_7__N_1135[2] , n11691, 
            \OAM1Cout[1] , n11751, OAM1ADR, n4183, PAR_O, DBIN, 
            W3, n11711, n11787, CNT_7__N_1133, n5745, n7695, \CNT1[0] , 
            OAM1ADR_0__N_1033, n11817) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_563;
    input \CNT1_7__N_1135[2] ;
    input n11691;
    output \OAM1Cout[1] ;
    input n11751;
    output [7:0]OAM1ADR;
    output n4183;
    input PAR_O;
    input [7:0]DBIN;
    input W3;
    input n11711;
    input n11787;
    input CNT_7__N_1133;
    input n5745;
    input n7695;
    output \CNT1[0] ;
    input OAM1ADR_0__N_1033;
    input n11817;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]CNT1;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1682[10:14])
    wire [7:0]CNT1_7__N_1135;
    
    wire n5746;
    wire [7:0]n27;
    wire [7:0]n56;
    
    FD1P3AX CNT1_i0_i7 (.D(CNT1_7__N_1135[7]), .SP(Clk_enable_563), .CK(Clk), 
            .Q(CNT1[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT1_i0_i7.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i6 (.D(CNT1_7__N_1135[6]), .SP(Clk_enable_563), .CK(Clk), 
            .Q(CNT1[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT1_i0_i6.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i5 (.D(CNT1_7__N_1135[5]), .SP(Clk_enable_563), .CK(Clk), 
            .Q(CNT1[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT1_i0_i5.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i4 (.D(CNT1_7__N_1135[4]), .SP(Clk_enable_563), .CK(Clk), 
            .Q(CNT1[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT1_i0_i4.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i3 (.D(CNT1_7__N_1135[3]), .SP(Clk_enable_563), .CK(Clk), 
            .Q(CNT1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT1_i0_i3.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i2 (.D(\CNT1_7__N_1135[2] ), .SP(Clk_enable_563), .CK(Clk), 
            .Q(CNT1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT1_i0_i2.GSR = "DISABLED";
    LUT4 i3223_3_lut_4_lut (.A(n11691), .B(\OAM1Cout[1] ), .C(n11751), 
         .D(OAM1ADR[6]), .Z(CNT1_7__N_1135[6])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (C (D)+!C !(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1691[48:112])
    defparam i3223_3_lut_4_lut.init = 16'h2fd0;
    LUT4 i3683_4_lut_3_lut (.A(OAM1ADR[1]), .B(OAM1ADR[0]), .C(n11691), 
         .Z(n4183)) /* synthesis lut_function=(A (B (C))+!A !(B+(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1684[24:55])
    defparam i3683_4_lut_3_lut.init = 16'h8181;
    FD1S3IX CNT__i0 (.D(n5746), .CK(Clk), .CD(PAR_O), .Q(OAM1ADR[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT__i0.GSR = "DISABLED";
    LUT4 mux_8_i2_3_lut (.A(CNT1[1]), .B(DBIN[1]), .C(W3), .Z(n27[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1690[64:92])
    defparam mux_8_i2_3_lut.init = 16'hcaca;
    LUT4 mux_8_i3_3_lut (.A(CNT1[2]), .B(DBIN[2]), .C(W3), .Z(n27[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1690[64:92])
    defparam mux_8_i3_3_lut.init = 16'hcaca;
    LUT4 mux_8_i4_3_lut (.A(CNT1[3]), .B(DBIN[3]), .C(W3), .Z(n27[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1690[64:92])
    defparam mux_8_i4_3_lut.init = 16'hcaca;
    LUT4 mux_8_i5_3_lut (.A(CNT1[4]), .B(DBIN[4]), .C(W3), .Z(n27[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1690[64:92])
    defparam mux_8_i5_3_lut.init = 16'hcaca;
    LUT4 mux_8_i6_3_lut (.A(CNT1[5]), .B(DBIN[5]), .C(W3), .Z(n27[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1690[64:92])
    defparam mux_8_i6_3_lut.init = 16'hcaca;
    LUT4 mux_8_i7_3_lut (.A(CNT1[6]), .B(DBIN[6]), .C(W3), .Z(n27[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1690[64:92])
    defparam mux_8_i7_3_lut.init = 16'hcaca;
    LUT4 mux_8_i8_3_lut (.A(CNT1[7]), .B(DBIN[7]), .C(W3), .Z(n27[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1690[64:92])
    defparam mux_8_i8_3_lut.init = 16'hcaca;
    LUT4 CNT_7__I_0_21_i2_2_lut (.A(OAM1ADR[1]), .B(OAM1ADR[0]), .Z(\OAM1Cout[1] )) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1684[24:55])
    defparam CNT_7__I_0_21_i2_2_lut.init = 16'h8888;
    LUT4 i3220_3_lut_4_lut (.A(n11691), .B(\OAM1Cout[1] ), .C(OAM1ADR[2]), 
         .D(OAM1ADR[3]), .Z(CNT1_7__N_1135[3])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (C (D)+!C !(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1691[48:112])
    defparam i3220_3_lut_4_lut.init = 16'h2fd0;
    LUT4 i3224_3_lut_4_lut (.A(n11691), .B(\OAM1Cout[1] ), .C(n11711), 
         .D(OAM1ADR[7]), .Z(CNT1_7__N_1135[7])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (C (D)+!C !(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1691[48:112])
    defparam i3224_3_lut_4_lut.init = 16'h2fd0;
    LUT4 i3222_3_lut_4_lut (.A(n11691), .B(\OAM1Cout[1] ), .C(n11787), 
         .D(OAM1ADR[5]), .Z(CNT1_7__N_1135[5])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (C (D)+!C !(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1691[48:112])
    defparam i3222_3_lut_4_lut.init = 16'h2fd0;
    FD1P3IX CNT__i1 (.D(n27[1]), .SP(CNT_7__N_1133), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT__i1.GSR = "DISABLED";
    LUT4 i5241_3_lut (.A(n5745), .B(DBIN[0]), .C(W3), .Z(n5746)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam i5241_3_lut.init = 16'hcaca;
    FD1P3IX CNT__i2 (.D(n27[2]), .SP(CNT_7__N_1133), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT__i2.GSR = "DISABLED";
    FD1P3IX CNT__i3 (.D(n27[3]), .SP(CNT_7__N_1133), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT__i3.GSR = "DISABLED";
    FD1P3IX CNT__i4 (.D(n27[4]), .SP(CNT_7__N_1133), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT__i4.GSR = "DISABLED";
    FD1P3IX CNT__i5 (.D(n27[5]), .SP(CNT_7__N_1133), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT__i5.GSR = "DISABLED";
    FD1P3IX CNT__i6 (.D(n27[6]), .SP(CNT_7__N_1133), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT__i6.GSR = "DISABLED";
    FD1P3IX CNT__i7 (.D(n27[7]), .SP(CNT_7__N_1133), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT__i7.GSR = "DISABLED";
    LUT4 xor_13_i2_2_lut (.A(OAM1ADR[1]), .B(OAM1ADR[0]), .Z(n56[1])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1691[78:112])
    defparam xor_13_i2_2_lut.init = 16'h6666;
    FD1P3IX CNT1_i0_i1 (.D(n56[1]), .SP(Clk_enable_563), .CD(n7695), .CK(Clk), 
            .Q(CNT1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT1_i0_i1.GSR = "DISABLED";
    FD1P3IX CNT1_i0_i0 (.D(OAM1ADR_0__N_1033), .SP(Clk_enable_563), .CD(n7695), 
            .CK(Clk), .Q(\CNT1[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=76, LSE_LLINE=1265, LSE_RLINE=1265 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1689[8] 1692[26])
    defparam CNT1_i0_i0.GSR = "DISABLED";
    LUT4 i3221_3_lut_4_lut (.A(n11691), .B(\OAM1Cout[1] ), .C(n11817), 
         .D(OAM1ADR[4]), .Z(CNT1_7__N_1135[4])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (C (D)+!C !(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1691[48:112])
    defparam i3221_3_lut_4_lut.init = 16'h2fd0;
    
endmodule
//
// Verilog Description of module COUNTER_U118
//

module COUNTER_U118 (Clk, Clk_enable_423, CNT1_N_558, \OAM2ADR[4] , 
            OAM2STEP_N_1097, ORES) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_423;
    input [0:0]CNT1_N_558;
    output \OAM2ADR[4] ;
    input OAM2STEP_N_1097;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_423), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1097), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[4] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U119
//

module COUNTER_U119 (\OAM2ADR[3] , Clk, OAM2STEP_N_1097, ORES, Clk_enable_423, 
            CNT1_N_558) /* synthesis syn_module_defined=1 */ ;
    output \OAM2ADR[3] ;
    input Clk;
    input OAM2STEP_N_1097;
    input ORES;
    input Clk_enable_423;
    input [0:0]CNT1_N_558;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1097), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[3] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_423), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U120
//

module COUNTER_U120 (\OAM2ADR[2] , n11813, \OAM2ADR[4] , \OAM2ADR[3] , 
            C_OUT_N_556, CNT1_N_558, Clk, Clk_enable_185, CNT1_N_558_adj_4, 
            OAM2STEP_N_1097, ORES) /* synthesis syn_module_defined=1 */ ;
    output \OAM2ADR[2] ;
    input n11813;
    input \OAM2ADR[4] ;
    input \OAM2ADR[3] ;
    output C_OUT_N_556;
    output [0:0]CNT1_N_558;
    input Clk;
    input Clk_enable_185;
    input [0:0]CNT1_N_558_adj_4;
    input OAM2STEP_N_1097;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\OAM2ADR[2] ), .B(n11813), .C(\OAM2ADR[4] ), 
         .D(\OAM2ADR[3] ), .Z(C_OUT_N_556)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h8000;
    LUT4 i1870_2_lut_3_lut_4_lut (.A(\OAM2ADR[2] ), .B(n11813), .C(\OAM2ADR[4] ), 
         .D(\OAM2ADR[3] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1870_2_lut_3_lut_4_lut.init = 16'h78f0;
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_4[0]), .SP(Clk_enable_185), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1097), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[2] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U121
//

module COUNTER_U121 (\OAM2ADR[1] , \OAM2ADR[0] , n11813, \OAM2ADR[2] , 
            CNT1_N_558, \OAM2ADR[3] , CNT1_N_558_adj_2, Clk, OAM2STEP_N_1097, 
            ORES, Clk_enable_530) /* synthesis syn_module_defined=1 */ ;
    output \OAM2ADR[1] ;
    input \OAM2ADR[0] ;
    output n11813;
    input \OAM2ADR[2] ;
    output [0:0]CNT1_N_558;
    input \OAM2ADR[3] ;
    output [0:0]CNT1_N_558_adj_2;
    input Clk;
    input OAM2STEP_N_1097;
    input ORES;
    input Clk_enable_530;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    wire [0:0]CNT1_N_558_adj_1561;
    
    LUT4 CNT_I_0_2_lut_rep_337 (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), .Z(n11813)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam CNT_I_0_2_lut_rep_337.init = 16'h8888;
    LUT4 i1884_2_lut_3_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), .C(\OAM2ADR[2] ), 
         .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1884_2_lut_3_lut.init = 16'h7878;
    LUT4 i1877_2_lut_3_lut_4_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), .C(\OAM2ADR[3] ), 
         .D(\OAM2ADR[2] ), .Z(CNT1_N_558_adj_2[0])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1655[22:32])
    defparam i1877_2_lut_3_lut_4_lut.init = 16'h78f0;
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1097), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[1] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_558_adj_1561[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1891_2_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), .Z(CNT1_N_558_adj_1561[0])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1663[26:36])
    defparam i1891_2_lut.init = 16'h6666;
    
endmodule
//
// Verilog Description of module COUNTER_U122
//

module COUNTER_U122 (Clk, Clk_enable_530, \OAM2ADR[0] , OAM2STEP_N_1097, 
            ORES) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_530;
    output \OAM2ADR[0] ;
    input OAM2STEP_N_1097;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire CNT1;
    wire [0:0]CNT1_N_558;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_558[0]), .SP(Clk_enable_530), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1662[8] 1664[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1097), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[0] ));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1659[8] 1660[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1905_1_lut (.A(\OAM2ADR[0] ), .Z(CNT1_N_558[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1663[26:36])
    defparam i1905_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module OAM2_RAM
//

module OAM2_RAM (Clk, GND_net, WE, OAM2ADR, OB2, OAM2Q) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input Clk;
    input GND_net;
    input WE;
    input [4:0]OAM2ADR;
    input [7:0]OB2;
    output [7:0]OAM2Q;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    
    wire VCC_net;
    
    DP8KC OAM2_RAM_0_0_0 (.DIA0(OB2[0]), .DIA1(OB2[1]), .DIA2(OB2[2]), 
          .DIA3(OB2[3]), .DIA4(OB2[4]), .DIA5(OB2[5]), .DIA6(OB2[6]), 
          .DIA7(OB2[7]), .DIA8(GND_net), .ADA0(VCC_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(OAM2ADR[0]), .ADA4(OAM2ADR[1]), .ADA5(OAM2ADR[2]), 
          .ADA6(OAM2ADR[3]), .ADA7(OAM2ADR[4]), .ADA8(GND_net), .ADA9(GND_net), 
          .ADA10(GND_net), .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(WE), .CSA0(GND_net), .CSA1(GND_net), 
          .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), .DIB1(GND_net), 
          .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), .DIB5(GND_net), 
          .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), .ADB0(GND_net), 
          .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), .ADB4(GND_net), 
          .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), .ADB8(GND_net), 
          .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), .ADB12(GND_net), 
          .CEB(VCC_net), .OCEB(VCC_net), .CLKB(GND_net), .WEB(GND_net), 
          .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), .RSTB(GND_net), 
          .DOA0(OAM2Q[0]), .DOA1(OAM2Q[1]), .DOA2(OAM2Q[2]), .DOA3(OAM2Q[3]), 
          .DOA4(OAM2Q[4]), .DOA5(OAM2Q[5]), .DOA6(OAM2Q[6]), .DOA7(OAM2Q[7])) /* synthesis MEM_LPC_FILE="OAM2_RAM.lpc", MEM_INIT_FILE="INIT_ALL_0s", syn_instantiated=1, LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=90, LSE_LLINE=1272, LSE_RLINE=1272 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1272[10:90])
    defparam OAM2_RAM_0_0_0.DATA_WIDTH_A = 9;
    defparam OAM2_RAM_0_0_0.DATA_WIDTH_B = 9;
    defparam OAM2_RAM_0_0_0.REGMODE_A = "NOREG";
    defparam OAM2_RAM_0_0_0.REGMODE_B = "NOREG";
    defparam OAM2_RAM_0_0_0.CSDECODE_A = "0b000";
    defparam OAM2_RAM_0_0_0.CSDECODE_B = "0b111";
    defparam OAM2_RAM_0_0_0.WRITEMODE_A = "NORMAL";
    defparam OAM2_RAM_0_0_0.WRITEMODE_B = "NORMAL";
    defparam OAM2_RAM_0_0_0.GSR = "ENABLED";
    defparam OAM2_RAM_0_0_0.RESETMODE = "ASYNC";
    defparam OAM2_RAM_0_0_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam OAM2_RAM_0_0_0.INIT_DATA = "STATIC";
    defparam OAM2_RAM_0_0_0.INITVAL_00 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_01 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_02 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_03 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_04 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_05 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_06 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_07 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    VHI i1 (.Z(VCC_net));
    
endmodule
//
// Verilog Description of module READBUSMUX
//

module READBUSMUX (OB_R, Clk, Clk_enable_367, OB, Clk_enable_87, RC, 
            PD_out_0, Clk_enable_513, R2, R7, R4, Clk_enable_564, 
            Clk_enable_83, PD_out_7, PD_out_6, PD_out_5, PD_out_4, 
            PD_out_3, PD_out_2, PD_out_1, DBIN, D, RnWR, nDBER, 
            R_EN, XRB_N_599, n83, R2DB) /* synthesis syn_module_defined=1 */ ;
    output [7:0]OB_R;
    input Clk;
    input Clk_enable_367;
    input [7:0]OB;
    input Clk_enable_87;
    input RC;
    input PD_out_0;
    input Clk_enable_513;
    input R2;
    input R7;
    input R4;
    input Clk_enable_564;
    input Clk_enable_83;
    input PD_out_7;
    input PD_out_6;
    input PD_out_5;
    input PD_out_4;
    input PD_out_3;
    input PD_out_2;
    input PD_out_1;
    input [7:0]DBIN;
    output [7:0]D;
    input RnWR;
    input nDBER;
    output R_EN;
    input XRB_N_599;
    input [7:0]n83;
    input [2:0]R2DB;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]PD_R;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(639[10:14])
    wire [7:0]Do;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(641[10:12])
    wire [7:0]Do_7__N_156;
    
    wire D_7__N_164, n5, n5_adj_1551, n5_adj_1552, n5_adj_1553, n5_adj_1554, 
        n5_adj_1555, n5_adj_1556, n5_adj_1557;
    
    FD1P3AX OB_R_i0_i5 (.D(OB[5]), .SP(Clk_enable_367), .CK(Clk), .Q(OB_R[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam OB_R_i0_i5.GSR = "DISABLED";
    FD1P3IX PD_R__i0 (.D(PD_out_0), .SP(Clk_enable_87), .CD(RC), .CK(Clk), 
            .Q(PD_R[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam PD_R__i0.GSR = "DISABLED";
    FD1S3AX Do_i7 (.D(Do_7__N_156[7]), .CK(Clk), .Q(Do[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam Do_i7.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i0 (.D(OB[0]), .SP(Clk_enable_513), .CK(Clk), .Q(OB_R[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam OB_R_i0_i0.GSR = "DISABLED";
    FD1S3AX Do_i0 (.D(Do_7__N_156[0]), .CK(Clk), .Q(Do[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam Do_i0.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i4 (.D(OB[4]), .SP(Clk_enable_513), .CK(Clk), .Q(OB_R[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam OB_R_i0_i4.GSR = "DISABLED";
    FD1S3AX Do_i6 (.D(Do_7__N_156[6]), .CK(Clk), .Q(Do[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam Do_i6.GSR = "DISABLED";
    FD1S3AX Do_i5 (.D(Do_7__N_156[5]), .CK(Clk), .Q(Do[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam Do_i5.GSR = "DISABLED";
    LUT4 i3_4_lut_4_lut (.A(R2), .B(R7), .C(R4), .Z(D_7__N_164)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(644[17:41])
    defparam i3_4_lut_4_lut.init = 16'hfefe;
    FD1S3AX Do_i4 (.D(Do_7__N_156[4]), .CK(Clk), .Q(Do[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam Do_i4.GSR = "DISABLED";
    FD1S3AX Do_i3 (.D(Do_7__N_156[3]), .CK(Clk), .Q(Do[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam Do_i3.GSR = "DISABLED";
    FD1S3AX Do_i2 (.D(Do_7__N_156[2]), .CK(Clk), .Q(Do[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam Do_i2.GSR = "DISABLED";
    FD1S3AX Do_i1 (.D(Do_7__N_156[1]), .CK(Clk), .Q(Do[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam Do_i1.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i7 (.D(OB[7]), .SP(Clk_enable_564), .CK(Clk), .Q(OB_R[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam OB_R_i0_i7.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i6 (.D(OB[6]), .SP(Clk_enable_564), .CK(Clk), .Q(OB_R[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam OB_R_i0_i6.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i3 (.D(OB[3]), .SP(Clk_enable_564), .CK(Clk), .Q(OB_R[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam OB_R_i0_i3.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i2 (.D(OB[2]), .SP(Clk_enable_564), .CK(Clk), .Q(OB_R[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam OB_R_i0_i2.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i1 (.D(OB[1]), .SP(Clk_enable_564), .CK(Clk), .Q(OB_R[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam OB_R_i0_i1.GSR = "DISABLED";
    FD1P3IX PD_R__i7 (.D(PD_out_7), .SP(Clk_enable_83), .CD(RC), .CK(Clk), 
            .Q(PD_R[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam PD_R__i7.GSR = "DISABLED";
    FD1P3IX PD_R__i6 (.D(PD_out_6), .SP(Clk_enable_83), .CD(RC), .CK(Clk), 
            .Q(PD_R[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam PD_R__i6.GSR = "DISABLED";
    FD1P3IX PD_R__i5 (.D(PD_out_5), .SP(Clk_enable_83), .CD(RC), .CK(Clk), 
            .Q(PD_R[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam PD_R__i5.GSR = "DISABLED";
    FD1P3IX PD_R__i4 (.D(PD_out_4), .SP(Clk_enable_83), .CD(RC), .CK(Clk), 
            .Q(PD_R[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam PD_R__i4.GSR = "DISABLED";
    FD1P3IX PD_R__i3 (.D(PD_out_3), .SP(Clk_enable_87), .CD(RC), .CK(Clk), 
            .Q(PD_R[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam PD_R__i3.GSR = "DISABLED";
    FD1P3IX PD_R__i2 (.D(PD_out_2), .SP(Clk_enable_87), .CD(RC), .CK(Clk), 
            .Q(PD_R[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam PD_R__i2.GSR = "DISABLED";
    FD1P3IX PD_R__i1 (.D(PD_out_1), .SP(Clk_enable_87), .CD(RC), .CK(Clk), 
            .Q(PD_R[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=223, LSE_RLINE=239 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(647[8] 652[26])
    defparam PD_R__i1.GSR = "DISABLED";
    LUT4 DBIN_7__I_0_i1_3_lut (.A(DBIN[0]), .B(Do[0]), .C(D_7__N_164), 
         .Z(D[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(644[17:63])
    defparam DBIN_7__I_0_i1_3_lut.init = 16'hcaca;
    LUT4 i10753_2_lut (.A(RnWR), .B(nDBER), .Z(R_EN)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(645[8:10])
    defparam i10753_2_lut.init = 16'hdddd;
    LUT4 DBIN_7__I_0_i2_3_lut (.A(DBIN[1]), .B(Do[1]), .C(D_7__N_164), 
         .Z(D[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(644[17:63])
    defparam DBIN_7__I_0_i2_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i3_3_lut (.A(DBIN[2]), .B(Do[2]), .C(D_7__N_164), 
         .Z(D[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(644[17:63])
    defparam DBIN_7__I_0_i3_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i4_3_lut (.A(DBIN[3]), .B(Do[3]), .C(D_7__N_164), 
         .Z(D[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(644[17:63])
    defparam DBIN_7__I_0_i4_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i5_3_lut (.A(DBIN[4]), .B(Do[4]), .C(D_7__N_164), 
         .Z(D[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(644[17:63])
    defparam DBIN_7__I_0_i5_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i6_3_lut (.A(DBIN[5]), .B(Do[5]), .C(D_7__N_164), 
         .Z(D[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(644[17:63])
    defparam DBIN_7__I_0_i6_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i7_3_lut (.A(DBIN[6]), .B(Do[6]), .C(D_7__N_164), 
         .Z(D[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(644[17:63])
    defparam DBIN_7__I_0_i7_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i8_3_lut (.A(DBIN[7]), .B(Do[7]), .C(D_7__N_164), 
         .Z(D[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(644[17:63])
    defparam DBIN_7__I_0_i8_3_lut.init = 16'hcaca;
    LUT4 i3_4_lut (.A(n5), .B(XRB_N_599), .C(n83[7]), .D(PD_R[7]), .Z(Do_7__N_156[7])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i3_4_lut.init = 16'hfbfa;
    LUT4 i1_4_lut (.A(R4), .B(R2), .C(OB_R[7]), .D(R2DB[2]), .Z(n5)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i1_4_lut.init = 16'heca0;
    LUT4 i3_4_lut_adj_381 (.A(n5_adj_1551), .B(XRB_N_599), .C(n83[0]), 
         .D(PD_R[0]), .Z(Do_7__N_156[0])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i3_4_lut_adj_381.init = 16'hfbfa;
    LUT4 i1_4_lut_adj_382 (.A(R4), .B(R2), .C(OB_R[0]), .D(DBIN[0]), 
         .Z(n5_adj_1551)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i1_4_lut_adj_382.init = 16'heca0;
    LUT4 i3_4_lut_adj_383 (.A(n5_adj_1552), .B(XRB_N_599), .C(n83[6]), 
         .D(PD_R[6]), .Z(Do_7__N_156[6])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i3_4_lut_adj_383.init = 16'hfbfa;
    LUT4 i1_4_lut_adj_384 (.A(R4), .B(R2), .C(OB_R[6]), .D(R2DB[1]), 
         .Z(n5_adj_1552)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i1_4_lut_adj_384.init = 16'heca0;
    LUT4 i3_4_lut_adj_385 (.A(n5_adj_1553), .B(XRB_N_599), .C(n83[5]), 
         .D(PD_R[5]), .Z(Do_7__N_156[5])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i3_4_lut_adj_385.init = 16'hfbfa;
    LUT4 i1_4_lut_adj_386 (.A(R4), .B(R2), .C(OB_R[5]), .D(R2DB[0]), 
         .Z(n5_adj_1553)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i1_4_lut_adj_386.init = 16'heca0;
    LUT4 i3_4_lut_adj_387 (.A(n5_adj_1554), .B(XRB_N_599), .C(n83[4]), 
         .D(PD_R[4]), .Z(Do_7__N_156[4])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i3_4_lut_adj_387.init = 16'hfbfa;
    LUT4 i1_4_lut_adj_388 (.A(R4), .B(R2), .C(OB_R[4]), .D(DBIN[4]), 
         .Z(n5_adj_1554)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i1_4_lut_adj_388.init = 16'heca0;
    LUT4 i3_4_lut_adj_389 (.A(n5_adj_1555), .B(XRB_N_599), .C(n83[3]), 
         .D(PD_R[3]), .Z(Do_7__N_156[3])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i3_4_lut_adj_389.init = 16'hfbfa;
    LUT4 i1_4_lut_adj_390 (.A(R4), .B(R2), .C(OB_R[3]), .D(DBIN[3]), 
         .Z(n5_adj_1555)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i1_4_lut_adj_390.init = 16'heca0;
    LUT4 i3_4_lut_adj_391 (.A(n5_adj_1556), .B(XRB_N_599), .C(n83[2]), 
         .D(PD_R[2]), .Z(Do_7__N_156[2])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i3_4_lut_adj_391.init = 16'hfbfa;
    LUT4 i1_4_lut_adj_392 (.A(R4), .B(R2), .C(OB_R[2]), .D(DBIN[2]), 
         .Z(n5_adj_1556)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i1_4_lut_adj_392.init = 16'heca0;
    LUT4 i3_4_lut_adj_393 (.A(n5_adj_1557), .B(XRB_N_599), .C(n83[1]), 
         .D(PD_R[1]), .Z(Do_7__N_156[1])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i3_4_lut_adj_393.init = 16'hfbfa;
    LUT4 i1_4_lut_adj_394 (.A(R4), .B(R2), .C(OB_R[1]), .D(DBIN[1]), 
         .Z(n5_adj_1557)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(651[17:136])
    defparam i1_4_lut_adj_394.init = 16'heca0;
    
endmodule
//
// Verilog Description of module CLK_DIV
//

module CLK_DIV (MCLK_c, SUBCLK_c, Clk2_N_17, DIV_2__N_3, n11839, \DIV[1] , 
            Clk_enable_206, Clk_enable_207, Clk_enable_210, Clk_enable_73, 
            Clk_enable_562, Clk_enable_185, Clk_enable_530, Clk_enable_423, 
            Clk_enable_473, n12292, Clk_enable_513, Clk_enable_564, 
            Clk_enable_549, Clk_enable_367, Clk_enable_526, SPR_OV, 
            OAMCTR2, nVIS, n11800, n10, HC, RESCL_IN, Vo_7__N_205, 
            nRES_c, Clk_enable_204, H_8__N_226, Clk_enable_202, ORES_LATCH, 
            n11741, \Hnn[0] , Clk_enable_120, n10722, \R2DB[1] , RESCL, 
            n10549, ORES, PAR_O, SPR0_EV1, SPR0_EV, n2939, \Hnn[5] , 
            n5788, \OSTEP[0] , n4430, OAM2STEP_N_1097, S_EV, SPR0_EV1_N_977, 
            \OAM1ADR[0] , \CNT1[0] , n11830, n5745, NFO_OUT, FTA_OUT, 
            PD_SR, I_OAM2, n5755, W3, CNT_7__N_1133, \Hn[0] , n10784, 
            F_AT_LATCH, PD_SEL) /* synthesis syn_module_defined=1 */ ;
    input MCLK_c;
    output SUBCLK_c;
    input Clk2_N_17;
    input DIV_2__N_3;
    input n11839;
    output \DIV[1] ;
    output Clk_enable_206;
    output Clk_enable_207;
    output Clk_enable_210;
    output Clk_enable_73;
    output Clk_enable_562;
    output Clk_enable_185;
    output Clk_enable_530;
    output Clk_enable_423;
    output Clk_enable_473;
    output n12292;
    output Clk_enable_513;
    output Clk_enable_564;
    output Clk_enable_549;
    output Clk_enable_367;
    output Clk_enable_526;
    input SPR_OV;
    input OAMCTR2;
    input nVIS;
    input n11800;
    output n10;
    input HC;
    input RESCL_IN;
    output Vo_7__N_205;
    input nRES_c;
    output Clk_enable_204;
    output H_8__N_226;
    output Clk_enable_202;
    input ORES_LATCH;
    output n11741;
    input \Hnn[0] ;
    output Clk_enable_120;
    input n10722;
    input \R2DB[1] ;
    input RESCL;
    output n10549;
    output ORES;
    input PAR_O;
    input SPR0_EV1;
    input SPR0_EV;
    output n2939;
    input \Hnn[5] ;
    output n5788;
    input \OSTEP[0] ;
    input n4430;
    output OAM2STEP_N_1097;
    input S_EV;
    output SPR0_EV1_N_977;
    input \OAM1ADR[0] ;
    input \CNT1[0] ;
    input n11830;
    output n5745;
    input NFO_OUT;
    input FTA_OUT;
    output PD_SR;
    input I_OAM2;
    output n5755;
    input W3;
    output CNT_7__N_1133;
    input \Hn[0] ;
    output n10784;
    input F_AT_LATCH;
    output PD_SEL;
    
    wire MCLK_c /* synthesis is_clock=1, SET_AS_NETWORK=MCLK_c */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(36[7:11])
    wire Clk2_N_17 /* synthesis is_inv_clock=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(478[5:10])
    wire [1:0]SUB;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(480[10:13])
    
    wire SUB_1__N_10;
    wire [2:0]DIV;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(479[10:13])
    
    wire DIV_2__N_5, DIV2n;
    
    FD1S3AX SUB_i0 (.D(SUB_1__N_10), .CK(MCLK_c), .Q(SUB[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=164, LSE_RLINE=171 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(485[8] 490[28])
    defparam SUB_i0.GSR = "DISABLED";
    FD1S3AX DIV_i0 (.D(DIV_2__N_5), .CK(MCLK_c), .Q(DIV[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=164, LSE_RLINE=171 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(485[8] 490[28])
    defparam DIV_i0.GSR = "DISABLED";
    FD1S3AX SUBCLK_29 (.D(SUB[1]), .CK(MCLK_c), .Q(SUBCLK_c)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=164, LSE_RLINE=171 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(485[8] 490[28])
    defparam SUBCLK_29.GSR = "DISABLED";
    FD1S3AX DIV2n_30 (.D(DIV_2__N_3), .CK(Clk2_N_17), .Q(DIV2n)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=164, LSE_RLINE=171 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(491[8] 493[28])
    defparam DIV2n_30.GSR = "DISABLED";
    LUT4 i1_4_lut_rep_371 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_206)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam i1_4_lut_rep_371.init = 16'hfefa;
    LUT4 i1_4_lut_rep_372 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_207)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam i1_4_lut_rep_372.init = 16'hfefa;
    LUT4 i1_4_lut_rep_373 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_210)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam i1_4_lut_rep_373.init = 16'hfefa;
    LUT4 i1_4_lut_rep_374 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_73)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam i1_4_lut_rep_374.init = 16'hfefa;
    LUT4 PCLK_I_0_1_lut_rep_376 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_562)) /* synthesis lut_function=(!(A+(B (C+(D))+!B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam PCLK_I_0_1_lut_rep_376.init = 16'h0105;
    LUT4 PCLK_I_0_1_lut_rep_377 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_185)) /* synthesis lut_function=(!(A+(B (C+(D))+!B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam PCLK_I_0_1_lut_rep_377.init = 16'h0105;
    LUT4 PCLK_I_0_1_lut_rep_378 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_530)) /* synthesis lut_function=(!(A+(B (C+(D))+!B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam PCLK_I_0_1_lut_rep_378.init = 16'h0105;
    LUT4 PCLK_I_0_1_lut_rep_379 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_423)) /* synthesis lut_function=(!(A+(B (C+(D))+!B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam PCLK_I_0_1_lut_rep_379.init = 16'h0105;
    LUT4 PCLK_I_0_1_lut_rep_380 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_473)) /* synthesis lut_function=(!(A+(B (C+(D))+!B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam PCLK_I_0_1_lut_rep_380.init = 16'h0105;
    LUT4 i1_4_lut_rep_381 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(n12292)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam i1_4_lut_rep_381.init = 16'hfefa;
    LUT4 i1_4_lut_rep_382 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_513)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam i1_4_lut_rep_382.init = 16'hfefa;
    LUT4 i1_4_lut_rep_383 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_564)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam i1_4_lut_rep_383.init = 16'hfefa;
    LUT4 i1_4_lut_rep_384 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_549)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam i1_4_lut_rep_384.init = 16'hfefa;
    FD1S3AX DIV_i2 (.D(DIV_2__N_3), .CK(MCLK_c), .Q(DIV[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=164, LSE_RLINE=171 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(485[8] 490[28])
    defparam DIV_i2.GSR = "DISABLED";
    FD1S3AX DIV_i1 (.D(DIV[0]), .CK(MCLK_c), .Q(\DIV[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=164, LSE_RLINE=171 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(485[8] 490[28])
    defparam DIV_i1.GSR = "DISABLED";
    FD1S3AX SUB_i1 (.D(SUB[0]), .CK(MCLK_c), .Q(SUB[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=164, LSE_RLINE=171 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(485[8] 490[28])
    defparam SUB_i1.GSR = "DISABLED";
    LUT4 i1_4_lut_rep_326 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_367)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam i1_4_lut_rep_326.init = 16'hfefa;
    LUT4 PCLK_I_0_1_lut_rep_306_4_lut (.A(DIV[2]), .B(n11839), .C(DIV2n), 
         .D(\DIV[1] ), .Z(Clk_enable_526)) /* synthesis lut_function=(!(A+(B (C+(D))+!B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam PCLK_I_0_1_lut_rep_306_4_lut.init = 16'h0105;
    LUT4 i4_4_lut (.A(SPR_OV), .B(OAMCTR2), .C(nVIS), .D(n11800), .Z(n10)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i4_4_lut.init = 16'hfffe;
    LUT4 i2_3_lut (.A(HC), .B(n12292), .C(RESCL_IN), .Z(Vo_7__N_205)) /* synthesis lut_function=(!(A+!(B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam i2_3_lut.init = 16'h4040;
    LUT4 i10574_2_lut (.A(SUBCLK_c), .B(nRES_c), .Z(SUB_1__N_10)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(489[42:61])
    defparam i10574_2_lut.init = 16'h4444;
    LUT4 i1_4_lut_rep_370 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_204)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam i1_4_lut_rep_370.init = 16'hfefa;
    LUT4 i1_2_lut (.A(n12292), .B(HC), .Z(H_8__N_226)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam i1_2_lut.init = 16'h2222;
    LUT4 i10572_3_lut (.A(\DIV[1] ), .B(DIV[2]), .C(nRES_c), .Z(DIV_2__N_5)) /* synthesis lut_function=(!(A+(B+!(C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(487[46:74])
    defparam i10572_3_lut.init = 16'h1010;
    LUT4 i1_4_lut_rep_369 (.A(DIV[2]), .B(n11839), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_202)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(482[18:51])
    defparam i1_4_lut_rep_369.init = 16'hfefa;
    LUT4 nPCLK_I_0_2_lut_rep_265_2_lut (.A(n12292), .B(ORES_LATCH), .Z(n11741)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam nPCLK_I_0_2_lut_rep_265_2_lut.init = 16'hdddd;
    LUT4 nPCLK_I_0_130_2_lut_rep_232_2_lut (.A(n12292), .B(\Hnn[0] ), .Z(Clk_enable_120)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam nPCLK_I_0_130_2_lut_rep_232_2_lut.init = 16'h4444;
    LUT4 i1_4_lut_4_lut (.A(n12292), .B(n10722), .C(\R2DB[1] ), .D(RESCL), 
         .Z(n10549)) /* synthesis lut_function=(!(A ((D)+!C)+!A (B (D)+!B ((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam i1_4_lut_4_lut.init = 16'h00f4;
    LUT4 ORES_I_0_1_lut_2_lut_2_lut (.A(n12292), .B(ORES_LATCH), .Z(ORES)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam ORES_I_0_1_lut_2_lut_2_lut.init = 16'h2222;
    LUT4 i2487_4_lut_4_lut (.A(n12292), .B(PAR_O), .C(SPR0_EV1), .D(SPR0_EV), 
         .Z(n2939)) /* synthesis lut_function=(A (D)+!A !(B (C)+!B !(D))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam i2487_4_lut_4_lut.init = 16'hbf04;
    LUT4 i5283_2_lut_2_lut (.A(n12292), .B(\Hnn[5] ), .Z(n5788)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam i5283_2_lut_2_lut.init = 16'h4444;
    LUT4 i10718_3_lut_3_lut (.A(n12292), .B(\OSTEP[0] ), .C(n4430), .Z(OAM2STEP_N_1097)) /* synthesis lut_function=(!((B+(C))+!A)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam i10718_3_lut_3_lut.init = 16'h0202;
    LUT4 S_EV_I_0_2_lut_2_lut (.A(n12292), .B(S_EV), .Z(SPR0_EV1_N_977)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam S_EV_I_0_2_lut_2_lut.init = 16'h4444;
    LUT4 i5240_3_lut_4_lut_4_lut (.A(n12292), .B(\OAM1ADR[0] ), .C(\CNT1[0] ), 
         .D(n11830), .Z(n5745)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam i5240_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i1_3_lut_4_lut_4_lut (.A(n12292), .B(NFO_OUT), .C(FTA_OUT), .D(\Hnn[0] ), 
         .Z(PD_SR)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam i1_3_lut_4_lut_4_lut.init = 16'h0100;
    LUT4 i5257_2_lut_2_lut (.A(n12292), .B(I_OAM2), .Z(n5755)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam i5257_2_lut_2_lut.init = 16'h4444;
    LUT4 CNT_7__I_310_2_lut_3_lut_4_lut_4_lut (.A(n12292), .B(W3), .C(PAR_O), 
         .D(n11830), .Z(CNT_7__N_1133)) /* synthesis lut_function=(A (B+(C+!(D)))+!A (B+(C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam CNT_7__I_310_2_lut_3_lut_4_lut_4_lut.init = 16'hfcfe;
    LUT4 i1_2_lut_2_lut (.A(n12292), .B(\Hn[0] ), .Z(n10784)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam i1_2_lut_2_lut.init = 16'hdddd;
    LUT4 PD_SR_N_676_I_0_129_2_lut_3_lut_3_lut (.A(n12292), .B(F_AT_LATCH), 
         .C(\Hnn[0] ), .Z(PD_SEL)) /* synthesis lut_function=(!(A+!(B (C)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(483[16:52])
    defparam PD_SR_N_676_I_0_129_2_lut_3_lut_3_lut.init = 16'h4040;
    
endmodule
//
// Verilog Description of module BG_COLOR
//

module BG_COLOR (Clk, Clk_enable_367, Clk_enable_293, Clk_enable_562, 
            PD_SR, PD_out_0, Clk_enable_120, n11811, PD_out_7, PD_out_6, 
            PD_out_5, PD_out_4, PD_out_3, PD_out_2, n11797, PD_out_1, 
            CLPB_LATCH, Clk_enable_564, nCLPB_N_123, F_AT_LATCH, n11794, 
            \THO[1] , BGC2, PD_SEL, Clk_enable_423, RC, \DBIN[0] , 
            Clk_enable_513, W5_1, \DBIN[1] , \DBIN[2] , n12292, NFO_OUT, 
            TVO1, Clk_enable_549, n11701) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_367;
    input Clk_enable_293;
    input Clk_enable_562;
    input PD_SR;
    input PD_out_0;
    input Clk_enable_120;
    input n11811;
    input PD_out_7;
    input PD_out_6;
    input PD_out_5;
    input PD_out_4;
    input PD_out_3;
    input PD_out_2;
    input n11797;
    input PD_out_1;
    output CLPB_LATCH;
    input Clk_enable_564;
    input nCLPB_N_123;
    output F_AT_LATCH;
    input n11794;
    input \THO[1] ;
    output [3:0]BGC2;
    input PD_SEL;
    input Clk_enable_423;
    input RC;
    input \DBIN[0] ;
    input Clk_enable_513;
    input W5_1;
    input \DBIN[1] ;
    input \DBIN[2] ;
    input n12292;
    input NFO_OUT;
    input TVO1;
    input Clk_enable_549;
    input n11701;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]SR3;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(969[25:28])
    wire [2:0]FH;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(948[10:12])
    
    wire n12062, n12063, n12065, n12066;
    wire [7:0]SR2;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(969[20:23])
    
    wire n12069, n12070, n12072;
    wire [7:0]SR0;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(969[10:13])
    
    wire n12257, n12259, n12256, n12260;
    wire [1:0]ATR;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(954[10:13])
    wire [1:0]ATRO;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(955[10:14])
    wire [1:0]ATSEL;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(964[11:16])
    wire [3:0]BGC1;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(946[10:14])
    wire [3:0]BGC_POS;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(977[11:18])
    wire [7:0]PDTA;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(953[10:14])
    
    wire n5717, n5718, n5719, n5720, n5721, n5722, n5723, n5724, 
        n5725, n5726, n5727, n5728, Clk_enable_391;
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    wire [7:0]QP;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    
    wire n5173, n5729, n5730, n5165, n5136, n5130, n12073;
    wire [7:0]SR1;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(969[15:18])
    
    wire n12089, n5735, THO1R, n5733, n5731, n5732, n5734;
    wire [7:0]QS_IN_adj_1549;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    wire [7:0]QP_adj_1550;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1473[17:19])
    
    wire n5736, n5131, n5137, n5166, n5174;
    wire [7:0]PDAT;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(952[10:14])
    
    wire Clk_enable_302, n12088, n12091, n12093, n12090, n12092, 
        n13, n10, n13_adj_1547, n10_adj_1548, n12074, n12071, n12261, 
        n12258, n12067, n12064;
    
    LUT4 SR3_1__bdd_3_lut_11077 (.A(SR3[0]), .B(FH[1]), .C(SR3[2]), .Z(n12062)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR3_1__bdd_3_lut_11077.init = 16'hb8b8;
    LUT4 SR3_1__bdd_3_lut_11179 (.A(SR3[1]), .B(FH[1]), .C(SR3[3]), .Z(n12063)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR3_1__bdd_3_lut_11179.init = 16'hb8b8;
    LUT4 SR3_5__bdd_3_lut_11080 (.A(SR3[4]), .B(FH[1]), .C(SR3[6]), .Z(n12065)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR3_5__bdd_3_lut_11080.init = 16'hb8b8;
    LUT4 SR3_5__bdd_3_lut_11183 (.A(SR3[5]), .B(FH[1]), .C(SR3[7]), .Z(n12066)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR3_5__bdd_3_lut_11183.init = 16'hb8b8;
    LUT4 SR2_1__bdd_3_lut_11085 (.A(SR2[0]), .B(FH[1]), .C(SR2[2]), .Z(n12069)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR2_1__bdd_3_lut_11085.init = 16'hb8b8;
    LUT4 SR2_1__bdd_3_lut_11159 (.A(SR2[1]), .B(FH[1]), .C(SR2[3]), .Z(n12070)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR2_1__bdd_3_lut_11159.init = 16'hb8b8;
    LUT4 SR2_5__bdd_3_lut_11088 (.A(SR2[4]), .B(FH[1]), .C(SR2[6]), .Z(n12072)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR2_5__bdd_3_lut_11088.init = 16'hb8b8;
    LUT4 SR0_1__bdd_3_lut (.A(SR0[1]), .B(FH[1]), .C(SR0[3]), .Z(n12257)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR0_1__bdd_3_lut.init = 16'hb8b8;
    LUT4 SR0_5__bdd_3_lut_11174 (.A(SR0[4]), .B(FH[1]), .C(SR0[6]), .Z(n12259)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR0_5__bdd_3_lut_11174.init = 16'hb8b8;
    LUT4 SR0_1__bdd_3_lut_11171 (.A(SR0[0]), .B(FH[1]), .C(SR0[2]), .Z(n12256)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR0_1__bdd_3_lut_11171.init = 16'hb8b8;
    LUT4 SR0_5__bdd_3_lut (.A(SR0[5]), .B(FH[1]), .C(SR0[7]), .Z(n12260)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR0_5__bdd_3_lut.init = 16'hb8b8;
    FD1P3AX ATR_i0_i0 (.D(ATRO[0]), .SP(Clk_enable_367), .CK(Clk), .Q(ATR[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam ATR_i0_i0.GSR = "DISABLED";
    FD1P3AX ATRO_i0_i0 (.D(ATSEL[0]), .SP(Clk_enable_293), .CK(Clk), .Q(ATRO[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam ATRO_i0_i0.GSR = "DISABLED";
    FD1P3AX BGC1_i0_i0 (.D(BGC_POS[0]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(BGC1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam BGC1_i0_i0.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i0 (.D(PD_out_0), .SP(PD_SR), .CK(Clk), .Q(PDTA[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDTA_i0_i0.GSR = "DISABLED";
    LUT4 i5213_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PD_out_7), 
         .D(n5717), .Z(n5718)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i5213_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5215_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PD_out_6), 
         .D(n5719), .Z(n5720)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i5215_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5217_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PD_out_5), 
         .D(n5721), .Z(n5722)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i5217_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5219_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PD_out_4), 
         .D(n5723), .Z(n5724)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i5219_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5221_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PD_out_3), 
         .D(n5725), .Z(n5726)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i5221_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5223_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PD_out_2), 
         .D(n5727), .Z(n5728)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i5223_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4668_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[1]), .C(QP[0]), 
         .D(n11797), .Z(n5173)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4668_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i5225_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PD_out_1), 
         .D(n5729), .Z(n5730)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i5225_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4660_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[2]), .C(QP[1]), 
         .D(n11797), .Z(n5165)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4660_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4631_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[3]), .C(QP[2]), 
         .D(n11797), .Z(n5136)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4631_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4625_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[4]), .C(QP[3]), 
         .D(n11797), .Z(n5130)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4625_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 SR2_5__bdd_3_lut_11163 (.A(SR2[5]), .B(FH[1]), .C(SR2[7]), .Z(n12073)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR2_5__bdd_3_lut_11163.init = 16'hb8b8;
    LUT4 SR1_1__bdd_3_lut_11113 (.A(SR1[1]), .B(FH[1]), .C(SR1[3]), .Z(n12089)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR1_1__bdd_3_lut_11113.init = 16'hb8b8;
    FD1P3AX CLPB_LATCH_111 (.D(nCLPB_N_123), .SP(Clk_enable_564), .CK(Clk), 
            .Q(CLPB_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam CLPB_LATCH_111.GSR = "DISABLED";
    FD1P3AX F_AT_LATCH_112 (.D(n11794), .SP(Clk_enable_564), .CK(Clk), 
            .Q(F_AT_LATCH));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam F_AT_LATCH_112.GSR = "DISABLED";
    LUT4 i5230_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[5]), .C(QP[4]), 
         .D(n11797), .Z(n5735)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i5230_3_lut_4_lut_4_lut.init = 16'hcce4;
    FD1P3AX THO1R_113 (.D(\THO[1] ), .SP(Clk_enable_564), .CK(Clk), .Q(THO1R));   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam THO1R_113.GSR = "DISABLED";
    LUT4 i5228_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[6]), .C(QP[5]), 
         .D(n11797), .Z(n5733)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i5228_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i5227_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PDTA[7]), 
         .D(n5731), .Z(n5732)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i5227_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5226_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[7]), .C(QP[6]), 
         .D(n11797), .Z(n5731)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i5226_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i5229_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PDTA[6]), 
         .D(n5733), .Z(n5734)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i5229_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5224_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1549[1]), 
         .C(QP_adj_1550[0]), .D(n11797), .Z(n5729)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i5224_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i5231_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PDTA[5]), 
         .D(n5735), .Z(n5736)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i5231_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5222_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1549[2]), 
         .C(QP_adj_1550[1]), .D(n11797), .Z(n5727)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i5222_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i5220_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1549[3]), 
         .C(QP_adj_1550[2]), .D(n11797), .Z(n5725)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i5220_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i5218_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1549[4]), 
         .C(QP_adj_1550[3]), .D(n11797), .Z(n5723)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i5218_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i5216_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1549[5]), 
         .C(QP_adj_1550[4]), .D(n11797), .Z(n5721)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i5216_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4626_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PDTA[4]), 
         .D(n5130), .Z(n5131)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i4626_3_lut_4_lut.init = 16'hfd20;
    LUT4 i5214_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1549[6]), 
         .C(QP_adj_1550[5]), .D(n11797), .Z(n5719)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i5214_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i5212_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1549[7]), 
         .C(QP_adj_1550[6]), .D(n11797), .Z(n5717)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i5212_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4632_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PDTA[3]), 
         .D(n5136), .Z(n5137)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i4632_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4661_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PDTA[2]), 
         .D(n5165), .Z(n5166)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i4661_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4669_3_lut_4_lut (.A(Clk_enable_120), .B(n11811), .C(PDTA[1]), 
         .D(n5173), .Z(n5174)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(960[17:36])
    defparam i4669_3_lut_4_lut.init = 16'hfd20;
    FD1P3AX BGC2_i0_i0 (.D(BGC1[0]), .SP(Clk_enable_367), .CK(Clk), .Q(BGC2[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam BGC2_i0_i0.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i0 (.D(PD_out_0), .SP(PD_SEL), .CK(Clk), .Q(PDAT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDAT_i0_i0.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i7 (.D(PD_out_7), .SP(PD_SR), .CK(Clk), .Q(PDTA[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDTA_i0_i7.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i6 (.D(PD_out_6), .SP(PD_SR), .CK(Clk), .Q(PDTA[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDTA_i0_i6.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i5 (.D(PD_out_5), .SP(PD_SR), .CK(Clk), .Q(PDTA[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDTA_i0_i5.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i4 (.D(PD_out_4), .SP(PD_SR), .CK(Clk), .Q(PDTA[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDTA_i0_i4.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i3 (.D(PD_out_3), .SP(PD_SR), .CK(Clk), .Q(PDTA[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDTA_i0_i3.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i2 (.D(PD_out_2), .SP(PD_SR), .CK(Clk), .Q(PDTA[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDTA_i0_i2.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i1 (.D(PD_out_1), .SP(PD_SR), .CK(Clk), .Q(PDTA[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDTA_i0_i1.GSR = "DISABLED";
    FD1P3AX BGC1_i0_i3 (.D(BGC_POS[3]), .SP(Clk_enable_423), .CK(Clk), 
            .Q(BGC1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam BGC1_i0_i3.GSR = "DISABLED";
    FD1P3AX BGC1_i0_i2 (.D(BGC_POS[2]), .SP(Clk_enable_423), .CK(Clk), 
            .Q(BGC1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam BGC1_i0_i2.GSR = "DISABLED";
    FD1P3AX BGC1_i0_i1 (.D(BGC_POS[1]), .SP(Clk_enable_423), .CK(Clk), 
            .Q(BGC1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam BGC1_i0_i1.GSR = "DISABLED";
    FD1P3AX ATRO_i0_i1 (.D(ATSEL[1]), .SP(Clk_enable_293), .CK(Clk), .Q(ATRO[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam ATRO_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_i0_i1 (.D(ATRO[1]), .SP(Clk_enable_367), .CK(Clk), .Q(ATR[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam ATR_i0_i1.GSR = "DISABLED";
    FD1P3IX FH__i0 (.D(\DBIN[0] ), .SP(Clk_enable_302), .CD(RC), .CK(Clk), 
            .Q(FH[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam FH__i0.GSR = "DISABLED";
    LUT4 SR1_1__bdd_3_lut_11093 (.A(SR1[0]), .B(FH[1]), .C(SR1[2]), .Z(n12088)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR1_1__bdd_3_lut_11093.init = 16'hb8b8;
    LUT4 SR1_5__bdd_3_lut_11096 (.A(SR1[4]), .B(FH[1]), .C(SR1[6]), .Z(n12091)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR1_5__bdd_3_lut_11096.init = 16'hb8b8;
    L6MUX21 i11099 (.D0(n12093), .D1(n12090), .SD(FH[2]), .Z(BGC_POS[1]));
    PFUMX i11097 (.BLUT(n12092), .ALUT(n12091), .C0(FH[0]), .Z(n12093));
    LUT4 SR1_5__bdd_3_lut_11117 (.A(SR1[5]), .B(FH[1]), .C(SR1[7]), .Z(n12092)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR1_5__bdd_3_lut_11117.init = 16'hb8b8;
    FD1P3AX BGC2_i0_i1 (.D(BGC1[1]), .SP(Clk_enable_513), .CK(Clk), .Q(BGC2[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam BGC2_i0_i1.GSR = "DISABLED";
    FD1P3AX BGC2_i0_i2 (.D(BGC1[2]), .SP(Clk_enable_513), .CK(Clk), .Q(BGC2[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam BGC2_i0_i2.GSR = "DISABLED";
    FD1P3AX BGC2_i0_i3 (.D(BGC1[3]), .SP(Clk_enable_513), .CK(Clk), .Q(BGC2[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam BGC2_i0_i3.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i1 (.D(PD_out_1), .SP(PD_SEL), .CK(Clk), .Q(PDAT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDAT_i0_i1.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i2 (.D(PD_out_2), .SP(PD_SEL), .CK(Clk), .Q(PDAT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDAT_i0_i2.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i3 (.D(PD_out_3), .SP(PD_SEL), .CK(Clk), .Q(PDAT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDAT_i0_i3.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i4 (.D(PD_out_4), .SP(PD_SEL), .CK(Clk), .Q(PDAT[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDAT_i0_i4.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i5 (.D(PD_out_5), .SP(PD_SEL), .CK(Clk), .Q(PDAT[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDAT_i0_i5.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i6 (.D(PD_out_6), .SP(PD_SEL), .CK(Clk), .Q(PDAT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDAT_i0_i6.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i7 (.D(PD_out_7), .SP(PD_SEL), .CK(Clk), .Q(PDAT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam PDAT_i0_i7.GSR = "DISABLED";
    FD1P3IX FH__i1 (.D(\DBIN[1] ), .SP(W5_1), .CD(RC), .CK(Clk), .Q(FH[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam FH__i1.GSR = "DISABLED";
    FD1P3IX FH__i2 (.D(\DBIN[2] ), .SP(W5_1), .CD(RC), .CK(Clk), .Q(FH[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=307, LSE_RLINE=324 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(989[8] 1003[27])
    defparam FH__i2.GSR = "DISABLED";
    LUT4 i29_3_lut (.A(PDAT[1]), .B(PDAT[3]), .C(THO1R), .Z(n13)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(966[19:130])
    defparam i29_3_lut.init = 16'hcaca;
    LUT4 i30_3_lut (.A(PDAT[5]), .B(PDAT[7]), .C(THO1R), .Z(n10)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(966[19:130])
    defparam i30_3_lut.init = 16'hcaca;
    LUT4 i29_3_lut_adj_378 (.A(PDAT[0]), .B(PDAT[2]), .C(THO1R), .Z(n13_adj_1547)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(966[19:130])
    defparam i29_3_lut_adj_378.init = 16'hcaca;
    LUT4 i30_3_lut_adj_379 (.A(PDAT[4]), .B(PDAT[6]), .C(THO1R), .Z(n10_adj_1548)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(966[19:130])
    defparam i30_3_lut_adj_379.init = 16'hcaca;
    LUT4 i10690_2_lut_rep_285 (.A(n12292), .B(NFO_OUT), .Z(Clk_enable_391)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i10690_2_lut_rep_285.init = 16'h1111;
    PFUMX i11094 (.BLUT(n12089), .ALUT(n12088), .C0(FH[0]), .Z(n12090));
    L6MUX21 i11091 (.D0(n12074), .D1(n12071), .SD(FH[2]), .Z(BGC_POS[2]));
    PFUMX i11089 (.BLUT(n12073), .ALUT(n12072), .C0(FH[0]), .Z(n12074));
    PFUMX i28 (.BLUT(n13), .ALUT(n10), .C0(TVO1), .Z(ATSEL[1]));
    PFUMX i28_adj_380 (.BLUT(n13_adj_1547), .ALUT(n10_adj_1548), .C0(TVO1), 
          .Z(ATSEL[0]));
    L6MUX21 i11177 (.D0(n12261), .D1(n12258), .SD(FH[2]), .Z(BGC_POS[0]));
    PFUMX i11175 (.BLUT(n12260), .ALUT(n12259), .C0(FH[0]), .Z(n12261));
    PFUMX i11172 (.BLUT(n12257), .ALUT(n12256), .C0(FH[0]), .Z(n12258));
    PFUMX i11086 (.BLUT(n12070), .ALUT(n12069), .C0(FH[0]), .Z(n12071));
    L6MUX21 i11083 (.D0(n12067), .D1(n12064), .SD(FH[2]), .Z(BGC_POS[3]));
    PFUMX i11081 (.BLUT(n12066), .ALUT(n12065), .C0(FH[0]), .Z(n12067));
    PFUMX i11078 (.BLUT(n12063), .ALUT(n12062), .C0(FH[0]), .Z(n12064));
    LUT4 i772_2_lut (.A(W5_1), .B(RC), .Z(Clk_enable_302)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i772_2_lut.init = 16'heeee;
    SHIFTREG_U123 SREG_TB (.QP({QP_adj_1550}), .Clk(Clk), .Clk_enable_549(Clk_enable_549), 
            .Clk_enable_513(Clk_enable_513), .\QS_IN[1] (QS_IN_adj_1549[1]), 
            .\QS_IN[2] (QS_IN_adj_1549[2]), .\QS_IN[3] (QS_IN_adj_1549[3]), 
            .\QS_IN[4] (QS_IN_adj_1549[4]), .Clk_enable_564(Clk_enable_564), 
            .\QS_IN[5] (QS_IN_adj_1549[5]), .\QS_IN[6] (QS_IN_adj_1549[6]), 
            .\QS_IN[7] (QS_IN_adj_1549[7]), .n5730(n5730), .n5728(n5728), 
            .n5726(n5726), .n5724(n5724), .n5722(n5722), .n5720(n5720), 
            .n5718(n5718), .PD_out_0(PD_out_0), .Clk_enable_293(Clk_enable_293), 
            .n11701(n11701)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(972[10:81])
    SHIFTREG_U124 SREG_TA (.Clk(Clk), .QP({QP}), .Clk_enable_513(Clk_enable_513), 
            .\QS_IN[1] (QS_IN[1]), .n5174(n5174), .\QS_IN[2] (QS_IN[2]), 
            .n5166(n5166), .\QS_IN[3] (QS_IN[3]), .n5137(n5137), .\QS_IN[4] (QS_IN[4]), 
            .n5131(n5131), .\QS_IN[5] (QS_IN[5]), .n5736(n5736), .\QS_IN[6] (QS_IN[6]), 
            .n5734(n5734), .\QS_IN[7] (QS_IN[7]), .n5732(n5732), .\PDTA[0] (PDTA[0]), 
            .Clk_enable_293(Clk_enable_293), .n11701(n11701)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(971[10:81])
    SHIFTREG_U125 SREG_FS3 (.SR3({SR3}), .Clk(Clk), .Clk_enable_549(Clk_enable_549), 
            .Clk_enable_391(Clk_enable_391), .\ATR[1] (ATR[1]), .Clk_enable_513(Clk_enable_513)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(976[10:81])
    SHIFTREG_U126 SREG_FS2 (.SR2({SR2}), .Clk(Clk), .Clk_enable_549(Clk_enable_549), 
            .Clk_enable_391(Clk_enable_391), .\ATR[0] (ATR[0]), .Clk_enable_513(Clk_enable_513), 
            .Clk_enable_367(Clk_enable_367)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(975[10:81])
    SHIFTREG_U127 SREG_FS1 (.SR1({SR1}), .Clk(Clk), .Clk_enable_549(Clk_enable_549), 
            .Clk_enable_391(Clk_enable_391), .QTB(QP_adj_1550[7]), .Clk_enable_513(Clk_enable_513), 
            .Clk_enable_367(Clk_enable_367)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(974[10:81])
    SHIFTREG_U128 SREG_FS0 (.SR0({SR0}), .Clk(Clk), .Clk_enable_513(Clk_enable_513), 
            .Clk_enable_391(Clk_enable_391), .QTA(QP[7]), .Clk_enable_549(Clk_enable_549)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(973[10:81])
    
endmodule
//
// Verilog Description of module SHIFTREG_U123
//

module SHIFTREG_U123 (QP, Clk, Clk_enable_549, Clk_enable_513, \QS_IN[1] , 
            \QS_IN[2] , \QS_IN[3] , \QS_IN[4] , Clk_enable_564, \QS_IN[5] , 
            \QS_IN[6] , \QS_IN[7] , n5730, n5728, n5726, n5724, 
            n5722, n5720, n5718, PD_out_0, Clk_enable_293, n11701) /* synthesis syn_module_defined=1 */ ;
    output [7:0]QP;
    input Clk;
    input Clk_enable_549;
    input Clk_enable_513;
    output \QS_IN[1] ;
    output \QS_IN[2] ;
    output \QS_IN[3] ;
    output \QS_IN[4] ;
    input Clk_enable_564;
    output \QS_IN[5] ;
    output \QS_IN[6] ;
    output \QS_IN[7] ;
    input n5730;
    input n5728;
    input n5726;
    input n5724;
    input n5722;
    input n5720;
    input n5718;
    input PD_out_0;
    input Clk_enable_293;
    input n11701;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5616;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_549), .CK(Clk), .Q(QP[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n5616), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_513), .CK(Clk), .Q(QP[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_513), .CK(Clk), .Q(QP[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_513), .CK(Clk), .Q(QP[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_549), .CK(Clk), .Q(QP[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_564), .CK(Clk), .Q(QP[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_549), .CK(Clk), .Q(QP[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_513), .CK(Clk), .Q(QP[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5730), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5728), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5726), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5724), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5722), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5720), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5718), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=972, LSE_RLINE=972 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    LUT4 i5111_4_lut (.A(QS_IN[0]), .B(PD_out_0), .C(Clk_enable_293), 
         .D(n11701), .Z(n5616)) /* synthesis lut_function=(A (B+!(C))+!A (B (C+!(D))+!B !(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5111_4_lut.init = 16'hcacf;
    
endmodule
//
// Verilog Description of module SHIFTREG_U124
//

module SHIFTREG_U124 (Clk, QP, Clk_enable_513, \QS_IN[1] , n5174, 
            \QS_IN[2] , n5166, \QS_IN[3] , n5137, \QS_IN[4] , n5131, 
            \QS_IN[5] , n5736, \QS_IN[6] , n5734, \QS_IN[7] , n5732, 
            \PDTA[0] , Clk_enable_293, n11701) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    output [7:0]QP;
    input Clk_enable_513;
    output \QS_IN[1] ;
    input n5174;
    output \QS_IN[2] ;
    input n5166;
    output \QS_IN[3] ;
    input n5137;
    output \QS_IN[4] ;
    input n5131;
    output \QS_IN[5] ;
    input n5736;
    output \QS_IN[6] ;
    input n5734;
    output \QS_IN[7] ;
    input n5732;
    input \PDTA[0] ;
    input Clk_enable_293;
    input n11701;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    wire n5618;
    
    FD1S3AX QS_IN_i0_i0 (.D(n5618), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_513), .CK(Clk), .Q(QP[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5174), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5166), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5137), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5131), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5736), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5734), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5732), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_513), .CK(Clk), .Q(QP[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_513), .CK(Clk), .Q(QP[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_513), .CK(Clk), .Q(QP[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_513), .CK(Clk), .Q(QP[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_513), .CK(Clk), .Q(QP[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_513), .CK(Clk), .Q(QP[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_513), .CK(Clk), .Q(QP[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=971, LSE_RLINE=971 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    LUT4 i5113_4_lut (.A(QS_IN[0]), .B(\PDTA[0] ), .C(Clk_enable_293), 
         .D(n11701), .Z(n5618)) /* synthesis lut_function=(A (B+!(C))+!A (B (C+!(D))+!B !(C+(D)))) */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam i5113_4_lut.init = 16'hcacf;
    
endmodule
//
// Verilog Description of module SHIFTREG_U125
//

module SHIFTREG_U125 (SR3, Clk, Clk_enable_549, Clk_enable_391, \ATR[1] , 
            Clk_enable_513) /* synthesis syn_module_defined=1 */ ;
    output [7:0]SR3;
    input Clk;
    input Clk_enable_549;
    input Clk_enable_391;
    input \ATR[1] ;
    input Clk_enable_513;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_549), .CK(Clk), .Q(SR3[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i0 (.D(\ATR[1] ), .SP(Clk_enable_391), .CK(Clk), 
            .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(Clk_enable_513), .CK(Clk), .Q(SR3[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(Clk_enable_513), .CK(Clk), .Q(SR3[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(Clk_enable_513), .CK(Clk), .Q(SR3[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(Clk_enable_513), .CK(Clk), .Q(SR3[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(Clk_enable_513), .CK(Clk), .Q(SR3[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(Clk_enable_513), .CK(Clk), .Q(SR3[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(Clk_enable_513), .CK(Clk), .Q(SR3[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(SR3[0]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(SR3[1]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(SR3[2]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(SR3[3]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(SR3[4]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(SR3[5]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(SR3[6]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U126
//

module SHIFTREG_U126 (SR2, Clk, Clk_enable_549, Clk_enable_391, \ATR[0] , 
            Clk_enable_513, Clk_enable_367) /* synthesis syn_module_defined=1 */ ;
    output [7:0]SR2;
    input Clk;
    input Clk_enable_549;
    input Clk_enable_391;
    input \ATR[0] ;
    input Clk_enable_513;
    input Clk_enable_367;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_549), .CK(Clk), .Q(SR2[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i0 (.D(\ATR[0] ), .SP(Clk_enable_391), .CK(Clk), 
            .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(Clk_enable_513), .CK(Clk), .Q(SR2[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(Clk_enable_367), .CK(Clk), .Q(SR2[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(Clk_enable_367), .CK(Clk), .Q(SR2[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(Clk_enable_367), .CK(Clk), .Q(SR2[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(Clk_enable_513), .CK(Clk), .Q(SR2[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(Clk_enable_513), .CK(Clk), .Q(SR2[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(Clk_enable_513), .CK(Clk), .Q(SR2[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(SR2[0]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(SR2[1]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(SR2[2]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(SR2[3]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(SR2[4]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(SR2[5]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(SR2[6]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=975, LSE_RLINE=975 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U127
//

module SHIFTREG_U127 (SR1, Clk, Clk_enable_549, Clk_enable_391, QTB, 
            Clk_enable_513, Clk_enable_367) /* synthesis syn_module_defined=1 */ ;
    output [7:0]SR1;
    input Clk;
    input Clk_enable_549;
    input Clk_enable_391;
    input QTB;
    input Clk_enable_513;
    input Clk_enable_367;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_549), .CK(Clk), .Q(SR1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i0 (.D(QTB), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(Clk_enable_513), .CK(Clk), .Q(SR1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(Clk_enable_513), .CK(Clk), .Q(SR1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(Clk_enable_513), .CK(Clk), .Q(SR1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(Clk_enable_513), .CK(Clk), .Q(SR1[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(Clk_enable_513), .CK(Clk), .Q(SR1[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(Clk_enable_513), .CK(Clk), .Q(SR1[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(Clk_enable_367), .CK(Clk), .Q(SR1[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(SR1[0]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(SR1[1]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(SR1[2]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(SR1[3]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(SR1[4]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(SR1[5]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(SR1[6]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=974, LSE_RLINE=974 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U128
//

module SHIFTREG_U128 (SR0, Clk, Clk_enable_513, Clk_enable_391, QTA, 
            Clk_enable_549) /* synthesis syn_module_defined=1 */ ;
    output [7:0]SR0;
    input Clk;
    input Clk_enable_513;
    input Clk_enable_391;
    input QTA;
    input Clk_enable_549;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1477[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_513), .CK(Clk), .Q(SR0[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i0 (.D(QTA), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(Clk_enable_513), .CK(Clk), .Q(SR0[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(Clk_enable_513), .CK(Clk), .Q(SR0[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(Clk_enable_513), .CK(Clk), .Q(SR0[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(Clk_enable_549), .CK(Clk), .Q(SR0[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(Clk_enable_513), .CK(Clk), .Q(SR0[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(Clk_enable_513), .CK(Clk), .Q(SR0[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(Clk_enable_513), .CK(Clk), .Q(SR0[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(SR0[0]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(SR0[1]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(SR0[2]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(SR0[3]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(SR0[4]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(SR0[5]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(SR0[6]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=973, LSE_RLINE=973 */ ;   // d:/ppu_reverse/fpga/ppu_mini/rp2c02_mini.v(1481[8] 1484[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
